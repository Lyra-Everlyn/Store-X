﻿namespace My_Store
{
    partial class CategoryAndSupplierForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CategoryAndSupplierForm));
            this.textBoxSearchCategory = new System.Windows.Forms.TextBox();
            this.textBoxSearchSupplier = new System.Windows.Forms.TextBox();
            this.dgvCategoryList = new System.Windows.Forms.DataGridView();
            this.dgvSupplierList = new System.Windows.Forms.DataGridView();
            this.buttonCreateNewCategory = new System.Windows.Forms.Button();
            this.buttonEditCategory = new System.Windows.Forms.Button();
            this.buttonCreateNewSupplier = new System.Windows.Forms.Button();
            this.buttonEditSupplier = new System.Windows.Forms.Button();
            this.panelCategoryInfo = new System.Windows.Forms.Panel();
            this.buttonAddCategory = new System.Windows.Forms.Button();
            this.richTextBoxDescription = new System.Windows.Forms.RichTextBox();
            this.labelCategoryId = new System.Windows.Forms.Label();
            this.buttonDeleteCategory = new System.Windows.Forms.Button();
            this.labelCategoryName = new System.Windows.Forms.Label();
            this.buttonSaveCategory = new System.Windows.Forms.Button();
            this.textBoxCategoryName = new System.Windows.Forms.TextBox();
            this.labelCategoryDescription = new System.Windows.Forms.Label();
            this.linkLabelCancelEditCategory = new System.Windows.Forms.LinkLabel();
            this.panelSupplierInfo = new System.Windows.Forms.Panel();
            this.buttonAddSupplier = new System.Windows.Forms.Button();
            this.labelSupplierAddress = new System.Windows.Forms.Label();
            this.textBoxSuppierEmail = new System.Windows.Forms.TextBox();
            this.textBoxSupplierPhoneNumber = new System.Windows.Forms.TextBox();
            this.richTextBoxAddress = new System.Windows.Forms.RichTextBox();
            this.labelSupplierEmail = new System.Windows.Forms.Label();
            this.labelSupplierId = new System.Windows.Forms.Label();
            this.buttonDeleteSupplier = new System.Windows.Forms.Button();
            this.labelSupplierName = new System.Windows.Forms.Label();
            this.buttonSaveSupplier = new System.Windows.Forms.Button();
            this.textBoxSupplierName = new System.Windows.Forms.TextBox();
            this.labelSupplierPhoneNumber = new System.Windows.Forms.Label();
            this.linkLabelCancelEditSupplier = new System.Windows.Forms.LinkLabel();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCategoryList)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSupplierList)).BeginInit();
            this.panelCategoryInfo.SuspendLayout();
            this.panelSupplierInfo.SuspendLayout();
            this.SuspendLayout();
            // 
            // textBoxSearchCategory
            // 
            this.textBoxSearchCategory.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.textBoxSearchCategory.Location = new System.Drawing.Point(12, 12);
            this.textBoxSearchCategory.Name = "textBoxSearchCategory";
            this.textBoxSearchCategory.Size = new System.Drawing.Size(995, 43);
            this.textBoxSearchCategory.TabIndex = 32;
            this.textBoxSearchCategory.Text = "Search Category";
            this.textBoxSearchCategory.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxSearchCategory.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxSearchCategory_KeyDown);
            // 
            // textBoxSearchSupplier
            // 
            this.textBoxSearchSupplier.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.textBoxSearchSupplier.Location = new System.Drawing.Point(1047, 12);
            this.textBoxSearchSupplier.Name = "textBoxSearchSupplier";
            this.textBoxSearchSupplier.Size = new System.Drawing.Size(995, 43);
            this.textBoxSearchSupplier.TabIndex = 33;
            this.textBoxSearchSupplier.Text = "Search Supplier";
            this.textBoxSearchSupplier.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxSearchSupplier.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxSearchSupplier_KeyDown);
            // 
            // dgvCategoryList
            // 
            this.dgvCategoryList.AllowUserToAddRows = false;
            this.dgvCategoryList.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dgvCategoryList.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvCategoryList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvCategoryList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCategoryList.Location = new System.Drawing.Point(12, 78);
            this.dgvCategoryList.MultiSelect = false;
            this.dgvCategoryList.Name = "dgvCategoryList";
            this.dgvCategoryList.ReadOnly = true;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 10F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvCategoryList.RowHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dgvCategoryList.RowHeadersWidth = 82;
            this.dgvCategoryList.RowTemplate.Height = 40;
            this.dgvCategoryList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvCategoryList.Size = new System.Drawing.Size(995, 430);
            this.dgvCategoryList.TabIndex = 34;
            this.dgvCategoryList.SelectionChanged += new System.EventHandler(this.dgvCategoryList_SelectionChanged);
            // 
            // dgvSupplierList
            // 
            this.dgvSupplierList.AllowUserToAddRows = false;
            this.dgvSupplierList.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dgvSupplierList.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvSupplierList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgvSupplierList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSupplierList.Location = new System.Drawing.Point(1047, 78);
            this.dgvSupplierList.MultiSelect = false;
            this.dgvSupplierList.Name = "dgvSupplierList";
            this.dgvSupplierList.ReadOnly = true;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Segoe UI", 10F);
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvSupplierList.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dgvSupplierList.RowHeadersWidth = 82;
            this.dgvSupplierList.RowTemplate.Height = 40;
            this.dgvSupplierList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvSupplierList.Size = new System.Drawing.Size(995, 430);
            this.dgvSupplierList.TabIndex = 35;
            this.dgvSupplierList.SelectionChanged += new System.EventHandler(this.dgvSupplierList_SelectionChanged);
            // 
            // buttonCreateNewCategory
            // 
            this.buttonCreateNewCategory.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.buttonCreateNewCategory.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonCreateNewCategory.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.buttonCreateNewCategory.ForeColor = System.Drawing.Color.White;
            this.buttonCreateNewCategory.Location = new System.Drawing.Point(12, 514);
            this.buttonCreateNewCategory.Name = "buttonCreateNewCategory";
            this.buttonCreateNewCategory.Size = new System.Drawing.Size(200, 60);
            this.buttonCreateNewCategory.TabIndex = 63;
            this.buttonCreateNewCategory.Text = "New Category";
            this.buttonCreateNewCategory.UseVisualStyleBackColor = false;
            this.buttonCreateNewCategory.Click += new System.EventHandler(this.buttonCreateNewCategory_Click);
            // 
            // buttonEditCategory
            // 
            this.buttonEditCategory.BackColor = System.Drawing.Color.MediumOrchid;
            this.buttonEditCategory.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonEditCategory.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.buttonEditCategory.ForeColor = System.Drawing.Color.White;
            this.buttonEditCategory.Location = new System.Drawing.Point(218, 514);
            this.buttonEditCategory.Name = "buttonEditCategory";
            this.buttonEditCategory.Size = new System.Drawing.Size(200, 60);
            this.buttonEditCategory.TabIndex = 70;
            this.buttonEditCategory.Text = "Edit Category";
            this.buttonEditCategory.UseVisualStyleBackColor = false;
            this.buttonEditCategory.Click += new System.EventHandler(this.buttonEditCategory_Click);
            // 
            // buttonCreateNewSupplier
            // 
            this.buttonCreateNewSupplier.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.buttonCreateNewSupplier.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonCreateNewSupplier.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.buttonCreateNewSupplier.ForeColor = System.Drawing.Color.White;
            this.buttonCreateNewSupplier.Location = new System.Drawing.Point(1047, 514);
            this.buttonCreateNewSupplier.Name = "buttonCreateNewSupplier";
            this.buttonCreateNewSupplier.Size = new System.Drawing.Size(200, 60);
            this.buttonCreateNewSupplier.TabIndex = 71;
            this.buttonCreateNewSupplier.Text = "New Supplier";
            this.buttonCreateNewSupplier.UseVisualStyleBackColor = false;
            this.buttonCreateNewSupplier.Click += new System.EventHandler(this.buttonCreateNewSupplier_Click);
            // 
            // buttonEditSupplier
            // 
            this.buttonEditSupplier.BackColor = System.Drawing.Color.MediumOrchid;
            this.buttonEditSupplier.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonEditSupplier.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.buttonEditSupplier.ForeColor = System.Drawing.Color.White;
            this.buttonEditSupplier.Location = new System.Drawing.Point(1253, 514);
            this.buttonEditSupplier.Name = "buttonEditSupplier";
            this.buttonEditSupplier.Size = new System.Drawing.Size(200, 60);
            this.buttonEditSupplier.TabIndex = 72;
            this.buttonEditSupplier.Text = "Edit Supplier";
            this.buttonEditSupplier.UseVisualStyleBackColor = false;
            this.buttonEditSupplier.Click += new System.EventHandler(this.buttonEditSupplier_Click);
            // 
            // panelCategoryInfo
            // 
            this.panelCategoryInfo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelCategoryInfo.Controls.Add(this.buttonAddCategory);
            this.panelCategoryInfo.Controls.Add(this.richTextBoxDescription);
            this.panelCategoryInfo.Controls.Add(this.labelCategoryId);
            this.panelCategoryInfo.Controls.Add(this.buttonDeleteCategory);
            this.panelCategoryInfo.Controls.Add(this.labelCategoryName);
            this.panelCategoryInfo.Controls.Add(this.buttonSaveCategory);
            this.panelCategoryInfo.Controls.Add(this.textBoxCategoryName);
            this.panelCategoryInfo.Controls.Add(this.labelCategoryDescription);
            this.panelCategoryInfo.Location = new System.Drawing.Point(12, 580);
            this.panelCategoryInfo.Name = "panelCategoryInfo";
            this.panelCategoryInfo.Size = new System.Drawing.Size(995, 637);
            this.panelCategoryInfo.TabIndex = 73;
            // 
            // buttonAddCategory
            // 
            this.buttonAddCategory.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.buttonAddCategory.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAddCategory.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.buttonAddCategory.ForeColor = System.Drawing.Color.White;
            this.buttonAddCategory.Location = new System.Drawing.Point(684, 11);
            this.buttonAddCategory.Name = "buttonAddCategory";
            this.buttonAddCategory.Size = new System.Drawing.Size(150, 60);
            this.buttonAddCategory.TabIndex = 68;
            this.buttonAddCategory.Text = "Add";
            this.buttonAddCategory.UseVisualStyleBackColor = false;
            this.buttonAddCategory.Click += new System.EventHandler(this.buttonAddCategory_Click);
            // 
            // richTextBoxDescription
            // 
            this.richTextBoxDescription.BackColor = System.Drawing.Color.WhiteSmoke;
            this.richTextBoxDescription.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.richTextBoxDescription.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.richTextBoxDescription.Location = new System.Drawing.Point(19, 171);
            this.richTextBoxDescription.Name = "richTextBoxDescription";
            this.richTextBoxDescription.Size = new System.Drawing.Size(571, 250);
            this.richTextBoxDescription.TabIndex = 67;
            this.richTextBoxDescription.Text = "No description";
            // 
            // labelCategoryId
            // 
            this.labelCategoryId.AutoSize = true;
            this.labelCategoryId.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.labelCategoryId.Location = new System.Drawing.Point(12, 11);
            this.labelCategoryId.Name = "labelCategoryId";
            this.labelCategoryId.Size = new System.Drawing.Size(168, 37);
            this.labelCategoryId.TabIndex = 33;
            this.labelCategoryId.Text = "Category Id: ";
            // 
            // buttonDeleteCategory
            // 
            this.buttonDeleteCategory.BackColor = System.Drawing.Color.LightCoral;
            this.buttonDeleteCategory.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonDeleteCategory.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.buttonDeleteCategory.ForeColor = System.Drawing.Color.White;
            this.buttonDeleteCategory.Location = new System.Drawing.Point(840, 566);
            this.buttonDeleteCategory.Name = "buttonDeleteCategory";
            this.buttonDeleteCategory.Size = new System.Drawing.Size(150, 60);
            this.buttonDeleteCategory.TabIndex = 65;
            this.buttonDeleteCategory.Text = "Delete";
            this.buttonDeleteCategory.UseVisualStyleBackColor = false;
            this.buttonDeleteCategory.Click += new System.EventHandler(this.buttonDeleteCategory_Click);
            // 
            // labelCategoryName
            // 
            this.labelCategoryName.AutoSize = true;
            this.labelCategoryName.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.labelCategoryName.Location = new System.Drawing.Point(12, 71);
            this.labelCategoryName.Name = "labelCategoryName";
            this.labelCategoryName.Size = new System.Drawing.Size(211, 37);
            this.labelCategoryName.TabIndex = 34;
            this.labelCategoryName.Text = "Category name: ";
            // 
            // buttonSaveCategory
            // 
            this.buttonSaveCategory.BackColor = System.Drawing.Color.LimeGreen;
            this.buttonSaveCategory.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSaveCategory.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.buttonSaveCategory.ForeColor = System.Drawing.Color.White;
            this.buttonSaveCategory.Location = new System.Drawing.Point(840, 11);
            this.buttonSaveCategory.Name = "buttonSaveCategory";
            this.buttonSaveCategory.Size = new System.Drawing.Size(150, 60);
            this.buttonSaveCategory.TabIndex = 64;
            this.buttonSaveCategory.Text = "Update";
            this.buttonSaveCategory.UseVisualStyleBackColor = false;
            this.buttonSaveCategory.Click += new System.EventHandler(this.buttonSaveCategory_Click);
            // 
            // textBoxCategoryName
            // 
            this.textBoxCategoryName.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.textBoxCategoryName.Location = new System.Drawing.Point(240, 68);
            this.textBoxCategoryName.Name = "textBoxCategoryName";
            this.textBoxCategoryName.Size = new System.Drawing.Size(350, 43);
            this.textBoxCategoryName.TabIndex = 37;
            // 
            // labelCategoryDescription
            // 
            this.labelCategoryDescription.AutoSize = true;
            this.labelCategoryDescription.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.labelCategoryDescription.Location = new System.Drawing.Point(12, 131);
            this.labelCategoryDescription.Name = "labelCategoryDescription";
            this.labelCategoryDescription.Size = new System.Drawing.Size(165, 37);
            this.labelCategoryDescription.TabIndex = 36;
            this.labelCategoryDescription.Text = "Description: ";
            // 
            // linkLabelCancelEditCategory
            // 
            this.linkLabelCancelEditCategory.AutoSize = true;
            this.linkLabelCancelEditCategory.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.linkLabelCancelEditCategory.LinkColor = System.Drawing.Color.DeepSkyBlue;
            this.linkLabelCancelEditCategory.Location = new System.Drawing.Point(424, 526);
            this.linkLabelCancelEditCategory.Name = "linkLabelCancelEditCategory";
            this.linkLabelCancelEditCategory.Size = new System.Drawing.Size(149, 37);
            this.linkLabelCancelEditCategory.TabIndex = 66;
            this.linkLabelCancelEditCategory.TabStop = true;
            this.linkLabelCancelEditCategory.Text = "Cancel edit";
            this.linkLabelCancelEditCategory.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabelCancelEditCategory_LinkClicked);
            // 
            // panelSupplierInfo
            // 
            this.panelSupplierInfo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelSupplierInfo.Controls.Add(this.buttonAddSupplier);
            this.panelSupplierInfo.Controls.Add(this.labelSupplierAddress);
            this.panelSupplierInfo.Controls.Add(this.textBoxSuppierEmail);
            this.panelSupplierInfo.Controls.Add(this.textBoxSupplierPhoneNumber);
            this.panelSupplierInfo.Controls.Add(this.richTextBoxAddress);
            this.panelSupplierInfo.Controls.Add(this.labelSupplierEmail);
            this.panelSupplierInfo.Controls.Add(this.labelSupplierId);
            this.panelSupplierInfo.Controls.Add(this.buttonDeleteSupplier);
            this.panelSupplierInfo.Controls.Add(this.labelSupplierName);
            this.panelSupplierInfo.Controls.Add(this.buttonSaveSupplier);
            this.panelSupplierInfo.Controls.Add(this.textBoxSupplierName);
            this.panelSupplierInfo.Controls.Add(this.labelSupplierPhoneNumber);
            this.panelSupplierInfo.Location = new System.Drawing.Point(1047, 580);
            this.panelSupplierInfo.Name = "panelSupplierInfo";
            this.panelSupplierInfo.Size = new System.Drawing.Size(995, 637);
            this.panelSupplierInfo.TabIndex = 75;
            // 
            // buttonAddSupplier
            // 
            this.buttonAddSupplier.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.buttonAddSupplier.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAddSupplier.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.buttonAddSupplier.ForeColor = System.Drawing.Color.White;
            this.buttonAddSupplier.Location = new System.Drawing.Point(684, 11);
            this.buttonAddSupplier.Name = "buttonAddSupplier";
            this.buttonAddSupplier.Size = new System.Drawing.Size(150, 60);
            this.buttonAddSupplier.TabIndex = 72;
            this.buttonAddSupplier.Text = "Add";
            this.buttonAddSupplier.UseVisualStyleBackColor = false;
            this.buttonAddSupplier.Click += new System.EventHandler(this.buttonAddSupplier_Click);
            // 
            // labelSupplierAddress
            // 
            this.labelSupplierAddress.AutoSize = true;
            this.labelSupplierAddress.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.labelSupplierAddress.Location = new System.Drawing.Point(12, 251);
            this.labelSupplierAddress.Name = "labelSupplierAddress";
            this.labelSupplierAddress.Size = new System.Drawing.Size(124, 37);
            this.labelSupplierAddress.TabIndex = 71;
            this.labelSupplierAddress.Text = "Address: ";
            // 
            // textBoxSuppierEmail
            // 
            this.textBoxSuppierEmail.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.textBoxSuppierEmail.Location = new System.Drawing.Point(240, 188);
            this.textBoxSuppierEmail.Name = "textBoxSuppierEmail";
            this.textBoxSuppierEmail.Size = new System.Drawing.Size(350, 43);
            this.textBoxSuppierEmail.TabIndex = 70;
            // 
            // textBoxSupplierPhoneNumber
            // 
            this.textBoxSupplierPhoneNumber.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.textBoxSupplierPhoneNumber.Location = new System.Drawing.Point(240, 128);
            this.textBoxSupplierPhoneNumber.Name = "textBoxSupplierPhoneNumber";
            this.textBoxSupplierPhoneNumber.Size = new System.Drawing.Size(350, 43);
            this.textBoxSupplierPhoneNumber.TabIndex = 69;
            // 
            // richTextBoxAddress
            // 
            this.richTextBoxAddress.BackColor = System.Drawing.Color.WhiteSmoke;
            this.richTextBoxAddress.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.richTextBoxAddress.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.richTextBoxAddress.Location = new System.Drawing.Point(19, 291);
            this.richTextBoxAddress.Name = "richTextBoxAddress";
            this.richTextBoxAddress.Size = new System.Drawing.Size(571, 100);
            this.richTextBoxAddress.TabIndex = 68;
            this.richTextBoxAddress.Text = "";
            // 
            // labelSupplierEmail
            // 
            this.labelSupplierEmail.AutoSize = true;
            this.labelSupplierEmail.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.labelSupplierEmail.Location = new System.Drawing.Point(12, 191);
            this.labelSupplierEmail.Name = "labelSupplierEmail";
            this.labelSupplierEmail.Size = new System.Drawing.Size(95, 37);
            this.labelSupplierEmail.TabIndex = 67;
            this.labelSupplierEmail.Text = "Email: ";
            // 
            // labelSupplierId
            // 
            this.labelSupplierId.AutoSize = true;
            this.labelSupplierId.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.labelSupplierId.Location = new System.Drawing.Point(12, 11);
            this.labelSupplierId.Name = "labelSupplierId";
            this.labelSupplierId.Size = new System.Drawing.Size(158, 37);
            this.labelSupplierId.TabIndex = 33;
            this.labelSupplierId.Text = "Supplier Id: ";
            // 
            // buttonDeleteSupplier
            // 
            this.buttonDeleteSupplier.BackColor = System.Drawing.Color.LightCoral;
            this.buttonDeleteSupplier.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonDeleteSupplier.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.buttonDeleteSupplier.ForeColor = System.Drawing.Color.White;
            this.buttonDeleteSupplier.Location = new System.Drawing.Point(840, 566);
            this.buttonDeleteSupplier.Name = "buttonDeleteSupplier";
            this.buttonDeleteSupplier.Size = new System.Drawing.Size(150, 60);
            this.buttonDeleteSupplier.TabIndex = 65;
            this.buttonDeleteSupplier.Text = "Delete";
            this.buttonDeleteSupplier.UseVisualStyleBackColor = false;
            this.buttonDeleteSupplier.Click += new System.EventHandler(this.buttonDeleteSupplier_Click);
            // 
            // labelSupplierName
            // 
            this.labelSupplierName.AutoSize = true;
            this.labelSupplierName.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.labelSupplierName.Location = new System.Drawing.Point(12, 71);
            this.labelSupplierName.Name = "labelSupplierName";
            this.labelSupplierName.Size = new System.Drawing.Size(201, 37);
            this.labelSupplierName.TabIndex = 34;
            this.labelSupplierName.Text = "Supplier name: ";
            // 
            // buttonSaveSupplier
            // 
            this.buttonSaveSupplier.BackColor = System.Drawing.Color.LimeGreen;
            this.buttonSaveSupplier.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSaveSupplier.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.buttonSaveSupplier.ForeColor = System.Drawing.Color.White;
            this.buttonSaveSupplier.Location = new System.Drawing.Point(840, 11);
            this.buttonSaveSupplier.Name = "buttonSaveSupplier";
            this.buttonSaveSupplier.Size = new System.Drawing.Size(150, 60);
            this.buttonSaveSupplier.TabIndex = 64;
            this.buttonSaveSupplier.Text = "Update";
            this.buttonSaveSupplier.UseVisualStyleBackColor = false;
            this.buttonSaveSupplier.Click += new System.EventHandler(this.buttonSaveSupplier_Click);
            // 
            // textBoxSupplierName
            // 
            this.textBoxSupplierName.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.textBoxSupplierName.Location = new System.Drawing.Point(240, 68);
            this.textBoxSupplierName.Name = "textBoxSupplierName";
            this.textBoxSupplierName.Size = new System.Drawing.Size(350, 43);
            this.textBoxSupplierName.TabIndex = 37;
            // 
            // labelSupplierPhoneNumber
            // 
            this.labelSupplierPhoneNumber.AutoSize = true;
            this.labelSupplierPhoneNumber.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.labelSupplierPhoneNumber.Location = new System.Drawing.Point(12, 131);
            this.labelSupplierPhoneNumber.Name = "labelSupplierPhoneNumber";
            this.labelSupplierPhoneNumber.Size = new System.Drawing.Size(204, 37);
            this.labelSupplierPhoneNumber.TabIndex = 36;
            this.labelSupplierPhoneNumber.Text = "Phone number: ";
            // 
            // linkLabelCancelEditSupplier
            // 
            this.linkLabelCancelEditSupplier.AutoSize = true;
            this.linkLabelCancelEditSupplier.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.linkLabelCancelEditSupplier.LinkColor = System.Drawing.Color.DeepSkyBlue;
            this.linkLabelCancelEditSupplier.Location = new System.Drawing.Point(1459, 526);
            this.linkLabelCancelEditSupplier.Name = "linkLabelCancelEditSupplier";
            this.linkLabelCancelEditSupplier.Size = new System.Drawing.Size(149, 37);
            this.linkLabelCancelEditSupplier.TabIndex = 66;
            this.linkLabelCancelEditSupplier.TabStop = true;
            this.linkLabelCancelEditSupplier.Text = "Cancel edit";
            this.linkLabelCancelEditSupplier.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabelCancelEditSupplier_LinkClicked);
            // 
            // CategoryAndSupplierForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(2054, 1229);
            this.Controls.Add(this.panelSupplierInfo);
            this.Controls.Add(this.panelCategoryInfo);
            this.Controls.Add(this.linkLabelCancelEditCategory);
            this.Controls.Add(this.buttonEditSupplier);
            this.Controls.Add(this.buttonCreateNewSupplier);
            this.Controls.Add(this.buttonEditCategory);
            this.Controls.Add(this.linkLabelCancelEditSupplier);
            this.Controls.Add(this.buttonCreateNewCategory);
            this.Controls.Add(this.dgvSupplierList);
            this.Controls.Add(this.dgvCategoryList);
            this.Controls.Add(this.textBoxSearchSupplier);
            this.Controls.Add(this.textBoxSearchCategory);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "CategoryAndSupplierForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Category & supplier management";
            this.Load += new System.EventHandler(this.CategoryAndSupplierForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvCategoryList)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSupplierList)).EndInit();
            this.panelCategoryInfo.ResumeLayout(false);
            this.panelCategoryInfo.PerformLayout();
            this.panelSupplierInfo.ResumeLayout(false);
            this.panelSupplierInfo.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBoxSearchCategory;
        private System.Windows.Forms.TextBox textBoxSearchSupplier;
        private System.Windows.Forms.DataGridView dgvCategoryList;
        private System.Windows.Forms.DataGridView dgvSupplierList;
        private System.Windows.Forms.Button buttonCreateNewCategory;
        private System.Windows.Forms.Button buttonEditCategory;
        private System.Windows.Forms.Button buttonCreateNewSupplier;
        private System.Windows.Forms.Button buttonEditSupplier;
        private System.Windows.Forms.Panel panelCategoryInfo;
        private System.Windows.Forms.LinkLabel linkLabelCancelEditCategory;
        private System.Windows.Forms.Label labelCategoryId;
        private System.Windows.Forms.Button buttonDeleteCategory;
        private System.Windows.Forms.Label labelCategoryName;
        private System.Windows.Forms.Button buttonSaveCategory;
        private System.Windows.Forms.TextBox textBoxCategoryName;
        private System.Windows.Forms.Label labelCategoryDescription;
        private System.Windows.Forms.RichTextBox richTextBoxDescription;
        private System.Windows.Forms.Panel panelSupplierInfo;
        private System.Windows.Forms.Label labelSupplierEmail;
        private System.Windows.Forms.LinkLabel linkLabelCancelEditSupplier;
        private System.Windows.Forms.Label labelSupplierId;
        private System.Windows.Forms.Button buttonDeleteSupplier;
        private System.Windows.Forms.Label labelSupplierName;
        private System.Windows.Forms.Button buttonSaveSupplier;
        private System.Windows.Forms.TextBox textBoxSupplierName;
        private System.Windows.Forms.Label labelSupplierPhoneNumber;
        private System.Windows.Forms.Label labelSupplierAddress;
        private System.Windows.Forms.TextBox textBoxSuppierEmail;
        private System.Windows.Forms.TextBox textBoxSupplierPhoneNumber;
        private System.Windows.Forms.RichTextBox richTextBoxAddress;
        private System.Windows.Forms.Button buttonAddCategory;
        private System.Windows.Forms.Button buttonAddSupplier;
    }
}