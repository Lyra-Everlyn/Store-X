﻿using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace My_Store
{
    partial class AdminDashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AdminDashboard));
            this.tabAdmin = new System.Windows.Forms.TabControl();
            this.tabPageRevenue = new System.Windows.Forms.TabPage();
            this.panelTodayRevenue = new System.Windows.Forms.Panel();
            this.labelTodayRevenue = new System.Windows.Forms.Label();
            this.labelTodayRevenueTitle = new System.Windows.Forms.Label();
            this.panelMonthRevenue = new System.Windows.Forms.Panel();
            this.labelMonthRevenue = new System.Windows.Forms.Label();
            this.labelMonthRevenueTitle = new System.Windows.Forms.Label();
            this.panelYesterdayRevenue = new System.Windows.Forms.Panel();
            this.labelYesterdayRevenue = new System.Windows.Forms.Label();
            this.labelYesterdayRevenueTitle = new System.Windows.Forms.Label();
            this.dgvDetailedRevenue = new System.Windows.Forms.DataGridView();
            this.chartRevenue = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.tabStaff = new System.Windows.Forms.TabPage();
            this.dgvStaffList = new System.Windows.Forms.DataGridView();
            this.linkLabelCancelEditStaff = new System.Windows.Forms.LinkLabel();
            this.buttonEditStaff = new System.Windows.Forms.Button();
            this.buttonCreateNewStaff = new System.Windows.Forms.Button();
            this.checkBoxShowInactiveAcc = new System.Windows.Forms.CheckBox();
            this.buttonDeleteStaff = new System.Windows.Forms.Button();
            this.buttonSaveChanges = new System.Windows.Forms.Button();
            this.buttonAddStaff = new System.Windows.Forms.Button();
            this.comboBoxWorkingStatus = new System.Windows.Forms.ComboBox();
            this.labelWorkingStatus = new System.Windows.Forms.Label();
            this.labelAuthorityLevel = new System.Windows.Forms.Label();
            this.checkBoxShowPassword = new System.Windows.Forms.CheckBox();
            this.labelPassword = new System.Windows.Forms.Label();
            this.labelUsername = new System.Windows.Forms.Label();
            this.labelEmail = new System.Windows.Forms.Label();
            this.labelPhoneNumber = new System.Windows.Forms.Label();
            this.labelStaffName = new System.Windows.Forms.Label();
            this.textBoxSearchStaff = new System.Windows.Forms.TextBox();
            this.comboBoxAuthorityLevel = new System.Windows.Forms.ComboBox();
            this.labelStaffId = new System.Windows.Forms.Label();
            this.textBoxStaffName = new System.Windows.Forms.TextBox();
            this.textBoxPhoneNumber = new System.Windows.Forms.TextBox();
            this.textBoxEmail = new System.Windows.Forms.TextBox();
            this.textBoxPassword = new System.Windows.Forms.TextBox();
            this.textBoxUsername = new System.Windows.Forms.TextBox();
            this.tabAdmin.SuspendLayout();
            this.tabPageRevenue.SuspendLayout();
            this.panelTodayRevenue.SuspendLayout();
            this.panelMonthRevenue.SuspendLayout();
            this.panelYesterdayRevenue.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDetailedRevenue)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartRevenue)).BeginInit();
            this.tabStaff.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvStaffList)).BeginInit();
            this.SuspendLayout();
            // 
            // tabAdmin
            // 
            this.tabAdmin.Controls.Add(this.tabPageRevenue);
            this.tabAdmin.Controls.Add(this.tabStaff);
            this.tabAdmin.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabAdmin.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tabAdmin.ItemSize = new System.Drawing.Size(98, 45);
            this.tabAdmin.Location = new System.Drawing.Point(0, 0);
            this.tabAdmin.Name = "tabAdmin";
            this.tabAdmin.SelectedIndex = 0;
            this.tabAdmin.Size = new System.Drawing.Size(1894, 1129);
            this.tabAdmin.TabIndex = 0;
            // 
            // tabPageRevenue
            // 
            this.tabPageRevenue.BackColor = System.Drawing.Color.White;
            this.tabPageRevenue.Controls.Add(this.panelTodayRevenue);
            this.tabPageRevenue.Controls.Add(this.panelMonthRevenue);
            this.tabPageRevenue.Controls.Add(this.panelYesterdayRevenue);
            this.tabPageRevenue.Controls.Add(this.dgvDetailedRevenue);
            this.tabPageRevenue.Controls.Add(this.chartRevenue);
            this.tabPageRevenue.Location = new System.Drawing.Point(8, 53);
            this.tabPageRevenue.Name = "tabPageRevenue";
            this.tabPageRevenue.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageRevenue.Size = new System.Drawing.Size(1878, 1068);
            this.tabPageRevenue.TabIndex = 0;
            this.tabPageRevenue.Text = "Revenue";
            // 
            // panelTodayRevenue
            // 
            this.panelTodayRevenue.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelTodayRevenue.Controls.Add(this.labelTodayRevenue);
            this.panelTodayRevenue.Controls.Add(this.labelTodayRevenueTitle);
            this.panelTodayRevenue.ForeColor = System.Drawing.SystemColors.ControlText;
            this.panelTodayRevenue.Location = new System.Drawing.Point(6, 6);
            this.panelTodayRevenue.Name = "panelTodayRevenue";
            this.panelTodayRevenue.Size = new System.Drawing.Size(340, 112);
            this.panelTodayRevenue.TabIndex = 6;
            // 
            // labelTodayRevenue
            // 
            this.labelTodayRevenue.AutoSize = true;
            this.labelTodayRevenue.Font = new System.Drawing.Font("Segoe UI", 18F);
            this.labelTodayRevenue.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.labelTodayRevenue.Location = new System.Drawing.Point(-1, 46);
            this.labelTodayRevenue.Name = "labelTodayRevenue";
            this.labelTodayRevenue.Size = new System.Drawing.Size(54, 65);
            this.labelTodayRevenue.TabIndex = 2;
            this.labelTodayRevenue.Text = "0";
            // 
            // labelTodayRevenueTitle
            // 
            this.labelTodayRevenueTitle.AutoSize = true;
            this.labelTodayRevenueTitle.Font = new System.Drawing.Font("Segoe UI", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTodayRevenueTitle.ForeColor = System.Drawing.Color.Gray;
            this.labelTodayRevenueTitle.Location = new System.Drawing.Point(3, 9);
            this.labelTodayRevenueTitle.Name = "labelTodayRevenueTitle";
            this.labelTodayRevenueTitle.Size = new System.Drawing.Size(211, 37);
            this.labelTodayRevenueTitle.TabIndex = 3;
            this.labelTodayRevenueTitle.Text = "Today\'s Revenue";
            // 
            // panelMonthRevenue
            // 
            this.panelMonthRevenue.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelMonthRevenue.Controls.Add(this.labelMonthRevenue);
            this.panelMonthRevenue.Controls.Add(this.labelMonthRevenueTitle);
            this.panelMonthRevenue.Location = new System.Drawing.Point(698, 6);
            this.panelMonthRevenue.Name = "panelMonthRevenue";
            this.panelMonthRevenue.Size = new System.Drawing.Size(340, 112);
            this.panelMonthRevenue.TabIndex = 6;
            // 
            // labelMonthRevenue
            // 
            this.labelMonthRevenue.AutoSize = true;
            this.labelMonthRevenue.Font = new System.Drawing.Font("Segoe UI", 18F);
            this.labelMonthRevenue.ForeColor = System.Drawing.Color.Orange;
            this.labelMonthRevenue.Location = new System.Drawing.Point(3, 46);
            this.labelMonthRevenue.Name = "labelMonthRevenue";
            this.labelMonthRevenue.Size = new System.Drawing.Size(54, 65);
            this.labelMonthRevenue.TabIndex = 2;
            this.labelMonthRevenue.Text = "0";
            // 
            // labelMonthRevenueTitle
            // 
            this.labelMonthRevenueTitle.AutoSize = true;
            this.labelMonthRevenueTitle.Font = new System.Drawing.Font("Segoe UI", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelMonthRevenueTitle.ForeColor = System.Drawing.Color.Gray;
            this.labelMonthRevenueTitle.Location = new System.Drawing.Point(-1, 9);
            this.labelMonthRevenueTitle.Name = "labelMonthRevenueTitle";
            this.labelMonthRevenueTitle.Size = new System.Drawing.Size(273, 37);
            this.labelMonthRevenueTitle.TabIndex = 3;
            this.labelMonthRevenueTitle.Text = "This month\'s Revenue";
            // 
            // panelYesterdayRevenue
            // 
            this.panelYesterdayRevenue.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelYesterdayRevenue.Controls.Add(this.labelYesterdayRevenue);
            this.panelYesterdayRevenue.Controls.Add(this.labelYesterdayRevenueTitle);
            this.panelYesterdayRevenue.Location = new System.Drawing.Point(352, 6);
            this.panelYesterdayRevenue.Name = "panelYesterdayRevenue";
            this.panelYesterdayRevenue.Size = new System.Drawing.Size(340, 112);
            this.panelYesterdayRevenue.TabIndex = 5;
            // 
            // labelYesterdayRevenue
            // 
            this.labelYesterdayRevenue.AutoSize = true;
            this.labelYesterdayRevenue.Font = new System.Drawing.Font("Segoe UI", 18F);
            this.labelYesterdayRevenue.ForeColor = System.Drawing.Color.LimeGreen;
            this.labelYesterdayRevenue.Location = new System.Drawing.Point(-1, 46);
            this.labelYesterdayRevenue.Name = "labelYesterdayRevenue";
            this.labelYesterdayRevenue.Size = new System.Drawing.Size(54, 65);
            this.labelYesterdayRevenue.TabIndex = 2;
            this.labelYesterdayRevenue.Text = "0";
            // 
            // labelYesterdayRevenueTitle
            // 
            this.labelYesterdayRevenueTitle.AutoSize = true;
            this.labelYesterdayRevenueTitle.Font = new System.Drawing.Font("Segoe UI", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelYesterdayRevenueTitle.ForeColor = System.Drawing.Color.Gray;
            this.labelYesterdayRevenueTitle.Location = new System.Drawing.Point(3, 9);
            this.labelYesterdayRevenueTitle.Name = "labelYesterdayRevenueTitle";
            this.labelYesterdayRevenueTitle.Size = new System.Drawing.Size(254, 37);
            this.labelYesterdayRevenueTitle.TabIndex = 3;
            this.labelYesterdayRevenueTitle.Text = "Yesterday\'s Revenue";
            // 
            // dgvDetailedRevenue
            // 
            this.dgvDetailedRevenue.AllowUserToAddRows = false;
            this.dgvDetailedRevenue.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dgvDetailedRevenue.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvDetailedRevenue.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvDetailedRevenue.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.875F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvDetailedRevenue.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgvDetailedRevenue.Location = new System.Drawing.Point(1242, 6);
            this.dgvDetailedRevenue.MultiSelect = false;
            this.dgvDetailedRevenue.Name = "dgvDetailedRevenue";
            this.dgvDetailedRevenue.ReadOnly = true;
            this.dgvDetailedRevenue.RowHeadersWidth = 82;
            this.dgvDetailedRevenue.RowTemplate.Height = 33;
            this.dgvDetailedRevenue.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvDetailedRevenue.Size = new System.Drawing.Size(630, 1136);
            this.dgvDetailedRevenue.TabIndex = 1;
            this.dgvDetailedRevenue.MouseMove += new System.Windows.Forms.MouseEventHandler(this.dgvRevenueDetail_MouseMove);
            // 
            // chartRevenue
            // 
            this.chartRevenue.BorderlineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.DashDot;
            chartArea1.Name = "ChartArea1";
            this.chartRevenue.ChartAreas.Add(chartArea1);
            legend1.Enabled = false;
            legend1.Name = "Legend1";
            this.chartRevenue.Legends.Add(legend1);
            this.chartRevenue.Location = new System.Drawing.Point(6, 222);
            this.chartRevenue.Name = "chartRevenue";
            series1.ChartArea = "ChartArea1";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series1.Legend = "Legend1";
            series1.Name = "Revenue";
            this.chartRevenue.Series.Add(series1);
            this.chartRevenue.Size = new System.Drawing.Size(1220, 840);
            this.chartRevenue.TabIndex = 0;
            this.chartRevenue.Text = "chart1";
            this.chartRevenue.MouseMove += new System.Windows.Forms.MouseEventHandler(this.dgvRevenueDetail_MouseMove);
            // 
            // tabStaff
            // 
            this.tabStaff.BackColor = System.Drawing.Color.White;
            this.tabStaff.Controls.Add(this.dgvStaffList);
            this.tabStaff.Controls.Add(this.linkLabelCancelEditStaff);
            this.tabStaff.Controls.Add(this.buttonEditStaff);
            this.tabStaff.Controls.Add(this.buttonCreateNewStaff);
            this.tabStaff.Controls.Add(this.checkBoxShowInactiveAcc);
            this.tabStaff.Controls.Add(this.buttonDeleteStaff);
            this.tabStaff.Controls.Add(this.buttonSaveChanges);
            this.tabStaff.Controls.Add(this.buttonAddStaff);
            this.tabStaff.Controls.Add(this.comboBoxWorkingStatus);
            this.tabStaff.Controls.Add(this.labelWorkingStatus);
            this.tabStaff.Controls.Add(this.labelAuthorityLevel);
            this.tabStaff.Controls.Add(this.checkBoxShowPassword);
            this.tabStaff.Controls.Add(this.labelPassword);
            this.tabStaff.Controls.Add(this.labelUsername);
            this.tabStaff.Controls.Add(this.labelEmail);
            this.tabStaff.Controls.Add(this.labelPhoneNumber);
            this.tabStaff.Controls.Add(this.labelStaffName);
            this.tabStaff.Controls.Add(this.textBoxSearchStaff);
            this.tabStaff.Controls.Add(this.comboBoxAuthorityLevel);
            this.tabStaff.Controls.Add(this.labelStaffId);
            this.tabStaff.Controls.Add(this.textBoxStaffName);
            this.tabStaff.Controls.Add(this.textBoxPhoneNumber);
            this.tabStaff.Controls.Add(this.textBoxEmail);
            this.tabStaff.Controls.Add(this.textBoxPassword);
            this.tabStaff.Controls.Add(this.textBoxUsername);
            this.tabStaff.Location = new System.Drawing.Point(8, 53);
            this.tabStaff.Name = "tabStaff";
            this.tabStaff.Padding = new System.Windows.Forms.Padding(3);
            this.tabStaff.Size = new System.Drawing.Size(1878, 1068);
            this.tabStaff.TabIndex = 1;
            this.tabStaff.Text = "Staff Management";
            // 
            // dgvStaffList
            // 
            this.dgvStaffList.AllowUserToAddRows = false;
            this.dgvStaffList.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dgvStaffList.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvStaffList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgvStaffList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.875F);
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvStaffList.DefaultCellStyle = dataGridViewCellStyle4;
            this.dgvStaffList.Location = new System.Drawing.Point(612, 102);
            this.dgvStaffList.MultiSelect = false;
            this.dgvStaffList.Name = "dgvStaffList";
            this.dgvStaffList.ReadOnly = true;
            this.dgvStaffList.RowHeadersWidth = 82;
            this.dgvStaffList.RowTemplate.Height = 33;
            this.dgvStaffList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvStaffList.Size = new System.Drawing.Size(1260, 960);
            this.dgvStaffList.TabIndex = 73;
            this.dgvStaffList.SelectionChanged += new System.EventHandler(this.dgvStaffList_SelectionChanged);
            // 
            // linkLabelCancelEditStaff
            // 
            this.linkLabelCancelEditStaff.AutoSize = true;
            this.linkLabelCancelEditStaff.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.linkLabelCancelEditStaff.LinkColor = System.Drawing.Color.DeepSkyBlue;
            this.linkLabelCancelEditStaff.Location = new System.Drawing.Point(418, 18);
            this.linkLabelCancelEditStaff.Name = "linkLabelCancelEditStaff";
            this.linkLabelCancelEditStaff.Size = new System.Drawing.Size(149, 37);
            this.linkLabelCancelEditStaff.TabIndex = 72;
            this.linkLabelCancelEditStaff.TabStop = true;
            this.linkLabelCancelEditStaff.Text = "Cancel edit";
            this.linkLabelCancelEditStaff.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabelCancelEditStaff_LinkClicked);
            // 
            // buttonEditStaff
            // 
            this.buttonEditStaff.BackColor = System.Drawing.Color.MediumOrchid;
            this.buttonEditStaff.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonEditStaff.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.buttonEditStaff.ForeColor = System.Drawing.Color.White;
            this.buttonEditStaff.Location = new System.Drawing.Point(212, 6);
            this.buttonEditStaff.Name = "buttonEditStaff";
            this.buttonEditStaff.Size = new System.Drawing.Size(200, 60);
            this.buttonEditStaff.TabIndex = 71;
            this.buttonEditStaff.Text = "Edit Staff";
            this.buttonEditStaff.UseVisualStyleBackColor = false;
            this.buttonEditStaff.Click += new System.EventHandler(this.buttonEditStaff_Click);
            // 
            // buttonCreateNewStaff
            // 
            this.buttonCreateNewStaff.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.buttonCreateNewStaff.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonCreateNewStaff.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.buttonCreateNewStaff.ForeColor = System.Drawing.Color.White;
            this.buttonCreateNewStaff.Location = new System.Drawing.Point(6, 6);
            this.buttonCreateNewStaff.Name = "buttonCreateNewStaff";
            this.buttonCreateNewStaff.Size = new System.Drawing.Size(200, 60);
            this.buttonCreateNewStaff.TabIndex = 64;
            this.buttonCreateNewStaff.Text = "New Staff";
            this.buttonCreateNewStaff.UseVisualStyleBackColor = false;
            this.buttonCreateNewStaff.Click += new System.EventHandler(this.buttonCreateNewStaff_Click);
            // 
            // checkBoxShowInactiveAcc
            // 
            this.checkBoxShowInactiveAcc.AutoSize = true;
            this.checkBoxShowInactiveAcc.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.checkBoxShowInactiveAcc.Location = new System.Drawing.Point(612, 55);
            this.checkBoxShowInactiveAcc.Name = "checkBoxShowInactiveAcc";
            this.checkBoxShowInactiveAcc.Size = new System.Drawing.Size(323, 41);
            this.checkBoxShowInactiveAcc.TabIndex = 22;
            this.checkBoxShowInactiveAcc.Text = "Show inactive accounts";
            this.checkBoxShowInactiveAcc.UseVisualStyleBackColor = true;
            this.checkBoxShowInactiveAcc.CheckedChanged += new System.EventHandler(this.checkBoxShowInactiveAcc_CheckedChanged);
            // 
            // buttonDeleteStaff
            // 
            this.buttonDeleteStaff.BackColor = System.Drawing.Color.LightCoral;
            this.buttonDeleteStaff.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonDeleteStaff.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.buttonDeleteStaff.ForeColor = System.Drawing.Color.White;
            this.buttonDeleteStaff.Location = new System.Drawing.Point(417, 1002);
            this.buttonDeleteStaff.Name = "buttonDeleteStaff";
            this.buttonDeleteStaff.Size = new System.Drawing.Size(150, 60);
            this.buttonDeleteStaff.TabIndex = 21;
            this.buttonDeleteStaff.Text = "Delete";
            this.buttonDeleteStaff.UseVisualStyleBackColor = false;
            this.buttonDeleteStaff.Click += new System.EventHandler(this.buttonDeleteStaff_Click);
            // 
            // buttonSaveChanges
            // 
            this.buttonSaveChanges.BackColor = System.Drawing.Color.LimeGreen;
            this.buttonSaveChanges.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSaveChanges.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.buttonSaveChanges.ForeColor = System.Drawing.Color.White;
            this.buttonSaveChanges.Location = new System.Drawing.Point(6, 1002);
            this.buttonSaveChanges.Name = "buttonSaveChanges";
            this.buttonSaveChanges.Size = new System.Drawing.Size(150, 60);
            this.buttonSaveChanges.TabIndex = 20;
            this.buttonSaveChanges.Text = "Save";
            this.buttonSaveChanges.UseVisualStyleBackColor = false;
            this.buttonSaveChanges.Click += new System.EventHandler(this.buttonSaveChanges_Click);
            // 
            // buttonAddStaff
            // 
            this.buttonAddStaff.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.buttonAddStaff.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAddStaff.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.buttonAddStaff.ForeColor = System.Drawing.Color.White;
            this.buttonAddStaff.Location = new System.Drawing.Point(162, 1002);
            this.buttonAddStaff.Name = "buttonAddStaff";
            this.buttonAddStaff.Size = new System.Drawing.Size(150, 60);
            this.buttonAddStaff.TabIndex = 19;
            this.buttonAddStaff.Text = "Add";
            this.buttonAddStaff.UseVisualStyleBackColor = false;
            this.buttonAddStaff.Click += new System.EventHandler(this.buttonAddStaff_Click);
            // 
            // comboBoxWorkingStatus
            // 
            this.comboBoxWorkingStatus.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.comboBoxWorkingStatus.FormattingEnabled = true;
            this.comboBoxWorkingStatus.Location = new System.Drawing.Point(221, 546);
            this.comboBoxWorkingStatus.Name = "comboBoxWorkingStatus";
            this.comboBoxWorkingStatus.Size = new System.Drawing.Size(350, 45);
            this.comboBoxWorkingStatus.TabIndex = 17;
            this.comboBoxWorkingStatus.Text = "Auto Get Status";
            // 
            // labelWorkingStatus
            // 
            this.labelWorkingStatus.AutoSize = true;
            this.labelWorkingStatus.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.labelWorkingStatus.Location = new System.Drawing.Point(6, 549);
            this.labelWorkingStatus.Name = "labelWorkingStatus";
            this.labelWorkingStatus.Size = new System.Drawing.Size(208, 37);
            this.labelWorkingStatus.TabIndex = 16;
            this.labelWorkingStatus.Text = "Working Status: ";
            // 
            // labelAuthorityLevel
            // 
            this.labelAuthorityLevel.AutoSize = true;
            this.labelAuthorityLevel.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.labelAuthorityLevel.Location = new System.Drawing.Point(6, 489);
            this.labelAuthorityLevel.Name = "labelAuthorityLevel";
            this.labelAuthorityLevel.Size = new System.Drawing.Size(208, 37);
            this.labelAuthorityLevel.TabIndex = 15;
            this.labelAuthorityLevel.Text = "Authority Level: ";
            // 
            // checkBoxShowPassword
            // 
            this.checkBoxShowPassword.AutoSize = true;
            this.checkBoxShowPassword.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.checkBoxShowPassword.Location = new System.Drawing.Point(221, 424);
            this.checkBoxShowPassword.Name = "checkBoxShowPassword";
            this.checkBoxShowPassword.Size = new System.Drawing.Size(234, 41);
            this.checkBoxShowPassword.TabIndex = 14;
            this.checkBoxShowPassword.Text = "Show password";
            this.checkBoxShowPassword.UseVisualStyleBackColor = true;
            this.checkBoxShowPassword.CheckedChanged += new System.EventHandler(this.checkBoxShowPassword_CheckedChanged);
            // 
            // labelPassword
            // 
            this.labelPassword.AutoSize = true;
            this.labelPassword.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.labelPassword.Location = new System.Drawing.Point(6, 369);
            this.labelPassword.Name = "labelPassword";
            this.labelPassword.Size = new System.Drawing.Size(141, 37);
            this.labelPassword.TabIndex = 13;
            this.labelPassword.Text = "Password: ";
            // 
            // labelUsername
            // 
            this.labelUsername.AutoSize = true;
            this.labelUsername.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.labelUsername.Location = new System.Drawing.Point(6, 309);
            this.labelUsername.Name = "labelUsername";
            this.labelUsername.Size = new System.Drawing.Size(149, 37);
            this.labelUsername.TabIndex = 12;
            this.labelUsername.Text = "Username: ";
            // 
            // labelEmail
            // 
            this.labelEmail.AutoSize = true;
            this.labelEmail.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.labelEmail.Location = new System.Drawing.Point(6, 249);
            this.labelEmail.Name = "labelEmail";
            this.labelEmail.Size = new System.Drawing.Size(95, 37);
            this.labelEmail.TabIndex = 11;
            this.labelEmail.Text = "Email: ";
            // 
            // labelPhoneNumber
            // 
            this.labelPhoneNumber.AutoSize = true;
            this.labelPhoneNumber.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.labelPhoneNumber.Location = new System.Drawing.Point(6, 189);
            this.labelPhoneNumber.Name = "labelPhoneNumber";
            this.labelPhoneNumber.Size = new System.Drawing.Size(209, 37);
            this.labelPhoneNumber.TabIndex = 10;
            this.labelPhoneNumber.Text = "Phone Number: ";
            // 
            // labelStaffName
            // 
            this.labelStaffName.AutoSize = true;
            this.labelStaffName.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.labelStaffName.Location = new System.Drawing.Point(6, 129);
            this.labelStaffName.Name = "labelStaffName";
            this.labelStaffName.Size = new System.Drawing.Size(160, 37);
            this.labelStaffName.TabIndex = 9;
            this.labelStaffName.Text = "Staff Name: ";
            // 
            // textBoxSearchStaff
            // 
            this.textBoxSearchStaff.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.textBoxSearchStaff.Location = new System.Drawing.Point(612, 6);
            this.textBoxSearchStaff.Name = "textBoxSearchStaff";
            this.textBoxSearchStaff.Size = new System.Drawing.Size(1260, 43);
            this.textBoxSearchStaff.TabIndex = 8;
            this.textBoxSearchStaff.Text = "Search Staff";
            this.textBoxSearchStaff.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxSearchStaff.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxSearchStaff_KeyDown);
            // 
            // comboBoxAuthorityLevel
            // 
            this.comboBoxAuthorityLevel.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.comboBoxAuthorityLevel.FormattingEnabled = true;
            this.comboBoxAuthorityLevel.Location = new System.Drawing.Point(221, 489);
            this.comboBoxAuthorityLevel.Name = "comboBoxAuthorityLevel";
            this.comboBoxAuthorityLevel.Size = new System.Drawing.Size(350, 45);
            this.comboBoxAuthorityLevel.TabIndex = 7;
            this.comboBoxAuthorityLevel.Text = "Select Level";
            // 
            // labelStaffId
            // 
            this.labelStaffId.AutoSize = true;
            this.labelStaffId.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.labelStaffId.Location = new System.Drawing.Point(6, 69);
            this.labelStaffId.Name = "labelStaffId";
            this.labelStaffId.Size = new System.Drawing.Size(112, 37);
            this.labelStaffId.TabIndex = 6;
            this.labelStaffId.Text = "Staff Id: ";
            // 
            // textBoxStaffName
            // 
            this.textBoxStaffName.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.textBoxStaffName.Location = new System.Drawing.Point(221, 126);
            this.textBoxStaffName.Name = "textBoxStaffName";
            this.textBoxStaffName.Size = new System.Drawing.Size(350, 43);
            this.textBoxStaffName.TabIndex = 5;
            // 
            // textBoxPhoneNumber
            // 
            this.textBoxPhoneNumber.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.textBoxPhoneNumber.Location = new System.Drawing.Point(221, 186);
            this.textBoxPhoneNumber.Name = "textBoxPhoneNumber";
            this.textBoxPhoneNumber.Size = new System.Drawing.Size(350, 43);
            this.textBoxPhoneNumber.TabIndex = 4;
            // 
            // textBoxEmail
            // 
            this.textBoxEmail.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.textBoxEmail.Location = new System.Drawing.Point(221, 246);
            this.textBoxEmail.Name = "textBoxEmail";
            this.textBoxEmail.Size = new System.Drawing.Size(350, 43);
            this.textBoxEmail.TabIndex = 3;
            // 
            // textBoxPassword
            // 
            this.textBoxPassword.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.textBoxPassword.Location = new System.Drawing.Point(221, 366);
            this.textBoxPassword.Name = "textBoxPassword";
            this.textBoxPassword.Size = new System.Drawing.Size(350, 43);
            this.textBoxPassword.TabIndex = 2;
            // 
            // textBoxUsername
            // 
            this.textBoxUsername.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.textBoxUsername.Location = new System.Drawing.Point(221, 306);
            this.textBoxUsername.Name = "textBoxUsername";
            this.textBoxUsername.Size = new System.Drawing.Size(350, 43);
            this.textBoxUsername.TabIndex = 1;
            // 
            // AdminDashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1894, 1129);
            this.Controls.Add(this.tabAdmin);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "AdminDashboard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Admin Dashboard";
            this.Load += new System.EventHandler(this.AdminDashboard_Load);
            this.tabAdmin.ResumeLayout(false);
            this.tabPageRevenue.ResumeLayout(false);
            this.panelTodayRevenue.ResumeLayout(false);
            this.panelTodayRevenue.PerformLayout();
            this.panelMonthRevenue.ResumeLayout(false);
            this.panelMonthRevenue.PerformLayout();
            this.panelYesterdayRevenue.ResumeLayout(false);
            this.panelYesterdayRevenue.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDetailedRevenue)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartRevenue)).EndInit();
            this.tabStaff.ResumeLayout(false);
            this.tabStaff.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvStaffList)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabAdmin;
        private System.Windows.Forms.TabPage tabPageRevenue;
        private System.Windows.Forms.TabPage tabStaff;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartRevenue;
        private System.Windows.Forms.DataGridView dgvDetailedRevenue;
        private System.Windows.Forms.Label labelYesterdayRevenue;
        private System.Windows.Forms.Label labelYesterdayRevenueTitle;
        private System.Windows.Forms.Panel panelYesterdayRevenue;
        private System.Windows.Forms.Panel panelMonthRevenue;
        private System.Windows.Forms.Label labelMonthRevenue;
        private System.Windows.Forms.Label labelMonthRevenueTitle;
        private System.Windows.Forms.Panel panelTodayRevenue;
        private System.Windows.Forms.Label labelTodayRevenue;
        private System.Windows.Forms.Label labelTodayRevenueTitle;
        private System.Windows.Forms.TextBox textBoxUsername;
        private System.Windows.Forms.TextBox textBoxPhoneNumber;
        private System.Windows.Forms.TextBox textBoxEmail;
        private System.Windows.Forms.TextBox textBoxPassword;
        private System.Windows.Forms.ComboBox comboBoxAuthorityLevel;
        private System.Windows.Forms.Label labelStaffId;
        private System.Windows.Forms.TextBox textBoxStaffName;
        private System.Windows.Forms.Label labelPhoneNumber;
        private System.Windows.Forms.Label labelStaffName;
        private System.Windows.Forms.TextBox textBoxSearchStaff;
        private System.Windows.Forms.Label labelUsername;
        private System.Windows.Forms.Label labelEmail;
        private System.Windows.Forms.CheckBox checkBoxShowPassword;
        private System.Windows.Forms.Label labelPassword;
        private System.Windows.Forms.ComboBox comboBoxWorkingStatus;
        private System.Windows.Forms.Label labelWorkingStatus;
        private System.Windows.Forms.Label labelAuthorityLevel;
        private System.Windows.Forms.Button buttonAddStaff;
        private System.Windows.Forms.Button buttonDeleteStaff;
        private System.Windows.Forms.Button buttonSaveChanges;
        private System.Windows.Forms.CheckBox checkBoxShowInactiveAcc;
        private System.Windows.Forms.Button buttonCreateNewStaff;
        private System.Windows.Forms.Button buttonEditStaff;
        private System.Windows.Forms.LinkLabel linkLabelCancelEditStaff;
        private System.Windows.Forms.DataGridView dgvStaffList;
    }
}