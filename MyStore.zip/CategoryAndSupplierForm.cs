﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace My_Store
{
    public partial class CategoryAndSupplierForm : Form
    {
        private string connectionString;
        private int selectedCategoryId = -1;
        private int selectedSupplierId = -1;
        private bool isUsingShowDeletedCategory = false;
        private bool isUsingShowDeletedSupplier = false;
        public CategoryAndSupplierForm()
        {
            InitializeComponent();
            this.connectionString = ConfigurationManager.ConnectionStrings["StoreMNGConnectionString"].ConnectionString;
        }

        private void CategoryAndSupplierForm_Load(object sender, EventArgs e)
        {
            dgvCategoryList.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvSupplierList.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            loadCategoryData();
            loadSupplierData();
            clearCategoryDetails();
            clearSupplierDetails();
            switchCategoryMode("view");
            switchSupplierMode("view");
        }

        #region Load hien thi
        // Load category data
        private void loadCategoryData()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    string query;
                    if (isUsingShowDeletedCategory)
                    {
                        query = @"
                        SELECT
                            categoryId AS ID,
                            categoryName AS Name,
                            categoryDescription AS Description
                        FROM
                            Category
                        ORDER BY categoryId DESC";
                    }
                    else
                    {
                        query = @"
                        SELECT
                            categoryId AS ID,
                            categoryName AS Name,
                            categoryDescription AS Description
                        FROM
                            Category
                        WHERE categoryName NOT LIKE 'Category[0-9]%'
                        ORDER BY categoryId DESC";
                    }

                    SqlDataAdapter categoryAdapter = new SqlDataAdapter(query, connection);
                    DataTable categoryData = new DataTable();
                    categoryAdapter.Fill(categoryData);
                    dgvCategoryList.DataSource = categoryData;
                    dgvCategoryList.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

                }
                catch (Exception ex)
                {
                    MessageBox.Show("Loading category data failed: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        // Load Supplier data
        private void loadSupplierData()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    string query;
                    if (isUsingShowDeletedSupplier)
                    {
                        query = @"
                        SELECT
                            supplierId AS ID,
                            supplierName AS Name,
                            supplierPhoneNumber AS Phone,
                            supplierEmail AS Email,
                            supplierAddress AS Address
                        FROM
                            Supplier
                        ORDER BY supplierId DESC";
                    }
                    else
                    {
                        query = @"
                        SELECT
                            supplierId AS ID,
                            supplierName AS Name,
                            supplierPhoneNumber AS Phone,
                            supplierEmail AS Email,
                            supplierAddress AS Address
                        FROM
                            Supplier
                        WHERE supplierName != 'Deleted Supplier'
                        ORDER BY supplierId DESC";
                    }

                    SqlDataAdapter supplierAdapter = new SqlDataAdapter(query, connection);
                    DataTable supplierData = new DataTable();
                    supplierAdapter.Fill(supplierData);
                    dgvSupplierList.DataSource = supplierData;
                    dgvSupplierList.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

                }

                catch (Exception ex)
                {
                    MessageBox.Show("Loading supplier data failed: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        #endregion

        #region Lay du lieu tu bang
        // Khi click vao bang category
        private void dgvCategoryList_SelectionChanged(object sender, EventArgs e)
        {
            if(dgvCategoryList.CurrentRow != null && dgvCategoryList.CurrentRow.Index >= 0)
            {
                DataGridViewRow row = dgvCategoryList.CurrentRow;
                selectedCategoryId = Convert.ToInt32(row.Cells["ID"].Value);

                labelCategoryId.Text = "Category Id: " + selectedCategoryId.ToString();
                textBoxCategoryName.Text = row.Cells["Name"].Value.ToString();
                richTextBoxDescription.Text = row.Cells["Description"].Value.ToString();
            }
        }

        // Khi click vao bang supplier
        private void dgvSupplierList_SelectionChanged(object sender, EventArgs e)
        {
            if(dgvSupplierList.CurrentRow != null && dgvSupplierList.CurrentRow.Index >= 0)
            {
                DataGridViewRow row = dgvSupplierList.CurrentRow;
                selectedSupplierId = Convert.ToInt32(row.Cells["ID"].Value);

                labelSupplierId.Text = "Supplier Id: " + selectedSupplierId.ToString();
                textBoxSupplierName.Text = row.Cells["Name"].Value.ToString();
                textBoxSupplierPhoneNumber.Text = row.Cells["Phone"].Value.ToString();
                textBoxSuppierEmail.Text = row.Cells["Email"].Value.ToString();
                richTextBoxAddress.Text = row.Cells["Address"].Value.ToString();
            }
        }
        #endregion

        #region Edit Category
        private void clearCategoryDetails()
        {
            labelCategoryId.Text = "Category Id: <Auto Generate>";
            textBoxCategoryName.Clear();
            richTextBoxDescription.Text = "No description";
            selectedCategoryId = -1;
        }

        private void switchCategoryMode(string modeName)
        {
            switch (modeName)
            {
                case "view":
                    // Block 1. TextBox                   
                    textBoxCategoryName.Enabled = false;
                    richTextBoxDescription.Enabled = false;

                    // Block 2. Button
                    buttonCreateNewCategory.Enabled = true;
                    buttonEditCategory.Enabled = true;

                    buttonAddCategory.Enabled = false;
                    buttonSaveCategory.Enabled = false;
                    buttonDeleteCategory.Enabled = false;
                    linkLabelCancelEditCategory.Enabled = false;

                    // Block 3. dgv Table 
                    dgvCategoryList.Enabled = true;
                    textBoxSearchCategory.Enabled = true;

                    break;

                case "edit":
                    // Block 1. TextBox                   
                    textBoxCategoryName.Enabled = true;
                    richTextBoxDescription.Enabled = true;

                    // Block 2. Button
                    buttonCreateNewCategory.Enabled = false;
                    buttonEditCategory.Enabled = false;

                    buttonAddCategory.Enabled = false;
                    buttonSaveCategory.Enabled = true;
                    buttonDeleteCategory.Enabled = true;
                    linkLabelCancelEditCategory.Enabled = true;

                    // Block 3. dgv Table 
                    dgvCategoryList.Enabled = true;
                    textBoxSearchCategory.Enabled = true;

                    break;

                case "add":
                    // Block 1. TextBox                   
                    textBoxCategoryName.Enabled = true;
                    richTextBoxDescription.Enabled = true;

                    // Block 2. Button
                    buttonCreateNewCategory.Enabled = false;
                    buttonEditCategory.Enabled = false;

                    buttonAddCategory.Enabled = true;
                    buttonSaveCategory.Enabled = false;
                    buttonDeleteCategory.Enabled = false;
                    linkLabelCancelEditCategory.Enabled = true;

                    // Block 3. dgv Table 
                    dgvCategoryList.Enabled = false;
                    textBoxSearchCategory.Enabled = false;

                    break;

                default:
                    switchCategoryMode("view");
                    break;
            }
        }

        private void buttonCreateNewCategory_Click(object sender, EventArgs e)
        {
            switchCategoryMode("add");
            clearCategoryDetails();
        }

        private void buttonEditCategory_Click(object sender, EventArgs e)
        {
            if (selectedCategoryId == -1)
            {
                MessageBox.Show("Please select a category member from the list to update.", "Selection Required", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            switchCategoryMode("edit");
        }

        private void linkLabelCancelEditCategory_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            switchCategoryMode("view");
        }

        // Tạo category mới
        private void buttonAddCategory_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBoxCategoryName.Text) ||
                string.IsNullOrWhiteSpace(richTextBoxDescription.Text))
            {
                MessageBox.Show("Please fill in all category details.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    string query = @"
                        INSERT INTO Category (categoryName, categoryDescription)
                        VALUES (@categoryName, @categoryDescription);
                        SELECT SCOPE_IDENTITY();";

                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@categoryName", textBoxCategoryName.Text);
                    command.Parameters.AddWithValue("@categoryDescription", richTextBoxDescription.Text);
                    selectedCategoryId = Convert.ToInt32(command.ExecuteScalar());

                    MessageBox.Show("Category added successfully! ID: " + selectedCategoryId, "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    
                    loadCategoryData();
                    switchCategoryMode("view");

                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error adding category: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        // Lưu cập nhật thay đổi dữ liệu category
        private void buttonSaveCategory_Click(object sender, EventArgs e)
        {
            if (selectedCategoryId == -1)
            {
                MessageBox.Show("Please select a category member from the list to update.", "Selection Required", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            if (string.IsNullOrWhiteSpace(textBoxCategoryName.Text) ||
                string.IsNullOrWhiteSpace(richTextBoxDescription.Text))
            {
                MessageBox.Show("Please fill in all category details.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    string query = @"
                        UPDATE Category SET
                            categoryName = @categoryName,
                            categoryDescription = @categoryDescription
                        WHERE categoryId = @categoryId";

                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@categoryId", selectedCategoryId);
                    command.Parameters.AddWithValue("@categoryName", textBoxCategoryName.Text);
                    command.Parameters.AddWithValue("@categoryDescription", richTextBoxDescription.Text);
                    command.ExecuteNonQuery();

                    MessageBox.Show("Category updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    
                    loadCategoryData();
                    switchCategoryMode("view");

                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error updating category: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        // Xóa dữ liệu category
        private void buttonDeleteCategory_Click(object sender, EventArgs e)
        {
            buttonCreateNewCategory.Enabled = true;
            buttonEditCategory.Enabled = true;
            dgvCategoryList.Enabled = true;

            if (selectedCategoryId == -1)
            {
                MessageBox.Show("Please select a category member from the list to 'soft delete'.", "Selection Required", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            if (MessageBox.Show($"Are you sure you want to mark category ID {selectedCategoryId} as 'Deleted category'?", "Confirm Soft Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    try
                    {
                        connection.Open();
                        string query = @"
                            UPDATE Category SET
                                categoryName = 'Category' + RIGHT('0000000000' + CONVERT(NVARCHAR, categoryId), 10),
                                categoryDescription = 'No description'
                            WHERE categoryId = @categoryId";

                        SqlCommand command = new SqlCommand(query, connection);
                        command.Parameters.AddWithValue("@categoryId", selectedCategoryId);
                        command.ExecuteNonQuery();

                        MessageBox.Show("Category marked as 'Deleted Category' successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                               
                        loadCategoryData();
                        clearCategoryDetails();
                        switchCategoryMode("view");

                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error marking category as 'Deleted': " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        // Phuong thuc tim kiem category
        private void searchCategory(string keyword)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    string query = @"
                        SELECT categoryId AS [ID], categoryName AS [Name], categoryDescription AS [Description]
                        FROM Category
                        WHERE ((categoryId LIKE @keyword OR categoryName LIKE @keyword) AND categoryName NOT LIKE 'Category[0-9]%')";

                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@keyword", $"%{keyword}%");

                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable resultTable = new DataTable();
                    adapter.Fill(resultTable);

                    dgvCategoryList.DataSource = resultTable;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Search failed: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        // Tìm kiếm category qua Id, tên
        private void textBoxSearchCategory_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.Handled = true;
                e.SuppressKeyPress = true;

                string keyword = textBoxSearchCategory.Text.Trim();
                if (string.IsNullOrEmpty(keyword))
                {
                    //MessageBox.Show("Please input item information", "Input Required", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    loadCategoryData();
                    return;
                }
                searchCategory(keyword);
            }
        }

        #endregion

        #region Edit Supplier
        private void clearSupplierDetails()
        {
            labelSupplierId.Text = "Supplier Id: <Auto Generate>";
            textBoxSupplierName.Clear();
            textBoxSupplierPhoneNumber.Clear();
            textBoxSuppierEmail.Clear();
            richTextBoxAddress.Clear();
            selectedSupplierId = -1;
        }

        private void switchSupplierMode(string modeName)
        {
            switch (modeName)
            {
                case "view":
                    // Block 1. TextBox
                    textBoxSupplierName.Enabled = false;
                    textBoxSupplierPhoneNumber.Enabled = false;
                    textBoxSuppierEmail.Enabled = false;
                    richTextBoxAddress.Enabled = false;

                    // Block 2. Button
                    buttonCreateNewSupplier.Enabled = true;
                    buttonEditSupplier.Enabled = true;

                    buttonAddSupplier.Enabled = false;
                    buttonSaveSupplier.Enabled = false;
                    buttonDeleteSupplier.Enabled = false;
                    linkLabelCancelEditSupplier.Enabled = false;

                    // Block 3. dgv Table 
                    dgvSupplierList.Enabled = true;
                    textBoxSearchSupplier.Enabled = true;
                    break;

                case "edit":
                    // Block 1. TextBox
                    textBoxSupplierName.Enabled = true;
                    textBoxSupplierPhoneNumber.Enabled = true;
                    textBoxSuppierEmail.Enabled = true;
                    richTextBoxAddress.Enabled = true;

                    // Block 2. Button
                    buttonCreateNewSupplier.Enabled = false;
                    buttonEditSupplier.Enabled = false;

                    buttonAddSupplier.Enabled = false;
                    buttonSaveSupplier.Enabled = true;
                    buttonDeleteSupplier.Enabled = true;
                    linkLabelCancelEditSupplier.Enabled = true;

                    // Block 3. dgv Table 
                    dgvSupplierList.Enabled = true;
                    textBoxSearchSupplier.Enabled = true;
                    break;

                case "add":
                    // Block 1. TextBox
                    textBoxSupplierName.Enabled = true;
                    textBoxSupplierPhoneNumber.Enabled = true;
                    textBoxSuppierEmail.Enabled = true;
                    richTextBoxAddress.Enabled = true;

                    // Block 2. Button
                    buttonCreateNewSupplier.Enabled = false;
                    buttonEditSupplier.Enabled = false;

                    buttonAddSupplier.Enabled = true;
                    buttonSaveSupplier.Enabled = false;
                    buttonDeleteSupplier.Enabled = false;
                    linkLabelCancelEditSupplier.Enabled = true;

                    // Block 3. dgv Table 
                    dgvSupplierList.Enabled = false;
                    textBoxSearchSupplier.Enabled = false;
                    break;

                default:
                    switchSupplierMode("view");
                    break;
            }
        }

        private void buttonCreateNewSupplier_Click(object sender, EventArgs e)
        {
            switchSupplierMode("add");
            clearSupplierDetails();
        }

        private void buttonEditSupplier_Click(object sender, EventArgs e)
        {
            if (selectedSupplierId == -1)
            {
                MessageBox.Show("Please select a supplier member from the list to update.", "Selection Required", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            switchSupplierMode("edit");
        }

        private void linkLabelCancelEditSupplier_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            switchSupplierMode("view");
        }

        // Thêm nhà cung cấp mới
        private void buttonAddSupplier_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBoxSupplierName.Text) ||
                string.IsNullOrWhiteSpace(textBoxSupplierPhoneNumber.Text) ||
                string.IsNullOrWhiteSpace(textBoxSuppierEmail.Text) ||
                string.IsNullOrWhiteSpace(richTextBoxAddress.Text))
            {
                MessageBox.Show("Please fill in all supplier details.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    string query = @"
                        INSERT INTO Supplier (supplierName, supplierPhoneNumber, supplierEmail, supplierAddress)
                        VALUES (@supplierName, @supplierPhoneNumber, @supplierEmail, @supplierAddress);
                        SELECT SCOPE_IDENTITY();";

                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@supplierName", textBoxSupplierName.Text);
                    command.Parameters.AddWithValue("@supplierPhoneNumber", textBoxSupplierPhoneNumber.Text);
                    command.Parameters.AddWithValue("@supplierEmail", textBoxSuppierEmail.Text);
                    command.Parameters.AddWithValue("@supplierAddress", richTextBoxAddress.Text);

                    selectedCategoryId = Convert.ToInt32(command.ExecuteScalar());

                    MessageBox.Show("Supplier added successfully! ID: " + selectedCategoryId, "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    
                    loadSupplierData();
                    switchSupplierMode("view");
                    
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error adding supplier: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        // Lưu cập nhật dữ liệu nhà cung cấp
        private void buttonSaveSupplier_Click(object sender, EventArgs e)
        {
            if (selectedSupplierId == -1)
            {
                MessageBox.Show("Please select a supplier member from the list to update.", "Selection Required", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            if (string.IsNullOrWhiteSpace(textBoxSupplierName.Text) ||
                string.IsNullOrWhiteSpace(textBoxSupplierPhoneNumber.Text) ||
                string.IsNullOrWhiteSpace(textBoxSuppierEmail.Text) ||
                string.IsNullOrWhiteSpace(richTextBoxAddress.Text))
            {
                MessageBox.Show("Please fill in all supplier details.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    string query = @"
                        UPDATE Supplier SET
                            supplierName = @supplierName,
                            supplierPhoneNumber = @supplierPhoneNumber,
                            supplierEmail = @supplierEmail,
                            supplierAddress = @supplierAddress
                        WHERE supplierId = @supplierId";

                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@supplierId", selectedSupplierId);
                    command.Parameters.AddWithValue("@supplierName", textBoxSupplierName.Text);
                    command.Parameters.AddWithValue("@supplierPhoneNumber", textBoxSupplierPhoneNumber.Text);
                    command.Parameters.AddWithValue("@supplierEmail", textBoxSuppierEmail.Text);
                    command.Parameters.AddWithValue("@supplierAddress", richTextBoxAddress.Text);
                    command.ExecuteNonQuery();

                    MessageBox.Show("Supplier updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    
                    loadSupplierData();
                    switchSupplierMode("view");

                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error updating supplier: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        // Xóa nhà cung cấp
        private void buttonDeleteSupplier_Click(object sender, EventArgs e)
        {
            if (selectedSupplierId == -1)
            {
                MessageBox.Show("Please select a supplier member from the list to 'soft delete'.", "Selection Required", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            if (MessageBox.Show($"Are you sure you want to mark supplier ID {selectedCategoryId} as 'Deleted supplier'?", "Confirm Soft Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    try
                    {
                        connection.Open();
                        string query = @"
                            UPDATE Supplier SET
                                supplierName = 'Deleted Supplier',
                                supplierPhoneNumber = RIGHT('0000000000' + CONVERT(NVARCHAR, supplierId), 10),
                                supplierEmail = 'deleted' + CONVERT(NVARCHAR, supplierId) + '@email.com',
                                supplierAddress = 'Deleted Address'
                            WHERE supplierId = @supplierId";

                        SqlCommand command = new SqlCommand(query, connection);
                        command.Parameters.AddWithValue("@supplierId", selectedSupplierId);
                        command.ExecuteNonQuery();
                        
                        MessageBox.Show("Supplier marked as 'Deleted Supplier' successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        
                        loadSupplierData();
                        clearSupplierDetails();
                        switchSupplierMode("view");

                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error marking supplier as 'Deleted': " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void searchSupplier(string keyword)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    string query = @"
                        SELECT supplierId AS [ID], supplierName AS [Name], supplierPhoneNumber AS [Phone],
                            supplierEmail AS [Email], supplierAddress AS [Address]
                        FROM Supplier
                        WHERE (
                            supplierId LIKE @keyword OR
                            supplierName LIKE @keyword OR
                            supplierPhoneNumber LIKE @keyword OR
                            supplierEmail LIKE @keyword
                        )";

                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@keyword", $"%{keyword}%");

                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable resultTable = new DataTable();
                    adapter.Fill(resultTable);

                    dgvSupplierList.DataSource = resultTable;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Search failed: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        // Tìm kiếm nhà cung cấp
        private void textBoxSearchSupplier_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.Handled = true;
                e.SuppressKeyPress = true;

                string keyword = textBoxSearchSupplier.Text.Trim();
                if (string.IsNullOrEmpty(keyword))
                {
                    loadSupplierData();
                    return;
                }
                searchSupplier(keyword);
            }
        }
        #endregion
    }
}