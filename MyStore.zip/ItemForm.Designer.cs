﻿namespace My_Store
{
    partial class ItemForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ItemForm));
            this.labelItemId = new System.Windows.Forms.Label();
            this.labelItemName = new System.Windows.Forms.Label();
            this.labelItemDescription = new System.Windows.Forms.Label();
            this.richTextBoxDescription = new System.Windows.Forms.RichTextBox();
            this.labelPrice = new System.Windows.Forms.Label();
            this.labelCategory = new System.Windows.Forms.Label();
            this.labelSupplier = new System.Windows.Forms.Label();
            this.labelQuantity = new System.Windows.Forms.Label();
            this.buttonSaveChanges = new System.Windows.Forms.Button();
            this.buttonAddItem = new System.Windows.Forms.Button();
            this.buttonDeleteItem = new System.Windows.Forms.Button();
            this.textBoxItemName = new System.Windows.Forms.TextBox();
            this.textBoxPrice = new System.Windows.Forms.TextBox();
            this.comboBoxCategory = new System.Windows.Forms.ComboBox();
            this.comboBoxSupplier = new System.Windows.Forms.ComboBox();
            this.numericUpDownQuantity = new System.Windows.Forms.NumericUpDown();
            this.textBoxSearchItem = new System.Windows.Forms.TextBox();
            this.checkBoxShowDeletedItem = new System.Windows.Forms.CheckBox();
            this.dgvItemList = new System.Windows.Forms.DataGridView();
            this.buttonCreateNewItem = new System.Windows.Forms.Button();
            this.buttonEditItem = new System.Windows.Forms.Button();
            this.linkLabelCancelEditItem = new System.Windows.Forms.LinkLabel();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.buttonExportAllItems = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownQuantity)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvItemList)).BeginInit();
            this.SuspendLayout();
            // 
            // labelItemId
            // 
            this.labelItemId.AutoSize = true;
            this.labelItemId.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.labelItemId.Location = new System.Drawing.Point(12, 75);
            this.labelItemId.Name = "labelItemId";
            this.labelItemId.Size = new System.Drawing.Size(113, 37);
            this.labelItemId.TabIndex = 8;
            this.labelItemId.Text = "Item Id: ";
            // 
            // labelItemName
            // 
            this.labelItemName.AutoSize = true;
            this.labelItemName.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.labelItemName.Location = new System.Drawing.Point(12, 135);
            this.labelItemName.Name = "labelItemName";
            this.labelItemName.Size = new System.Drawing.Size(161, 37);
            this.labelItemName.TabIndex = 9;
            this.labelItemName.Text = "Item Name: ";
            // 
            // labelItemDescription
            // 
            this.labelItemDescription.AutoSize = true;
            this.labelItemDescription.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.labelItemDescription.Location = new System.Drawing.Point(12, 195);
            this.labelItemDescription.Name = "labelItemDescription";
            this.labelItemDescription.Size = new System.Drawing.Size(165, 37);
            this.labelItemDescription.TabIndex = 10;
            this.labelItemDescription.Text = "Description: ";
            // 
            // richTextBoxDescription
            // 
            this.richTextBoxDescription.BackColor = System.Drawing.SystemColors.Control;
            this.richTextBoxDescription.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.richTextBoxDescription.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.richTextBoxDescription.Location = new System.Drawing.Point(19, 235);
            this.richTextBoxDescription.Name = "richTextBoxDescription";
            this.richTextBoxDescription.Size = new System.Drawing.Size(571, 250);
            this.richTextBoxDescription.TabIndex = 14;
            this.richTextBoxDescription.Text = "";
            // 
            // labelPrice
            // 
            this.labelPrice.AutoSize = true;
            this.labelPrice.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.labelPrice.Location = new System.Drawing.Point(12, 495);
            this.labelPrice.Name = "labelPrice";
            this.labelPrice.Size = new System.Drawing.Size(87, 37);
            this.labelPrice.TabIndex = 15;
            this.labelPrice.Text = "Price: ";
            // 
            // labelCategory
            // 
            this.labelCategory.AutoSize = true;
            this.labelCategory.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.labelCategory.Location = new System.Drawing.Point(12, 555);
            this.labelCategory.Name = "labelCategory";
            this.labelCategory.Size = new System.Drawing.Size(138, 37);
            this.labelCategory.TabIndex = 16;
            this.labelCategory.Text = "Category: ";
            // 
            // labelSupplier
            // 
            this.labelSupplier.AutoSize = true;
            this.labelSupplier.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.labelSupplier.Location = new System.Drawing.Point(12, 615);
            this.labelSupplier.Name = "labelSupplier";
            this.labelSupplier.Size = new System.Drawing.Size(128, 37);
            this.labelSupplier.TabIndex = 17;
            this.labelSupplier.Text = "Supplier: ";
            // 
            // labelQuantity
            // 
            this.labelQuantity.AutoSize = true;
            this.labelQuantity.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.labelQuantity.Location = new System.Drawing.Point(12, 675);
            this.labelQuantity.Name = "labelQuantity";
            this.labelQuantity.Size = new System.Drawing.Size(132, 37);
            this.labelQuantity.TabIndex = 18;
            this.labelQuantity.Text = "Quantity: ";
            // 
            // buttonSaveChanges
            // 
            this.buttonSaveChanges.BackColor = System.Drawing.Color.LimeGreen;
            this.buttonSaveChanges.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSaveChanges.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.buttonSaveChanges.ForeColor = System.Drawing.Color.White;
            this.buttonSaveChanges.Location = new System.Drawing.Point(10, 1057);
            this.buttonSaveChanges.Name = "buttonSaveChanges";
            this.buttonSaveChanges.Size = new System.Drawing.Size(150, 60);
            this.buttonSaveChanges.TabIndex = 22;
            this.buttonSaveChanges.Text = "Save";
            this.buttonSaveChanges.UseVisualStyleBackColor = false;
            this.buttonSaveChanges.Click += new System.EventHandler(this.buttonSaveChanges_Click);
            // 
            // buttonAddItem
            // 
            this.buttonAddItem.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.buttonAddItem.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAddItem.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.buttonAddItem.ForeColor = System.Drawing.Color.White;
            this.buttonAddItem.Location = new System.Drawing.Point(166, 1057);
            this.buttonAddItem.Name = "buttonAddItem";
            this.buttonAddItem.Size = new System.Drawing.Size(150, 60);
            this.buttonAddItem.TabIndex = 23;
            this.buttonAddItem.Text = "Add";
            this.buttonAddItem.UseVisualStyleBackColor = false;
            this.buttonAddItem.Click += new System.EventHandler(this.buttonAddItem_Click);
            // 
            // buttonDeleteItem
            // 
            this.buttonDeleteItem.BackColor = System.Drawing.Color.LightCoral;
            this.buttonDeleteItem.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonDeleteItem.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.buttonDeleteItem.ForeColor = System.Drawing.Color.White;
            this.buttonDeleteItem.Location = new System.Drawing.Point(440, 1057);
            this.buttonDeleteItem.Name = "buttonDeleteItem";
            this.buttonDeleteItem.Size = new System.Drawing.Size(150, 60);
            this.buttonDeleteItem.TabIndex = 24;
            this.buttonDeleteItem.Text = "Delete";
            this.buttonDeleteItem.UseVisualStyleBackColor = false;
            this.buttonDeleteItem.Click += new System.EventHandler(this.buttonDeleteItem_Click);
            // 
            // textBoxItemName
            // 
            this.textBoxItemName.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.textBoxItemName.Location = new System.Drawing.Point(240, 132);
            this.textBoxItemName.Name = "textBoxItemName";
            this.textBoxItemName.Size = new System.Drawing.Size(350, 43);
            this.textBoxItemName.TabIndex = 25;
            // 
            // textBoxPrice
            // 
            this.textBoxPrice.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.textBoxPrice.Location = new System.Drawing.Point(240, 492);
            this.textBoxPrice.Name = "textBoxPrice";
            this.textBoxPrice.Size = new System.Drawing.Size(350, 43);
            this.textBoxPrice.TabIndex = 26;
            // 
            // comboBoxCategory
            // 
            this.comboBoxCategory.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.comboBoxCategory.FormattingEnabled = true;
            this.comboBoxCategory.Location = new System.Drawing.Point(240, 552);
            this.comboBoxCategory.Name = "comboBoxCategory";
            this.comboBoxCategory.Size = new System.Drawing.Size(350, 45);
            this.comboBoxCategory.TabIndex = 27;
            this.comboBoxCategory.Text = "Select category";
            // 
            // comboBoxSupplier
            // 
            this.comboBoxSupplier.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.comboBoxSupplier.FormattingEnabled = true;
            this.comboBoxSupplier.Location = new System.Drawing.Point(240, 612);
            this.comboBoxSupplier.Name = "comboBoxSupplier";
            this.comboBoxSupplier.Size = new System.Drawing.Size(350, 45);
            this.comboBoxSupplier.TabIndex = 28;
            this.comboBoxSupplier.Text = "Select supplier";
            // 
            // numericUpDownQuantity
            // 
            this.numericUpDownQuantity.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.numericUpDownQuantity.Location = new System.Drawing.Point(240, 673);
            this.numericUpDownQuantity.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numericUpDownQuantity.Name = "numericUpDownQuantity";
            this.numericUpDownQuantity.Size = new System.Drawing.Size(350, 43);
            this.numericUpDownQuantity.TabIndex = 29;
            this.numericUpDownQuantity.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxSearchItem
            // 
            this.textBoxSearchItem.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.textBoxSearchItem.Location = new System.Drawing.Point(622, 12);
            this.textBoxSearchItem.Name = "textBoxSearchItem";
            this.textBoxSearchItem.Size = new System.Drawing.Size(1260, 43);
            this.textBoxSearchItem.TabIndex = 30;
            this.textBoxSearchItem.Text = "Search Item";
            this.textBoxSearchItem.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxSearchItem.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxSearchItem_KeyDown);
            // 
            // checkBoxShowDeletedItem
            // 
            this.checkBoxShowDeletedItem.AutoSize = true;
            this.checkBoxShowDeletedItem.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.checkBoxShowDeletedItem.Location = new System.Drawing.Point(622, 61);
            this.checkBoxShowDeletedItem.Name = "checkBoxShowDeletedItem";
            this.checkBoxShowDeletedItem.Size = new System.Drawing.Size(274, 41);
            this.checkBoxShowDeletedItem.TabIndex = 31;
            this.checkBoxShowDeletedItem.Text = "Show Deleted Item";
            this.checkBoxShowDeletedItem.UseVisualStyleBackColor = true;
            this.checkBoxShowDeletedItem.CheckedChanged += new System.EventHandler(this.checkBoxShowDeletedItem_CheckedChanged);
            // 
            // dgvItemList
            // 
            this.dgvItemList.AllowUserToAddRows = false;
            this.dgvItemList.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dgvItemList.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvItemList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvItemList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvItemList.Location = new System.Drawing.Point(622, 108);
            this.dgvItemList.MultiSelect = false;
            this.dgvItemList.Name = "dgvItemList";
            this.dgvItemList.ReadOnly = true;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 10F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvItemList.RowHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dgvItemList.RowHeadersWidth = 82;
            this.dgvItemList.RowTemplate.Height = 33;
            this.dgvItemList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvItemList.Size = new System.Drawing.Size(1260, 943);
            this.dgvItemList.TabIndex = 32;
            this.dgvItemList.SelectionChanged += new System.EventHandler(this.dgvItemList_SelectionChanged);
            // 
            // buttonCreateNewItem
            // 
            this.buttonCreateNewItem.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.buttonCreateNewItem.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonCreateNewItem.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.buttonCreateNewItem.ForeColor = System.Drawing.Color.White;
            this.buttonCreateNewItem.Location = new System.Drawing.Point(12, 12);
            this.buttonCreateNewItem.Name = "buttonCreateNewItem";
            this.buttonCreateNewItem.Size = new System.Drawing.Size(200, 60);
            this.buttonCreateNewItem.TabIndex = 65;
            this.buttonCreateNewItem.Text = "New Item";
            this.buttonCreateNewItem.UseVisualStyleBackColor = false;
            this.buttonCreateNewItem.Click += new System.EventHandler(this.buttonCreateNewItem_Click);
            // 
            // buttonEditItem
            // 
            this.buttonEditItem.BackColor = System.Drawing.Color.MediumOrchid;
            this.buttonEditItem.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonEditItem.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.buttonEditItem.ForeColor = System.Drawing.Color.White;
            this.buttonEditItem.Location = new System.Drawing.Point(218, 12);
            this.buttonEditItem.Name = "buttonEditItem";
            this.buttonEditItem.Size = new System.Drawing.Size(200, 60);
            this.buttonEditItem.TabIndex = 72;
            this.buttonEditItem.Text = "Edit Item";
            this.buttonEditItem.UseVisualStyleBackColor = false;
            this.buttonEditItem.Click += new System.EventHandler(this.buttonEditItem_Click);
            // 
            // linkLabelCancelEditItem
            // 
            this.linkLabelCancelEditItem.AutoSize = true;
            this.linkLabelCancelEditItem.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.linkLabelCancelEditItem.LinkColor = System.Drawing.Color.DeepSkyBlue;
            this.linkLabelCancelEditItem.Location = new System.Drawing.Point(424, 24);
            this.linkLabelCancelEditItem.Name = "linkLabelCancelEditItem";
            this.linkLabelCancelEditItem.Size = new System.Drawing.Size(149, 37);
            this.linkLabelCancelEditItem.TabIndex = 73;
            this.linkLabelCancelEditItem.TabStop = true;
            this.linkLabelCancelEditItem.Text = "Cancel edit";
            this.linkLabelCancelEditItem.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabelCancelEditItem_LinkClicked);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // buttonExportAllItems
            // 
            this.buttonExportAllItems.BackColor = System.Drawing.Color.Turquoise;
            this.buttonExportAllItems.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonExportAllItems.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.buttonExportAllItems.ForeColor = System.Drawing.Color.White;
            this.buttonExportAllItems.Location = new System.Drawing.Point(1682, 1057);
            this.buttonExportAllItems.Name = "buttonExportAllItems";
            this.buttonExportAllItems.Size = new System.Drawing.Size(200, 60);
            this.buttonExportAllItems.TabIndex = 74;
            this.buttonExportAllItems.Text = "Export data";
            this.buttonExportAllItems.UseVisualStyleBackColor = false;
            this.buttonExportAllItems.Click += new System.EventHandler(this.buttonExportAllItems_Click);
            // 
            // ItemForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1894, 1129);
            this.Controls.Add(this.buttonExportAllItems);
            this.Controls.Add(this.linkLabelCancelEditItem);
            this.Controls.Add(this.buttonEditItem);
            this.Controls.Add(this.buttonCreateNewItem);
            this.Controls.Add(this.dgvItemList);
            this.Controls.Add(this.checkBoxShowDeletedItem);
            this.Controls.Add(this.textBoxSearchItem);
            this.Controls.Add(this.numericUpDownQuantity);
            this.Controls.Add(this.comboBoxSupplier);
            this.Controls.Add(this.comboBoxCategory);
            this.Controls.Add(this.textBoxPrice);
            this.Controls.Add(this.textBoxItemName);
            this.Controls.Add(this.buttonDeleteItem);
            this.Controls.Add(this.buttonAddItem);
            this.Controls.Add(this.buttonSaveChanges);
            this.Controls.Add(this.labelQuantity);
            this.Controls.Add(this.labelSupplier);
            this.Controls.Add(this.labelCategory);
            this.Controls.Add(this.labelPrice);
            this.Controls.Add(this.richTextBoxDescription);
            this.Controls.Add(this.labelItemDescription);
            this.Controls.Add(this.labelItemName);
            this.Controls.Add(this.labelItemId);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ItemForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Item Mangement";
            this.Load += new System.EventHandler(this.ItemForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownQuantity)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvItemList)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelItemId;
        private System.Windows.Forms.Label labelItemName;
        private System.Windows.Forms.Label labelItemDescription;
        private System.Windows.Forms.RichTextBox richTextBoxDescription;
        private System.Windows.Forms.Label labelPrice;
        private System.Windows.Forms.Label labelCategory;
        private System.Windows.Forms.Label labelSupplier;
        private System.Windows.Forms.Label labelQuantity;
        private System.Windows.Forms.Button buttonSaveChanges;
        private System.Windows.Forms.Button buttonAddItem;
        private System.Windows.Forms.Button buttonDeleteItem;
        private System.Windows.Forms.TextBox textBoxItemName;
        private System.Windows.Forms.TextBox textBoxPrice;
        private System.Windows.Forms.ComboBox comboBoxCategory;
        private System.Windows.Forms.ComboBox comboBoxSupplier;
        private System.Windows.Forms.NumericUpDown numericUpDownQuantity;
        private System.Windows.Forms.TextBox textBoxSearchItem;
        private System.Windows.Forms.CheckBox checkBoxShowDeletedItem;
        private System.Windows.Forms.DataGridView dgvItemList;
        private System.Windows.Forms.Button buttonCreateNewItem;
        private System.Windows.Forms.Button buttonEditItem;
        private System.Windows.Forms.LinkLabel linkLabelCancelEditItem;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.Button buttonExportAllItems;
    }
}