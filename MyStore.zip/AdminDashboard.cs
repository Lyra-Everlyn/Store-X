﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Windows.Forms.DataVisualization.Charting;
using System.Data.SqlClient;
namespace My_Store
{
    public partial class AdminDashboard : Form
    {
        private string connectionString;             // Chuỗi kết nối tới database
        private ToolTip chartToolTip = new ToolTip();// Tooltip cho biểu đồ, dùng để hiển thị thông tin khi rê chuột vào điểm dữ liệu
        private int selectedStaffId = -1;            // Biến lưu trữ ID của nhân viên được chọn
        private bool isUsingShowDeletedData = false; // Bien bo loc co hien thi nhan vien da xoa khong
        public AdminDashboard()
        {
            InitializeComponent();
            this.connectionString = ConfigurationManager.ConnectionStrings["StoreMNGConnectionString"].ConnectionString; // Gán chuỗi kết nối được đọc từ Appconfig 
        }

        // Khi form Admin được load
        private void AdminDashboard_Load(object sender, EventArgs e)
        {
            // Doanh thu
            loadChartData();
            loadDetailedRevenueData();

            // Nhan vien  
            textBoxPassword.UseSystemPasswordChar = true;
            loadStaffData();
            clearStaffDetails();
            switchMode("view");
            convertAuthorityLevelsToString();
            convertWorkingStatusToString();
        }

        #region Tab doanh thu
        // Load biểu đồ
        private void loadChartData()
        {
            try
            {
                // Giải phóng tài nguyên sau khi load xong
                using (SqlConnection connection = new SqlConnection(connectionString)) 
                { 
                    connection.Open();

                    // -- Phần 1. Biểu đồ --
                    string chartQuery = @"
                        SELECT
                            CAST(orderDate AS DATE) AS [OrderDay],      
                            ISNULL(SUM(totalPrice), 0) AS [DailyRevenue]
                        FROM Orders
                        WHERE MONTH(orderDate) = MONTH(GETDATE()) AND YEAR(orderDate) = YEAR(GETDATE())
                        GROUP BY CAST(orderDate AS DATE)
                        ORDER BY OrderDay;
                    ";

                    SqlDataAdapter chartAdapter = new SqlDataAdapter(chartQuery, connection); // Bộ điều hợp dữ liệu
                    DataTable chartData = new DataTable();                                    // Bảng chứa dữ liệu trả về
                    chartAdapter.Fill(chartData);                                             // Đổ dữ liệu từ SQL vào bảng C#

                    chartRevenue.Series["Revenue"].Points.Clear();                            // Xóa dữ liệu cũ trên biểu đồ
                    chartRevenue.Titles.Clear();                                              // Xóa tiêu đề biểu đồ cũ

                    if (chartData.Rows.Count > 0) // Nếu có dữ liệu để vẽ biểu đồ
                    {
                        foreach (DataRow row in chartData.Rows)
                        {
                            DataPoint dp = new DataPoint();                      // Tạo một điểm dữ liệu
                            dp.SetValueXY(row["OrderDay"], row["DailyRevenue"]); // Đặt giá trị X (Ngày) và Y (Doanh thu)
                            dp.Tag = row["OrderDay"].ToString();                 // Lưu ngày vào Tag để dùng cho tooltip
                            chartRevenue.Series["Revenue"].Points.Add(dp);       // Thêm điểm vào biểu đồ
                        }
                    }
                    else // Nếu không có dữ liệu trong 30 ngày qua
                    {
                        chartRevenue.Series["Revenue"].Points.AddXY(DateTime.Today, 0);   // Thêm điểm 0 để biểu đồ không trống rỗng
                        chartRevenue.Titles.Add("No revenue data for the last 30 days."); // Thêm tiêu đề thông báo
                    }

                    // Cấu hình hiển thị trục X và Y của biểu đồ
                    chartRevenue.ChartAreas[0].AxisX.LabelStyle.Format = "MM-dd";                         // Định dạng nhãn trục X (Ngày-Tháng)
                    chartRevenue.ChartAreas[0].AxisX.IntervalType = DateTimeIntervalType.Days;            // Khoảng cách theo ngày
                    chartRevenue.ChartAreas[0].AxisX.Interval = 1;                                        // Mỗi nhãn là 1 ngày
                    chartRevenue.ChartAreas[0].AxisX.MajorGrid.LineDashStyle = ChartDashStyle.DashDotDot; // Style dường lưới của biểu đồ
                    chartRevenue.ChartAreas[0].AxisX.MajorGrid.LineColor = Color.LightGray;               // Đường lưới màu xám nhẹ

                    chartRevenue.ChartAreas[0].AxisY.Title = "Revenue (VNĐ)";                             // Tiêu đề trục Y
                    chartRevenue.ChartAreas[0].AxisY.LabelStyle.Format = "{#,##0}";                       // Định dạng số tiền
                    chartRevenue.ChartAreas[0].AxisY.MajorGrid.LineDashStyle = ChartDashStyle.DashDotDot; // Style dường lưới của biểu đồ
                    chartRevenue.ChartAreas[0].AxisY.MajorGrid.LineColor = Color.LightGray;               // Đường lưới màu xám nhẹ


                    // -- Phần 2. Chỉ số doanh thu (ở phia trên)
                    // Doanh thu tích lũy trong tháng hiện tại
                    string revenueThisMonthQuery = @"
                        SELECT ISNULL(SUM(totalPrice), 0)
                        FROM Orders
                        WHERE MONTH(orderDate) = MONTH(GETDATE()) AND YEAR(orderDate) = YEAR(GETDATE());
                    ";
                    SqlCommand revenueThisMonthCmd = new SqlCommand(revenueThisMonthQuery, connection);
                    decimal revenueThisMonth = Convert.ToDecimal(revenueThisMonthCmd.ExecuteScalar());
                    labelMonthRevenue.Text = revenueThisMonth.ToString("N0");

                    // Doanh thu của ngày hôm qua
                    string revenueYesterdayQuery = @"
                        SELECT ISNULL(SUM(totalPrice), 0)
                        FROM Orders
                        WHERE CAST(orderDate AS DATE) = CAST(DATEADD(day, -1, GETDATE()) AS DATE);
                    ";
                    SqlCommand revenueYesterdayCmd = new SqlCommand(revenueYesterdayQuery, connection);
                    decimal revenueYesterday = Convert.ToDecimal(revenueYesterdayCmd.ExecuteScalar());
                    labelYesterdayRevenue.Text = revenueYesterday.ToString("N0");

                    // Doanh thu của ngày hôm nay
                    string revenueTodayQuery = @"
                        SELECT ISNULL(SUM(totalPrice), 0)
                        FROM Orders
                        WHERE CAST(orderDate AS DATE) = CAST(GETDATE() AS DATE);
                    ";

                    SqlCommand revenueTodayCmd = new SqlCommand(revenueTodayQuery, connection);
                    decimal revenueToday = Convert.ToDecimal(revenueTodayCmd.ExecuteScalar());
                    labelTodayRevenue.Text = revenueToday.ToString("N0");

                }
            }
            catch (Exception ex) // Bắt lỗi trong quá trình load dữ liệu
            {
                MessageBox.Show("Loading Failed: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Khi di chuột vào biểu đồ
        private void dgvRevenueDetail_MouseMove(object sender, MouseEventArgs e)
        {
            HitTestResult result = chartRevenue.HitTest(e.X, e.Y); // Kiểm tra vị trí chuột trên biểu đồ
            if (result.ChartElementType == ChartElementType.DataPoint) // Nếu chuột đang trỏ vào một điểm dữ liệu
            {
                DataPoint point = chartRevenue.Series["Revenue"].Points[result.PointIndex]; // Lấy điểm dữ liệu đó

                DateTime date = DateTime.FromOADate(point.XValue);  // Lấy ngày từ giá trị X
                double revenue = point.YValues[0];                  // Lấy doanh thu từ giá trị Y

                string tooltipText = $"Day: {date.ToString("dd/MM/yyyy")}\nRevenue: {revenue.ToString("N0")} VNĐ"; // Tạo nội dung tooltip

                chartToolTip.Show(tooltipText, chartRevenue, e.X + 10, e.Y + 10); // Hiển thị tooltip
            }
            else // Nếu chuột không trỏ vào điểm dữ liệu
            {
                chartToolTip.Hide(chartRevenue); // Ẩn tooltip
            }
        }

        // Load bảng chi tiết doanh thu
        private void loadDetailedRevenueData()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    // Truy vấn để lấy chi tiết từng đơn hàng (Mã đơn hàng, Ngày, Nhân viên, Tổng tiền)
                    string detailedRevenueThisMonthQuery = @"
                        SELECT
                            O.orderId AS [Order Id],
                            CAST(O.orderDate AS DATE) AS [Day],
                            S.staffName AS [Staff],
                            O.totalPrice AS [Revenue]
                        FROM Orders O
                        LEFT JOIN Staff S ON O.staffId = S.staffId
                        WHERE MONTH(O.orderDate) = MONTH(GETDATE()) AND YEAR(O.orderDate) = YEAR(GETDATE())
                        ORDER BY O.orderDate DESC;
                    ";

                    SqlDataAdapter detailedAdapter = new SqlDataAdapter(detailedRevenueThisMonthQuery, connection);
                    DataTable detailedData = new DataTable();
                    detailedAdapter.Fill(detailedData); // Đổ dữ liệu vào bảng C#

                    dgvDetailedRevenue.DataSource = detailedData; // Gán bảng dữ liệu vào DataGridView
                    dgvDetailedRevenue.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Loading Failed: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        #endregion 

        #region Tab du lieu nhan vien
        // -- Phần 1. Hiển thị dữ liệu --
        // Load dữ liệu nhân viên, không bao gồm mật khẩu
        private void loadStaffData()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    string query;
                    if (!isUsingShowDeletedData)
                    {
                        query = @"
                        SELECT
                            staffId AS [ID],
                            staffName AS [Name],
                            staffPhoneNumber AS [Phone],
                            staffEmail AS [Email],
                            staffUsername AS [Username],
                            authorityLevel AS [Authority],
                            isActive AS [Status]
                        FROM
                            Staff
                        WHERE isActive = 1
                        ORDER BY staffId DESC";
                    }
                    else 
                    {
                        query = @"
                        SELECT
                            staffId AS [ID],
                            staffName AS [Name],
                            staffPhoneNumber AS [Phone],
                            staffEmail AS [Email],
                            staffUsername AS [Username],
                            authorityLevel AS [Authority],
                            isActive AS [Status]
                        FROM
                            Staff
                        ORDER BY staffId DESC";
                    }
                    SqlDataAdapter staffAdapter = new SqlDataAdapter(query, connection);
                    DataTable staffData = new DataTable();
                    staffAdapter.Fill(staffData);
                    dgvStaffList.DataSource = staffData;
                    dgvStaffList.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Loading Staff Failed: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        // Chuyển đổi trạng thái làm việc sang văn bản
        private void convertWorkingStatusToString()
        {
            // isActive là một bit trong bảng Staff
            DataTable dtWorkingStatus = new DataTable();
            dtWorkingStatus.Columns.Add("StatusID", typeof(int));
            dtWorkingStatus.Columns.Add("StatusName", typeof(string));

            dtWorkingStatus.Rows.Add(1, "Still Working");
            dtWorkingStatus.Rows.Add(0, "Retired");

            comboBoxWorkingStatus.DisplayMember = "StatusName";
            comboBoxWorkingStatus.ValueMember = "StatusID";
            comboBoxWorkingStatus.DataSource = dtWorkingStatus;
        }

        // Chuyển đổi cấp độ quyền lợi sang văn bản
        private void convertAuthorityLevelsToString()
        {
            // authorityLevel là một INT trong bảng Staff (1, 2, 3)
            DataTable dtAuthority = new DataTable();
            dtAuthority.Columns.Add("LevelID", typeof(int));
            dtAuthority.Columns.Add("LevelName", typeof(string));

            dtAuthority.Rows.Add(1, "Admin");
            dtAuthority.Rows.Add(2, "Sale");
            dtAuthority.Rows.Add(3, "Warehouse");

            comboBoxAuthorityLevel.DisplayMember = "LevelName";
            comboBoxAuthorityLevel.ValueMember = "LevelID";
            comboBoxAuthorityLevel.DataSource = dtAuthority;
        }

        // Khi chọn 1 hàng bất kì trong dgvStaffList
        private void dgvStaffList_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvStaffList.CurrentRow != null && dgvStaffList.CurrentRow.Index >= 0)
            {   
                DataGridViewRow row = dgvStaffList.CurrentRow;
                selectedStaffId = Convert.ToInt32(row.Cells["ID"].Value);

                labelStaffId.Text = "Staff Id: " + selectedStaffId.ToString();

                textBoxStaffName.Text = row.Cells["Name"].Value.ToString();
                textBoxPhoneNumber.Text = row.Cells["Phone"].Value.ToString();
                textBoxEmail.Text = row.Cells["Email"].Value.ToString();
                textBoxUsername.Text = row.Cells["Username"].Value.ToString();

                checkBoxShowPassword.Checked = false; 
                textBoxPassword.UseSystemPasswordChar = true;

                // Lấy mật khẩu riêng từ cơ sở dữ liệu
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    try
                    {
                        connection.Open();
                        string query = "SELECT staffPassword FROM Staff WHERE staffId = @staffId";
                        SqlCommand command = new SqlCommand(query, connection);
                        command.Parameters.AddWithValue("@staffId", selectedStaffId);

                        object passwordObj = command.ExecuteScalar();
                        if (passwordObj != null)
                        {
                            textBoxPassword.Text = passwordObj.ToString();
                        }
                        else
                        {
                            textBoxPassword.Clear();
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error retrieving password: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        textBoxPassword.Clear();
                    }
                }

                // Lấy giá trị authorityLevel từ DataGridView (là số nguyên)
                // Đảm bảo giá trị này khớp với LevelID trong DataTable của comboBoxAuthorityLevel
                if (row.Cells["Authority"].Value != DBNull.Value)
                {
                    int authorityLevelValue = Convert.ToInt32(row.Cells["Authority"].Value);
                    comboBoxAuthorityLevel.SelectedValue = authorityLevelValue;
                }
                else
                {
                    comboBoxAuthorityLevel.SelectedIndex = -1;
                }

                if (row.Cells["Status"].Value != DBNull.Value)
                {
                    int statusValue = Convert.ToInt32(row.Cells["Status"].Value);
                    comboBoxWorkingStatus.SelectedValue = statusValue;
                }
                else
                {
                    comboBoxWorkingStatus.SelectedIndex = -1;
                }
            }
        }

        // Khi tick hiện mật khẩu nhân viên
        private void checkBoxShowPassword_CheckedChanged(object sender, EventArgs e)
        {
            textBoxPassword.UseSystemPasswordChar = !checkBoxShowPassword.Checked;
        }

        // -- Phần 2. Sửa dữ liệu --
        // Clear dữ liệu các box
        private void clearStaffDetails()
        {
            labelStaffId.Text = "Staff Id: <Auto Generate>";

            textBoxStaffName.Clear();
            textBoxPhoneNumber.Clear();
            textBoxEmail.Clear();
            textBoxUsername.Clear();
            textBoxPassword.Clear();
            checkBoxShowPassword.Checked = false;
            textBoxPassword.UseSystemPasswordChar = true;

            comboBoxAuthorityLevel.SelectedIndex = -1;
            comboBoxAuthorityLevel.Text = "Select level";

            comboBoxWorkingStatus.SelectedIndex = -1;
            comboBoxWorkingStatus.Text = "Select status";

            selectedStaffId = -1;
        }

        private void switchMode(string modeName)
        {
            switch (modeName) 
            {
                case "view":
                    // Block 1. TextBox
                    textBoxStaffName.Enabled = false;
                    textBoxPhoneNumber.Enabled = false;
                    textBoxEmail.Enabled = false;
                    textBoxUsername.Enabled = false;
                    textBoxPassword.Enabled = false;

                    checkBoxShowPassword.Enabled = false;
                    comboBoxAuthorityLevel.Enabled = false;
                    comboBoxWorkingStatus.Enabled = false;

                    // Block 2. Button
                    buttonEditStaff.Enabled = true;
                    buttonCreateNewStaff.Enabled = true;
 
                    buttonSaveChanges.Enabled = false;
                    buttonAddStaff.Enabled = false;
                    buttonDeleteStaff.Enabled = false;
                    linkLabelCancelEditStaff.Enabled = false;

                    // Block 3. dgv Table
                    textBoxSearchStaff.Enabled = true;
                    dgvStaffList.Enabled = true;
                    break;
                
                case "edit":
                    // Block 1.TextBox
                    textBoxStaffName.Enabled = true;
                    textBoxPhoneNumber.Enabled = true;
                    textBoxEmail.Enabled = true;
                    textBoxUsername.Enabled = true;
                    textBoxPassword.Enabled = true;

                    checkBoxShowPassword.Enabled = true;
                    comboBoxAuthorityLevel.Enabled = true;
                    comboBoxWorkingStatus.Enabled = true;

                    // Block 2. Button
                    buttonCreateNewStaff.Enabled = false;
                    buttonEditStaff.Enabled = false;
                                       
                    buttonAddStaff.Enabled = false;
                    buttonSaveChanges.Enabled = true;
                    buttonDeleteStaff.Enabled = true;
                    linkLabelCancelEditStaff.Enabled = true;

                    // Block 3. dgv Table
                    textBoxSearchStaff.Enabled = true;
                    dgvStaffList.Enabled = true;
                    break;

                case "add":
                    // Block 1.TextBox
                    textBoxStaffName.Enabled = true;
                    textBoxPhoneNumber.Enabled = true;
                    textBoxEmail.Enabled = true;
                    textBoxUsername.Enabled = true;
                    textBoxPassword.Enabled = true;

                    checkBoxShowPassword.Enabled = true;
                    comboBoxAuthorityLevel.Enabled = true;
                    comboBoxWorkingStatus.Enabled = true;

                    // Block 2. Button
                    buttonCreateNewStaff.Enabled = false;
                    buttonEditStaff.Enabled = false;

                    buttonAddStaff.Enabled = true;
                    buttonSaveChanges.Enabled = false;
                    buttonDeleteStaff.Enabled = false;
                    linkLabelCancelEditStaff.Enabled = true;

                    // Block 3. dgv Table
                    textBoxSearchStaff.Enabled = false;
                    dgvStaffList.Enabled = false;
                    break;

                default: 
                    switchMode("view"); 
                    break;
            }
        }

        // Khi ấn nút tạo mới thì [Mở khóa nút thêm, link hủy] [Chặn nút tạo mới, edit, xóa, cập nhật] [Chặn dgv]
        private void buttonCreateNewStaff_Click(object sender, EventArgs e)
        {
            switchMode("add");
            clearStaffDetails();
        }

        // Khi ấn nút edit thì [Mở khóa nút xóa, cập nhật, link hủy] [Chặn nút tạo mới, thêm, edit] [Chặn dgv]
        private void buttonEditStaff_Click(object sender, EventArgs e)
        {
            if (selectedStaffId == -1)
            {
                MessageBox.Show("Please select a staff member from the list to update.", "Selection Required", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            switchMode("edit");
        }

        // Khi ấn link hủy thì [Mở khóa nút tạo mới, edit] [Chặn nút xóa, cập nhật, thêm] [Mở khóa dgv]
        private void linkLabelCancelEditStaff_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            switchMode("view");
        }

        // Khi ấn nút thêm [Mở khóa nút xóa, cập nhật, dgv] [Chặn nút thêm] [Thêm dữ liệu mới vào bảng staff]
        private void buttonAddStaff_Click(object sender, EventArgs e)
        {
            // Kiểm tra các trường bắt buộc
            if (string.IsNullOrWhiteSpace(textBoxStaffName.Text) ||
                string.IsNullOrWhiteSpace(textBoxPhoneNumber.Text) ||
                string.IsNullOrWhiteSpace(textBoxEmail.Text) ||
                string.IsNullOrWhiteSpace(textBoxUsername.Text) ||
                string.IsNullOrWhiteSpace(textBoxPassword.Text) ||
                comboBoxAuthorityLevel.SelectedValue == null)
            {
                MessageBox.Show("Please fill in all staff details.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    // KHÔNG BAO GỒM staffId vào INSERT vì nó là IDENTITY
                    string query = @"
                        INSERT INTO Staff (staffName, staffPhoneNumber, staffEmail, authorityLevel, staffUsername, staffPassword, isActive)
                        VALUES (@staffName, @staffPhoneNumber, @staffEmail, @authorityLevel, @staffUsername, @staffPassword, 1);
                        SELECT SCOPE_IDENTITY();"; 

                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@staffName", textBoxStaffName.Text);
                    command.Parameters.AddWithValue("@staffPhoneNumber", textBoxPhoneNumber.Text);
                    command.Parameters.AddWithValue("@staffEmail", textBoxEmail.Text);
                    command.Parameters.AddWithValue("@authorityLevel", (int)comboBoxAuthorityLevel.SelectedValue);
                    command.Parameters.AddWithValue("@staffUsername", textBoxUsername.Text);
                    
                    DatabaseHelper helper = new DatabaseHelper(connectionString);
                    string hashPassword = DatabaseHelper.GetSha256Hash(textBoxPassword.Text);
                    command.Parameters.AddWithValue("@staffPassword", hashPassword);

                    //command.Parameters.AddWithValue("@staffPassword", textBoxPassword.Text);
                    selectedStaffId = Convert.ToInt32(command.ExecuteScalar());

                    MessageBox.Show("Staff added successfully! ID: " + selectedStaffId, "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    loadStaffData();
                    switchMode("view");

                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error adding staff: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        // Khi ấn nút lưu [Mở khóa nút thêm mới, edit, dgv] [Chặn nút xóa, thêm]
        private void buttonSaveChanges_Click(object sender, EventArgs e)
        {
            if (selectedStaffId == -1)
            {
                MessageBox.Show("Please select a staff member from the list to update.", "Selection Required", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            if (string.IsNullOrWhiteSpace(textBoxStaffName.Text) ||
                string.IsNullOrWhiteSpace(textBoxPhoneNumber.Text) ||
                string.IsNullOrWhiteSpace(textBoxEmail.Text) ||
                string.IsNullOrWhiteSpace(textBoxUsername.Text) ||
                string.IsNullOrWhiteSpace(textBoxPassword.Text) ||
                comboBoxAuthorityLevel.SelectedValue == null)
            {
                MessageBox.Show("Please fill in all staff details.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    string query = @"
                        UPDATE Staff SET
                            staffName = @staffName,
                            staffPhoneNumber = @staffPhoneNumber,
                            staffEmail = @staffEmail,
                            authorityLevel = @authorityLevel,
                            staffUsername = @staffUsername,
                            staffPassword = @staffPassword,
                            isActive = @isActive
                        WHERE staffId = @staffId";

                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@staffName", textBoxStaffName.Text);
                    command.Parameters.AddWithValue("@staffPhoneNumber", textBoxPhoneNumber.Text);
                    command.Parameters.AddWithValue("@staffEmail", textBoxEmail.Text);
                    command.Parameters.AddWithValue("@authorityLevel", (int)comboBoxAuthorityLevel.SelectedValue);
                    command.Parameters.AddWithValue("@isActive", (int)comboBoxWorkingStatus.SelectedValue);
                    command.Parameters.AddWithValue("@staffUsername", textBoxUsername.Text);

                    DatabaseHelper helper = new DatabaseHelper(connectionString);
                    string hashPassword = DatabaseHelper.GetSha256Hash(textBoxPassword.Text);
                    command.Parameters.AddWithValue("@staffPassword", hashPassword);

                    //command.Parameters.AddWithValue("@staffPassword", textBoxPassword.Text);
                    command.Parameters.AddWithValue("@staffId", selectedStaffId);
                    command.ExecuteNonQuery();

                    MessageBox.Show("Staff updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    
                    loadStaffData();
                    switchMode("view");

                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error updating staff: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        // Khi ấn nút xóa [Mở khóa thêm mới, edit] [Xóa các box] [Chặn xóa, cập nhật]
        private void buttonDeleteStaff_Click(object sender, EventArgs e)
        {
            if (selectedStaffId == -1)
            {
                MessageBox.Show("Please select a staff member from the list to 'soft delete'.", "Selection Required", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            // Xác nhận xóa
            if (MessageBox.Show($"Are you sure you want to mark staff ID {selectedStaffId} as 'Deleted Staff'?", "Confirm Soft Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    try
                    {
                        connection.Open();
                        // UPDATE các thông tin thành "đã bị xóa" và set isActive = 0
                        string query = @"
                            UPDATE Staff SET
                                staffName = 'Deleted Staff',
                                staffPhoneNumber = RIGHT('0000000000' + CONVERT(NVARCHAR, staffId), 10),
                                staffEmail = 'deleted_' + CONVERT(NVARCHAR, staffId) + '@email.com',
                                staffUsername = 'deleted_' + CONVERT(NVARCHAR, staffId),
                                staffPassword = 'deletedpass',
                                isActive = 0 
                            WHERE staffId = @staffId";

                        SqlCommand command = new SqlCommand(query, connection);
                        command.Parameters.AddWithValue("@staffId", selectedStaffId);
                        command.ExecuteNonQuery();
                        
                        MessageBox.Show("Staff marked as 'Deleted Staff' successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        
                        loadStaffData();
                        clearStaffDetails();
                        switchMode("view");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error marking staff as 'Deleted': " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }
        #endregion

        #region Bo loc hien nhan vien da xoa
        // Khi tick hiện những tài khoản đã dừng hoạt động
        private void checkBoxShowInactiveAcc_CheckedChanged(object sender, EventArgs e)
        {
            if (!checkBoxShowInactiveAcc.Checked) { isUsingShowDeletedData = false; }
            else { isUsingShowDeletedData = true; }
            loadStaffData();
        }
        #endregion

        #region Tim kiem nhan vien
        // Tìm kiếm nhân viên qua id, tên, số điện thoại, email và tài khoản còn hoạt động
        private void searchStaff(string keyword)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    string query = @"
                        SELECT staffId AS [ID], staffName AS [Name], staffPhoneNumber AS [Phone],
                            staffEmail AS [Email], staffUsername AS [Username],
                            authorityLevel AS [Authority], isActive AS [Status]
                        FROM Staff
                        WHERE (
                            staffId LIKE @keyword OR
                            staffName LIKE @keyword OR
                            staffPhoneNumber LIKE @keyword OR
                            staffEmail LIKE @keyword
                        )";

                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@keyword", $"%{keyword}%");

                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable resultTable = new DataTable();
                    adapter.Fill(resultTable);

                    dgvStaffList.DataSource = resultTable;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Search failed: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        // Khi nhấn nút Enter
        private void textBoxSearchStaff_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.Handled = true;
                e.SuppressKeyPress = true;

                string keyword = textBoxSearchStaff.Text.Trim();
                if (string.IsNullOrEmpty(keyword))
                {
                    loadStaffData();
                    return;
                }
                searchStaff(keyword);
            }
        }
        #endregion       
    }
}