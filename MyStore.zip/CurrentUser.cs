﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace My_Store
{
    public static class CurrentUser
    {
        public static int StaffId { get; private set; }
        public static int AuthorityLevel { get; private set; }
        public static string StaffName { get; private set; }

        // Lưu thông tin nhân viên đã đăng nhập
        public static void Set(StaffProfile staff)
        {
            StaffId = staff.StaffId;
            AuthorityLevel = staff.AuthorityLevel;
            StaffName = staff.StaffName;
        }

        // Xóa thông tin khi logout
        public static void Clear()
        {
            StaffId = 0;
            AuthorityLevel = 0;
            StaffName = null;
        }

        // Kiểm tra đã đăng nhập chưa
        public static bool IsLoggedIn()
        {
            return StaffId > 0;
        }
    }
}
