﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using ClosedXML.Excel;
using System.IO;


namespace My_Store
{
    public partial class ItemForm : Form
    {
        private string connectionString;
        private int selectedItemId = -1;
        private bool isUsingShowDeletedData = false;

        public ItemForm()
        {
            InitializeComponent();
            this.connectionString = ConfigurationManager.ConnectionStrings["StoreMNGConnectionString"].ConnectionString;
        }

        // Khi Form duoc load
        private void ItemForm_Load(object sender, EventArgs e)
        {
            clearItemDetails();
            loadItemData();           
            loadCategoryName();
            loadSupplierName();
            switchMode("view");
        }
        #region Load du lieu vat pham
        // Phuong thuc load du lieu vat pham
        private void loadItemData()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    string query;

                    if (isUsingShowDeletedData)
                    {
                        
                        query = @"
                            SELECT
                                itemId AS [ID],
                                itemName AS [Name],
                                itemDescription AS [Description],
                                itemPrice AS [Price],
                                itemQuantity AS [Quantity],
                                categoryId AS [Category],
                                supplierId AS [Supplier]
                            FROM Item
                            ORDER BY itemId DESC";
                    }
                    else
                    {
                        query = @"
                            SELECT
                                itemId AS [ID],
                                itemName AS [Name],
                                itemDescription AS [Description],
                                itemPrice AS [Price],
                                itemQuantity AS [Quantity],
                                categoryId AS [Category],
                                supplierId AS [Supplier]
                            FROM Item
                            WHERE itemName != 'Deleted Item'
                            ORDER BY itemId DESC";
                    }

                    SqlDataAdapter itemAdapter = new SqlDataAdapter(query, connection);
                    DataTable itemData = new DataTable();
                    itemAdapter.Fill(itemData);
                    dgvItemList.DataSource = itemData;
                    dgvItemList.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

                }
                catch (Exception ex)
                {
                    MessageBox.Show("Loading item data failed: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        // Phuong thuc load loai vat pham
        private void loadCategoryName()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    string query = "SELECT categoryId, categoryName FROM Category WHERE categoryName NOT LIKE 'Category[0-9]%'";
                    SqlDataAdapter categoryAdapter = new SqlDataAdapter(query, connection);
                    DataTable categoryData = new DataTable();
                    categoryAdapter.Fill(categoryData);

                    comboBoxCategory.DataSource = categoryData;
                    comboBoxCategory.DisplayMember = "categoryName";
                    comboBoxCategory.ValueMember = "categoryId";

                }
                catch (Exception ex)
                {
                    MessageBox.Show("Loading category data failed: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        // Phuong thuc load nha cung cap
        private void loadSupplierName()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    string query = "SELECT supplierId, supplierName FROM Supplier WHERE supplierName NOT LIKE 'Deleted Supplier'";
                    SqlDataAdapter supplierAdapter = new SqlDataAdapter(query, connection);
                    DataTable supplierData = new DataTable();
                    supplierAdapter.Fill(supplierData);

                    comboBoxSupplier.DataSource = supplierData;
                    comboBoxSupplier.DisplayMember = "supplierName";
                    comboBoxSupplier.ValueMember = "supplierId";

                }
                catch (Exception ex)
                {
                    MessageBox.Show("Loading supplier data failed: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        // Khi click vao bang
        private void dgvItemList_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvItemList.CurrentRow != null && dgvItemList.CurrentRow.Index >= 0)
            {
                DataGridViewRow selectedRow = dgvItemList.CurrentRow;
                selectedItemId = Convert.ToInt32(selectedRow.Cells["ID"].Value);

                labelItemId.Text = "Item Id: " + selectedItemId.ToString();
                textBoxItemName.Text = selectedRow.Cells["Name"].Value.ToString();
                richTextBoxDescription.Text = selectedRow.Cells["Description"].Value.ToString();
                textBoxPrice.Text = selectedRow.Cells["Price"].Value.ToString();

                int categoryId = Convert.ToInt32(selectedRow.Cells["Category"].Value);
                comboBoxCategory.SelectedValue = categoryId;

                int supplierId = Convert.ToInt32(selectedRow.Cells["Supplier"].Value);
                comboBoxSupplier.SelectedValue = supplierId;

                int quantity = Convert.ToInt32(selectedRow.Cells["Quantity"].Value);
                numericUpDownQuantity.Value = quantity;
                //updateFormStateForEdit();
            }
        }
        #endregion

        #region Sua du lieu vat pham
        // Phuong thuc clear du lieu
        private void clearItemDetails()
        {
            labelItemId.Text = "Item Id: <Auto Generate>";

            textBoxItemName.Clear();
            richTextBoxDescription.Text = "No description";
            textBoxPrice.Text = "0";

            comboBoxCategory.SelectedValue = -1;
            comboBoxCategory.Text = "Select category";

            comboBoxSupplier.SelectedValue = -1;
            comboBoxSupplier.Text = "Select supplier";

            numericUpDownQuantity.Value = 0;
            selectedItemId = -1;
        }
        private void switchMode(string modeName)
        {
            switch (modeName)
            {
                case "view":
                    // Block 1. TextBox
                    textBoxItemName.Enabled = false;
                    richTextBoxDescription.Enabled = false;
                    textBoxPrice.Enabled = false;
                    comboBoxCategory.Enabled = false;
                    comboBoxSupplier.Enabled = false;
                    numericUpDownQuantity.Enabled = false;

                    // Block 2. Button
                    buttonCreateNewItem.Enabled = true;
                    buttonEditItem.Enabled = true;

                    buttonAddItem.Enabled = false;
                    buttonSaveChanges.Enabled = false;
                    buttonDeleteItem.Enabled = false;
                    linkLabelCancelEditItem.Enabled = false;

                    // Block 3. dgv Table 
                    textBoxSearchItem.Enabled = true;
                    dgvItemList.Enabled = true;
                    break;

                case "edit":
                    // Block 1. TextBox
                    textBoxItemName.Enabled = true;
                    richTextBoxDescription.Enabled = true;
                    textBoxPrice.Enabled = true;
                    comboBoxCategory.Enabled = true;
                    comboBoxSupplier.Enabled = true;
                    numericUpDownQuantity.Enabled = true;

                    // Block 2. Button
                    buttonCreateNewItem.Enabled = false;
                    buttonEditItem.Enabled = false;

                    buttonAddItem.Enabled = false;
                    buttonSaveChanges.Enabled = true;
                    buttonDeleteItem.Enabled = true;
                    linkLabelCancelEditItem.Enabled = true;

                    // Block 3. dgv Table 
                    textBoxSearchItem.Enabled = true;
                    dgvItemList.Enabled = true;
                    break;

                case "add":
                    // Block 1. TextBox
                    textBoxItemName.Enabled = true;
                    richTextBoxDescription.Enabled = true;
                    textBoxPrice.Enabled = true;
                    comboBoxCategory.Enabled = true;
                    comboBoxSupplier.Enabled = true;
                    numericUpDownQuantity.Enabled = true;

                    // Block 2. Button
                    buttonCreateNewItem.Enabled = false;
                    buttonEditItem.Enabled = false;

                    buttonAddItem.Enabled = true;
                    buttonSaveChanges.Enabled = false;
                    buttonDeleteItem.Enabled = false;
                    linkLabelCancelEditItem.Enabled = true;

                    // Block 3. dgv Table 
                    textBoxSearchItem.Enabled = false;
                    dgvItemList.Enabled = false;
                    break;

                default:
                    switchMode("view");
                    break;
            }
        }

        private void buttonCreateNewItem_Click(object sender, EventArgs e)
        {
            switchMode("add");
            clearItemDetails();            
        }

        private void buttonEditItem_Click(object sender, EventArgs e)
        {
            if (selectedItemId == -1)
            {
                MessageBox.Show("Please select an item member from the list to update.", "Selection Required", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            switchMode("edit");
        }

        private void linkLabelCancelEditItem_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            switchMode("view");
        }

        // Khi an nut them vat pham
        private void buttonAddItem_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBoxItemName.Text) ||
                string.IsNullOrWhiteSpace(richTextBoxDescription.Text) ||
                string.IsNullOrWhiteSpace(textBoxPrice.Text) ||
                comboBoxCategory.SelectedValue == null ||
                comboBoxSupplier.SelectedValue == null ||
                numericUpDownQuantity.Value < 0)
            {
                MessageBox.Show("Please fill in all item details.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    string query = @"
                        INSERT INTO Item (itemName, itemDescription, itemPrice, categoryId, supplierId, itemQuantity)
                        VALUES (@itemName, @itemDescription, @itemPrice, @categoryId, @supplierId, @itemQuantity);
                        SELECT SCOPE_IDENTITY();";

                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@itemName", textBoxItemName.Text);
                    command.Parameters.AddWithValue("@itemDescription", richTextBoxDescription.Text);
                    command.Parameters.AddWithValue("@itemPrice", Convert.ToDecimal(textBoxPrice.Text));

                    command.Parameters.AddWithValue("@categoryId", comboBoxCategory.SelectedValue);
                    command.Parameters.AddWithValue("@supplierId", comboBoxSupplier.SelectedValue);
                    command.Parameters.AddWithValue("@itemQuantity", numericUpDownQuantity.Value);
                    selectedItemId = Convert.ToInt32(command.ExecuteScalar());

                    MessageBox.Show("Item added successfully! ID: " + selectedItemId, "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    
                    loadItemData();
                    switchMode("view");

                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error adding item: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        // Luu thay doi
        private void buttonSaveChanges_Click(object sender, EventArgs e)
        {
            if (selectedItemId == -1)
            {
                MessageBox.Show("Please select an item member from the list to update.", "Selection Required", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            if (string.IsNullOrWhiteSpace(textBoxItemName.Text) ||
                string.IsNullOrWhiteSpace(richTextBoxDescription.Text) ||
                string.IsNullOrWhiteSpace(textBoxPrice.Text) ||
                comboBoxCategory.SelectedValue == null ||
                comboBoxSupplier.SelectedValue == null ||
                numericUpDownQuantity.Value < 0)
            {
                MessageBox.Show("Please fill in all item details.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    string query = 
                        @"UPDATE Item SET
                            itemName = @itemName, 
                            itemDescription = @itemDescription, 
                            itemPrice = @itemPrice, 
                            categoryId = @categoryId, 
                            supplierId = @supplierId, 
                            itemQuantity = @itemQuantity
                        WHERE itemId = @itemId";

                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@itemId", selectedItemId);
                    command.Parameters.AddWithValue("@itemName", textBoxItemName.Text);
                    command.Parameters.AddWithValue("@itemDescription", richTextBoxDescription.Text);

                    command.Parameters.AddWithValue("@itemPrice", Convert.ToDecimal(textBoxPrice.Text));
                    command.Parameters.AddWithValue("@categoryId", comboBoxCategory.SelectedValue);
                    command.Parameters.AddWithValue("@supplierId", comboBoxSupplier.SelectedValue);
                    command.Parameters.AddWithValue("@itemQuantity", Convert.ToInt32(numericUpDownQuantity.Value));
                    command.ExecuteNonQuery();

                    MessageBox.Show("Item updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    
                    loadItemData();
                    switchMode("view");

                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error updating item: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        // Khi xoa vat pham
        private void buttonDeleteItem_Click(object sender, EventArgs e)
        {
            if (selectedItemId == -1)
            {
                MessageBox.Show("Please select a item member from the list to 'soft delete'.", "Selection Required", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            if (MessageBox.Show($"Are you sure you want to mark item ID {selectedItemId} as 'Deleted item'?", "Confirm Soft Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    try
                    {
                        connection.Open();
                        string query = 
                            @"UPDATE Item SET
                                itemName = 'Deleted item', 
                                itemDescription = 'No description', 
                                itemPrice = 0, 
                                itemQuantity = 0
                            WHERE itemId = @itemId";

                        SqlCommand command = new SqlCommand(query, connection);
                        command.Parameters.AddWithValue("@itemId", selectedItemId);
                        command.ExecuteNonQuery();

                        MessageBox.Show("Item marked as 'Deleted item' successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        loadItemData();
                        clearItemDetails();
                        switchMode("view");

                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error marking item as 'Deleted': " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }
        #endregion

        #region Bo loc vat pham da xoa
        private void checkBoxShowDeletedItem_CheckedChanged(object sender, EventArgs e)
        {
            if (!checkBoxShowDeletedItem.Checked) { isUsingShowDeletedData = false; }
            else { isUsingShowDeletedData = true; }
            loadItemData();
        }
        #endregion

        #region Tim kiem vat pham
        // Phuong thuc tim kiem khach hang
        private void searchItem(string keyword)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    string query = @"
                        SELECT itemId AS [ID], itemName AS [Name], itemDescription AS [Description], itemPrice AS [Price], 
                                categoryId AS [Category], supplierId AS [Supplier], itemQuantity AS [Quantity]
                        FROM Item
                        WHERE ((itemId LIKE @keyword OR itemName LIKE @keyword) AND itemName != 'Deleted item')";

                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@keyword", $"%{keyword}%");

                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable resultTable = new DataTable();
                    adapter.Fill(resultTable);

                    dgvItemList.DataSource = resultTable;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Search failed: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        // Tim kiem vat oham
        private void textBoxSearchItem_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.Handled = true;
                e.SuppressKeyPress = true;

                string keyword = textBoxSearchItem.Text.Trim();
                if (string.IsNullOrEmpty(keyword))
                {
                    loadItemData();
                    return;
                }
                searchItem(keyword);
            }
        }
        #endregion

        // Khi click xuat du lieu 
        private void buttonExportAllItems_Click(object sender, EventArgs e)
        {
            // Tạo một hộp thoại để người dùng chọn nơi lưu file
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "Excel Files (*.xlsx)|*.xlsx";
            saveFileDialog.Title = "Save Excel File";
            saveFileDialog.FileName = "ItemList";

            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    // Tạo một Workbook mới
                    using (var workbook = new XLWorkbook())
                    {
                        // Thêm một Worksheet mới vào Workbook
                        var worksheet = workbook.Worksheets.Add("Data");

                        // Ghi tiêu đề (Header) của DataGridView vào Excel
                        for (int i = 0; i < dgvItemList.Columns.Count; i++)
                        {
                            worksheet.Cell(1, i + 1).Value = dgvItemList.Columns[i].HeaderText;
                        }

                        // Ghi dữ liệu từ DataGridView vào Excel
                        for (int i = 0; i < dgvItemList.Rows.Count; i++)
                        {
                            for (int j = 0; j < dgvItemList.Columns.Count; j++)
                            {
                                // Kiểm tra giá trị cell không rỗng trước khi ghi
                                if (dgvItemList.Rows[i].Cells[j].Value != null)
                                {
                                    worksheet.Cell(i + 2, j + 1).Value = dgvItemList.Rows[i].Cells[j].Value.ToString();
                                }
                            }
                        }

                        // Tự động điều chỉnh độ rộng của các cột
                        worksheet.Columns().AdjustToContents();

                        // Lưu Workbook vào file
                        workbook.SaveAs(saveFileDialog.FileName);
                    }

                    MessageBox.Show("Data has been successfully exported to Excel!", "Notification", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred while exporting the file.: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }
}