﻿namespace My_Store
{
    partial class OrderForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(OrderForm));
            this.dgvOrderList = new System.Windows.Forms.DataGridView();
            this.textBoxSearchOrder = new System.Windows.Forms.TextBox();
            this.labelOrderId = new System.Windows.Forms.Label();
            this.labelCustomerId = new System.Windows.Forms.Label();
            this.dateTimePickerOrder = new System.Windows.Forms.DateTimePicker();
            this.labelOrderTime = new System.Windows.Forms.Label();
            this.textBoxCustomerId = new System.Windows.Forms.TextBox();
            this.labelTotalPrice = new System.Windows.Forms.Label();
            this.labelStaffId = new System.Windows.Forms.Label();
            this.dgvOrderDetail = new System.Windows.Forms.DataGridView();
            this.labelOrderQuantity = new System.Windows.Forms.Label();
            this.textBoxSearchItem = new System.Windows.Forms.TextBox();
            this.buttonSaveAllItemInOrder = new System.Windows.Forms.Button();
            this.buttonDeleteItemFromOrder = new System.Windows.Forms.Button();
            this.buttonAddItemToOrder = new System.Windows.Forms.Button();
            this.dgvItemList = new System.Windows.Forms.DataGridView();
            this.numericUpDownSelectQuantity = new System.Windows.Forms.NumericUpDown();
            this.labelItemName = new System.Windows.Forms.Label();
            this.buttonCreateNewOrder = new System.Windows.Forms.Button();
            this.labelOrderItemName = new System.Windows.Forms.Label();
            this.buttonSaveChangesInOrder = new System.Windows.Forms.Button();
            this.buttonDeleteOrder = new System.Windows.Forms.Button();
            this.textBoxTotalPrice = new System.Windows.Forms.TextBox();
            this.panelDetail = new System.Windows.Forms.Panel();
            this.buttonAddOrder = new System.Windows.Forms.Button();
            this.linkLabelFindOrAddCustomer = new System.Windows.Forms.LinkLabel();
            this.linkLabelCancelEdit = new System.Windows.Forms.LinkLabel();
            this.textBoxSearchItemInOrder = new System.Windows.Forms.TextBox();
            this.numOrderDetail = new System.Windows.Forms.NumericUpDown();
            this.buttonEditOrder = new System.Windows.Forms.Button();
            this.labelItemPrice = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvOrderList)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvOrderDetail)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvItemList)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownSelectQuantity)).BeginInit();
            this.panelDetail.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numOrderDetail)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvOrderList
            // 
            this.dgvOrderList.AllowUserToAddRows = false;
            this.dgvOrderList.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dgvOrderList.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvOrderList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvOrderList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvOrderList.Location = new System.Drawing.Point(12, 78);
            this.dgvOrderList.MultiSelect = false;
            this.dgvOrderList.Name = "dgvOrderList";
            this.dgvOrderList.ReadOnly = true;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 10F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvOrderList.RowHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dgvOrderList.RowHeadersWidth = 82;
            this.dgvOrderList.RowTemplate.Height = 40;
            this.dgvOrderList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvOrderList.Size = new System.Drawing.Size(995, 430);
            this.dgvOrderList.TabIndex = 25;
            this.dgvOrderList.SelectionChanged += new System.EventHandler(this.dgvOrderList_SelectionChanged);
            // 
            // textBoxSearchOrder
            // 
            this.textBoxSearchOrder.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.textBoxSearchOrder.Location = new System.Drawing.Point(12, 12);
            this.textBoxSearchOrder.Name = "textBoxSearchOrder";
            this.textBoxSearchOrder.Size = new System.Drawing.Size(995, 43);
            this.textBoxSearchOrder.TabIndex = 31;
            this.textBoxSearchOrder.Text = "Search Order";
            this.textBoxSearchOrder.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxSearchOrder.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxSearchOrder_KeyDown);
            // 
            // labelOrderId
            // 
            this.labelOrderId.AutoSize = true;
            this.labelOrderId.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.labelOrderId.Location = new System.Drawing.Point(12, 11);
            this.labelOrderId.Name = "labelOrderId";
            this.labelOrderId.Size = new System.Drawing.Size(128, 37);
            this.labelOrderId.TabIndex = 33;
            this.labelOrderId.Text = "Order Id: ";
            // 
            // labelCustomerId
            // 
            this.labelCustomerId.AutoSize = true;
            this.labelCustomerId.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.labelCustomerId.Location = new System.Drawing.Point(12, 71);
            this.labelCustomerId.Name = "labelCustomerId";
            this.labelCustomerId.Size = new System.Drawing.Size(174, 37);
            this.labelCustomerId.TabIndex = 34;
            this.labelCustomerId.Text = "Customer Id: ";
            // 
            // dateTimePickerOrder
            // 
            this.dateTimePickerOrder.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.dateTimePickerOrder.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePickerOrder.Location = new System.Drawing.Point(219, 126);
            this.dateTimePickerOrder.Name = "dateTimePickerOrder";
            this.dateTimePickerOrder.Size = new System.Drawing.Size(350, 43);
            this.dateTimePickerOrder.TabIndex = 35;
            this.dateTimePickerOrder.Value = new System.DateTime(2025, 7, 24, 0, 0, 0, 0);
            // 
            // labelOrderTime
            // 
            this.labelOrderTime.AutoSize = true;
            this.labelOrderTime.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.labelOrderTime.Location = new System.Drawing.Point(12, 131);
            this.labelOrderTime.Name = "labelOrderTime";
            this.labelOrderTime.Size = new System.Drawing.Size(158, 37);
            this.labelOrderTime.TabIndex = 36;
            this.labelOrderTime.Text = "Order time: ";
            // 
            // textBoxCustomerId
            // 
            this.textBoxCustomerId.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.textBoxCustomerId.Location = new System.Drawing.Point(219, 68);
            this.textBoxCustomerId.Name = "textBoxCustomerId";
            this.textBoxCustomerId.Size = new System.Drawing.Size(350, 43);
            this.textBoxCustomerId.TabIndex = 37;
            // 
            // labelTotalPrice
            // 
            this.labelTotalPrice.AutoSize = true;
            this.labelTotalPrice.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.labelTotalPrice.Location = new System.Drawing.Point(12, 191);
            this.labelTotalPrice.Name = "labelTotalPrice";
            this.labelTotalPrice.Size = new System.Drawing.Size(152, 37);
            this.labelTotalPrice.TabIndex = 38;
            this.labelTotalPrice.Text = "Total price: ";
            // 
            // labelStaffId
            // 
            this.labelStaffId.AutoSize = true;
            this.labelStaffId.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.labelStaffId.Location = new System.Drawing.Point(12, 251);
            this.labelStaffId.Name = "labelStaffId";
            this.labelStaffId.Size = new System.Drawing.Size(112, 37);
            this.labelStaffId.TabIndex = 40;
            this.labelStaffId.Text = "Staff Id: ";
            // 
            // dgvOrderDetail
            // 
            this.dgvOrderDetail.AllowUserToAddRows = false;
            this.dgvOrderDetail.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dgvOrderDetail.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvOrderDetail.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgvOrderDetail.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.875F);
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvOrderDetail.DefaultCellStyle = dataGridViewCellStyle4;
            this.dgvOrderDetail.Location = new System.Drawing.Point(1047, 706);
            this.dgvOrderDetail.MultiSelect = false;
            this.dgvOrderDetail.Name = "dgvOrderDetail";
            this.dgvOrderDetail.ReadOnly = true;
            this.dgvOrderDetail.RowHeadersWidth = 82;
            this.dgvOrderDetail.RowTemplate.Height = 40;
            this.dgvOrderDetail.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvOrderDetail.Size = new System.Drawing.Size(995, 408);
            this.dgvOrderDetail.TabIndex = 42;
            this.dgvOrderDetail.SelectionChanged += new System.EventHandler(this.dgvOrderDetail_SelectionChanged);
            // 
            // labelOrderQuantity
            // 
            this.labelOrderQuantity.AutoSize = true;
            this.labelOrderQuantity.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.labelOrderQuantity.Location = new System.Drawing.Point(1040, 1169);
            this.labelOrderQuantity.Name = "labelOrderQuantity";
            this.labelOrderQuantity.Size = new System.Drawing.Size(132, 37);
            this.labelOrderQuantity.TabIndex = 48;
            this.labelOrderQuantity.Text = "Quantity: ";
            // 
            // textBoxSearchItem
            // 
            this.textBoxSearchItem.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.textBoxSearchItem.Location = new System.Drawing.Point(1047, 12);
            this.textBoxSearchItem.Name = "textBoxSearchItem";
            this.textBoxSearchItem.Size = new System.Drawing.Size(995, 43);
            this.textBoxSearchItem.TabIndex = 50;
            this.textBoxSearchItem.Text = "Search Item";
            this.textBoxSearchItem.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxSearchItem.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxSearchItem_KeyDown);
            // 
            // buttonSaveAllItemInOrder
            // 
            this.buttonSaveAllItemInOrder.BackColor = System.Drawing.Color.LimeGreen;
            this.buttonSaveAllItemInOrder.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSaveAllItemInOrder.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.buttonSaveAllItemInOrder.ForeColor = System.Drawing.Color.White;
            this.buttonSaveAllItemInOrder.Location = new System.Drawing.Point(1842, 1159);
            this.buttonSaveAllItemInOrder.Name = "buttonSaveAllItemInOrder";
            this.buttonSaveAllItemInOrder.Size = new System.Drawing.Size(200, 60);
            this.buttonSaveAllItemInOrder.TabIndex = 51;
            this.buttonSaveAllItemInOrder.Text = "Complete List";
            this.buttonSaveAllItemInOrder.UseVisualStyleBackColor = false;
            this.buttonSaveAllItemInOrder.Click += new System.EventHandler(this.buttonSaveAllItemInOrder_Click);
            // 
            // buttonDeleteItemFromOrder
            // 
            this.buttonDeleteItemFromOrder.BackColor = System.Drawing.Color.LightCoral;
            this.buttonDeleteItemFromOrder.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonDeleteItemFromOrder.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.buttonDeleteItemFromOrder.ForeColor = System.Drawing.Color.White;
            this.buttonDeleteItemFromOrder.Location = new System.Drawing.Point(1582, 1159);
            this.buttonDeleteItemFromOrder.Name = "buttonDeleteItemFromOrder";
            this.buttonDeleteItemFromOrder.Size = new System.Drawing.Size(200, 60);
            this.buttonDeleteItemFromOrder.TabIndex = 53;
            this.buttonDeleteItemFromOrder.Text = "Remove Item";
            this.buttonDeleteItemFromOrder.UseVisualStyleBackColor = false;
            this.buttonDeleteItemFromOrder.Click += new System.EventHandler(this.buttonDeleteItemFromOrder_Click);
            // 
            // buttonAddItemToOrder
            // 
            this.buttonAddItemToOrder.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.buttonAddItemToOrder.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAddItemToOrder.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.buttonAddItemToOrder.ForeColor = System.Drawing.Color.White;
            this.buttonAddItemToOrder.Location = new System.Drawing.Point(1892, 559);
            this.buttonAddItemToOrder.Name = "buttonAddItemToOrder";
            this.buttonAddItemToOrder.Size = new System.Drawing.Size(150, 60);
            this.buttonAddItemToOrder.TabIndex = 54;
            this.buttonAddItemToOrder.Text = "Add";
            this.buttonAddItemToOrder.UseVisualStyleBackColor = false;
            this.buttonAddItemToOrder.Click += new System.EventHandler(this.buttonAddItemToOrder_Click);
            // 
            // dgvItemList
            // 
            this.dgvItemList.AllowUserToAddRows = false;
            this.dgvItemList.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dgvItemList.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvItemList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.dgvItemList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvItemList.Location = new System.Drawing.Point(1047, 78);
            this.dgvItemList.MultiSelect = false;
            this.dgvItemList.Name = "dgvItemList";
            this.dgvItemList.ReadOnly = true;
            this.dgvItemList.RowHeadersWidth = 82;
            this.dgvItemList.RowTemplate.Height = 40;
            this.dgvItemList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvItemList.Size = new System.Drawing.Size(995, 430);
            this.dgvItemList.TabIndex = 56;
            this.dgvItemList.SelectionChanged += new System.EventHandler(this.dgvItemList_SelectionChanged);
            // 
            // numericUpDownSelectQuantity
            // 
            this.numericUpDownSelectQuantity.Font = new System.Drawing.Font("Segoe UI", 14.5F);
            this.numericUpDownSelectQuantity.Location = new System.Drawing.Point(1736, 560);
            this.numericUpDownSelectQuantity.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numericUpDownSelectQuantity.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownSelectQuantity.Name = "numericUpDownSelectQuantity";
            this.numericUpDownSelectQuantity.Size = new System.Drawing.Size(150, 59);
            this.numericUpDownSelectQuantity.TabIndex = 57;
            this.numericUpDownSelectQuantity.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUpDownSelectQuantity.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // labelItemName
            // 
            this.labelItemName.AutoSize = true;
            this.labelItemName.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelItemName.Location = new System.Drawing.Point(1039, 565);
            this.labelItemName.Name = "labelItemName";
            this.labelItemName.Size = new System.Drawing.Size(173, 45);
            this.labelItemName.TabIndex = 60;
            this.labelItemName.Text = "Item name";
            // 
            // buttonCreateNewOrder
            // 
            this.buttonCreateNewOrder.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.buttonCreateNewOrder.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonCreateNewOrder.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.buttonCreateNewOrder.ForeColor = System.Drawing.Color.White;
            this.buttonCreateNewOrder.Location = new System.Drawing.Point(12, 514);
            this.buttonCreateNewOrder.Name = "buttonCreateNewOrder";
            this.buttonCreateNewOrder.Size = new System.Drawing.Size(200, 60);
            this.buttonCreateNewOrder.TabIndex = 62;
            this.buttonCreateNewOrder.Text = "New Order";
            this.buttonCreateNewOrder.UseVisualStyleBackColor = false;
            this.buttonCreateNewOrder.Click += new System.EventHandler(this.buttonCreateNewOrder_Click);
            // 
            // labelOrderItemName
            // 
            this.labelOrderItemName.AutoSize = true;
            this.labelOrderItemName.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.labelOrderItemName.Location = new System.Drawing.Point(1040, 1117);
            this.labelOrderItemName.Name = "labelOrderItemName";
            this.labelOrderItemName.Size = new System.Drawing.Size(148, 37);
            this.labelOrderItemName.TabIndex = 63;
            this.labelOrderItemName.Text = "Item Name\r\n";
            // 
            // buttonSaveChangesInOrder
            // 
            this.buttonSaveChangesInOrder.BackColor = System.Drawing.Color.LimeGreen;
            this.buttonSaveChangesInOrder.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSaveChangesInOrder.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.buttonSaveChangesInOrder.ForeColor = System.Drawing.Color.White;
            this.buttonSaveChangesInOrder.Location = new System.Drawing.Point(830, 565);
            this.buttonSaveChangesInOrder.Name = "buttonSaveChangesInOrder";
            this.buttonSaveChangesInOrder.Size = new System.Drawing.Size(150, 60);
            this.buttonSaveChangesInOrder.TabIndex = 64;
            this.buttonSaveChangesInOrder.Text = "Save";
            this.buttonSaveChangesInOrder.UseVisualStyleBackColor = false;
            this.buttonSaveChangesInOrder.Click += new System.EventHandler(this.buttonSaveChangesInOrder_Click);
            // 
            // buttonDeleteOrder
            // 
            this.buttonDeleteOrder.BackColor = System.Drawing.Color.LightCoral;
            this.buttonDeleteOrder.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonDeleteOrder.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.buttonDeleteOrder.ForeColor = System.Drawing.Color.White;
            this.buttonDeleteOrder.Location = new System.Drawing.Point(19, 565);
            this.buttonDeleteOrder.Name = "buttonDeleteOrder";
            this.buttonDeleteOrder.Size = new System.Drawing.Size(200, 60);
            this.buttonDeleteOrder.TabIndex = 65;
            this.buttonDeleteOrder.Text = "Delete Order";
            this.buttonDeleteOrder.UseVisualStyleBackColor = false;
            this.buttonDeleteOrder.Click += new System.EventHandler(this.buttonDeleteOrder_Click);
            // 
            // textBoxTotalPrice
            // 
            this.textBoxTotalPrice.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.textBoxTotalPrice.Location = new System.Drawing.Point(219, 188);
            this.textBoxTotalPrice.Name = "textBoxTotalPrice";
            this.textBoxTotalPrice.Size = new System.Drawing.Size(350, 43);
            this.textBoxTotalPrice.TabIndex = 39;
            // 
            // panelDetail
            // 
            this.panelDetail.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelDetail.Controls.Add(this.buttonAddOrder);
            this.panelDetail.Controls.Add(this.linkLabelFindOrAddCustomer);
            this.panelDetail.Controls.Add(this.labelOrderId);
            this.panelDetail.Controls.Add(this.buttonDeleteOrder);
            this.panelDetail.Controls.Add(this.labelCustomerId);
            this.panelDetail.Controls.Add(this.buttonSaveChangesInOrder);
            this.panelDetail.Controls.Add(this.textBoxCustomerId);
            this.panelDetail.Controls.Add(this.labelOrderTime);
            this.panelDetail.Controls.Add(this.dateTimePickerOrder);
            this.panelDetail.Controls.Add(this.labelTotalPrice);
            this.panelDetail.Controls.Add(this.textBoxTotalPrice);
            this.panelDetail.Controls.Add(this.labelStaffId);
            this.panelDetail.Location = new System.Drawing.Point(12, 580);
            this.panelDetail.Name = "panelDetail";
            this.panelDetail.Size = new System.Drawing.Size(995, 637);
            this.panelDetail.TabIndex = 66;
            // 
            // buttonAddOrder
            // 
            this.buttonAddOrder.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.buttonAddOrder.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAddOrder.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.buttonAddOrder.ForeColor = System.Drawing.Color.White;
            this.buttonAddOrder.Location = new System.Drawing.Point(674, 565);
            this.buttonAddOrder.Name = "buttonAddOrder";
            this.buttonAddOrder.Size = new System.Drawing.Size(150, 60);
            this.buttonAddOrder.TabIndex = 68;
            this.buttonAddOrder.Text = "Add";
            this.buttonAddOrder.UseVisualStyleBackColor = false;
            this.buttonAddOrder.Click += new System.EventHandler(this.buttonAddOrder_Click);
            // 
            // linkLabelFindOrAddCustomer
            // 
            this.linkLabelFindOrAddCustomer.AutoSize = true;
            this.linkLabelFindOrAddCustomer.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.linkLabelFindOrAddCustomer.LinkColor = System.Drawing.Color.DeepSkyBlue;
            this.linkLabelFindOrAddCustomer.Location = new System.Drawing.Point(575, 71);
            this.linkLabelFindOrAddCustomer.Name = "linkLabelFindOrAddCustomer";
            this.linkLabelFindOrAddCustomer.Size = new System.Drawing.Size(325, 74);
            this.linkLabelFindOrAddCustomer.TabIndex = 67;
            this.linkLabelFindOrAddCustomer.TabStop = true;
            this.linkLabelFindOrAddCustomer.Text = "Find or add new customer\r\n\r\n";
            this.linkLabelFindOrAddCustomer.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabelFindOrAddCustomer_LinkClicked);
            // 
            // linkLabelCancelEdit
            // 
            this.linkLabelCancelEdit.AutoSize = true;
            this.linkLabelCancelEdit.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.linkLabelCancelEdit.LinkColor = System.Drawing.Color.DeepSkyBlue;
            this.linkLabelCancelEdit.Location = new System.Drawing.Point(424, 526);
            this.linkLabelCancelEdit.Name = "linkLabelCancelEdit";
            this.linkLabelCancelEdit.Size = new System.Drawing.Size(149, 37);
            this.linkLabelCancelEdit.TabIndex = 66;
            this.linkLabelCancelEdit.TabStop = true;
            this.linkLabelCancelEdit.Text = "Cancel edit";
            this.linkLabelCancelEdit.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabelCancelEdit_LinkClicked);
            // 
            // textBoxSearchItemInOrder
            // 
            this.textBoxSearchItemInOrder.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.textBoxSearchItemInOrder.Location = new System.Drawing.Point(1047, 645);
            this.textBoxSearchItemInOrder.Name = "textBoxSearchItemInOrder";
            this.textBoxSearchItemInOrder.Size = new System.Drawing.Size(995, 43);
            this.textBoxSearchItemInOrder.TabIndex = 67;
            this.textBoxSearchItemInOrder.Text = "Search item in order";
            this.textBoxSearchItemInOrder.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxSearchItemInOrder.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxSearchItemInOrder_KeyDown);
            // 
            // numOrderDetail
            // 
            this.numOrderDetail.Font = new System.Drawing.Font("Segoe UI", 14.5F);
            this.numOrderDetail.Location = new System.Drawing.Point(1178, 1157);
            this.numOrderDetail.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numOrderDetail.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numOrderDetail.Name = "numOrderDetail";
            this.numOrderDetail.Size = new System.Drawing.Size(150, 59);
            this.numOrderDetail.TabIndex = 68;
            this.numOrderDetail.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numOrderDetail.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numOrderDetail.ValueChanged += new System.EventHandler(this.numOrderDetail_ValueChanged);
            // 
            // buttonEditOrder
            // 
            this.buttonEditOrder.BackColor = System.Drawing.Color.MediumOrchid;
            this.buttonEditOrder.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonEditOrder.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.buttonEditOrder.ForeColor = System.Drawing.Color.White;
            this.buttonEditOrder.Location = new System.Drawing.Point(218, 514);
            this.buttonEditOrder.Name = "buttonEditOrder";
            this.buttonEditOrder.Size = new System.Drawing.Size(200, 60);
            this.buttonEditOrder.TabIndex = 69;
            this.buttonEditOrder.Text = "Edit Order";
            this.buttonEditOrder.UseVisualStyleBackColor = false;
            this.buttonEditOrder.Click += new System.EventHandler(this.buttonEditOrder_Click);
            // 
            // labelItemPrice
            // 
            this.labelItemPrice.AutoSize = true;
            this.labelItemPrice.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelItemPrice.Location = new System.Drawing.Point(1039, 511);
            this.labelItemPrice.Name = "labelItemPrice";
            this.labelItemPrice.Size = new System.Drawing.Size(163, 45);
            this.labelItemPrice.TabIndex = 70;
            this.labelItemPrice.Text = "Item Price";
            // 
            // OrderForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(2054, 1229);
            this.Controls.Add(this.labelItemPrice);
            this.Controls.Add(this.linkLabelCancelEdit);
            this.Controls.Add(this.buttonEditOrder);
            this.Controls.Add(this.numOrderDetail);
            this.Controls.Add(this.textBoxSearchItemInOrder);
            this.Controls.Add(this.panelDetail);
            this.Controls.Add(this.labelOrderItemName);
            this.Controls.Add(this.buttonCreateNewOrder);
            this.Controls.Add(this.labelItemName);
            this.Controls.Add(this.numericUpDownSelectQuantity);
            this.Controls.Add(this.dgvItemList);
            this.Controls.Add(this.buttonAddItemToOrder);
            this.Controls.Add(this.buttonDeleteItemFromOrder);
            this.Controls.Add(this.buttonSaveAllItemInOrder);
            this.Controls.Add(this.textBoxSearchItem);
            this.Controls.Add(this.labelOrderQuantity);
            this.Controls.Add(this.dgvOrderList);
            this.Controls.Add(this.dgvOrderDetail);
            this.Controls.Add(this.textBoxSearchOrder);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "OrderForm";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Order Management";
            this.Load += new System.EventHandler(this.OrderForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvOrderList)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvOrderDetail)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvItemList)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownSelectQuantity)).EndInit();
            this.panelDetail.ResumeLayout(false);
            this.panelDetail.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numOrderDetail)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.DataGridView dgvOrderList;
        private System.Windows.Forms.TextBox textBoxSearchOrder;
        private System.Windows.Forms.Label labelOrderId;
        private System.Windows.Forms.Label labelCustomerId;
        private System.Windows.Forms.Label labelOrderTime;
        private System.Windows.Forms.DateTimePicker dateTimePickerOrder;
        private System.Windows.Forms.TextBox textBoxCustomerId;
        private System.Windows.Forms.Label labelTotalPrice;
        private System.Windows.Forms.Label labelStaffId;
        private System.Windows.Forms.Label labelOrderQuantity;
        private System.Windows.Forms.DataGridView dgvOrderDetail;
        private System.Windows.Forms.TextBox textBoxSearchItem;
        private System.Windows.Forms.Button buttonSaveAllItemInOrder;
        private System.Windows.Forms.Button buttonDeleteItemFromOrder;
        private System.Windows.Forms.Button buttonAddItemToOrder;
        private System.Windows.Forms.DataGridView dgvItemList;
        private System.Windows.Forms.NumericUpDown numericUpDownSelectQuantity;
        private System.Windows.Forms.Label labelItemName;
        private System.Windows.Forms.Button buttonCreateNewOrder;
        private System.Windows.Forms.Label labelOrderItemName;
        private System.Windows.Forms.Button buttonSaveChangesInOrder;
        private System.Windows.Forms.Button buttonDeleteOrder;
        private System.Windows.Forms.TextBox textBoxTotalPrice;
        private System.Windows.Forms.Panel panelDetail;
        private System.Windows.Forms.TextBox textBoxSearchItemInOrder;
        private System.Windows.Forms.NumericUpDown numOrderDetail;
        private System.Windows.Forms.Button buttonEditOrder;
        private System.Windows.Forms.LinkLabel linkLabelCancelEdit;
        private System.Windows.Forms.LinkLabel linkLabelFindOrAddCustomer;
        private System.Windows.Forms.Label labelItemPrice;
        private System.Windows.Forms.Button buttonAddOrder;
    }
}