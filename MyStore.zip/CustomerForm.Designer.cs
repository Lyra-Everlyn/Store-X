﻿namespace My_Store
{
    partial class CustomerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CustomerForm));
            this.labelCustomerId = new System.Windows.Forms.Label();
            this.labelCustomerName = new System.Windows.Forms.Label();
            this.labelCustomerPhoneNumber = new System.Windows.Forms.Label();
            this.labelCustomerAddress = new System.Windows.Forms.Label();
            this.textBoxCustomerName = new System.Windows.Forms.TextBox();
            this.textBoxPhoneNumber = new System.Windows.Forms.TextBox();
            this.richTextBoxAddress = new System.Windows.Forms.RichTextBox();
            this.buttonSaveChanges = new System.Windows.Forms.Button();
            this.buttonAddCustomer = new System.Windows.Forms.Button();
            this.buttonDeleteCustomer = new System.Windows.Forms.Button();
            this.dgvCustomerList = new System.Windows.Forms.DataGridView();
            this.checkBoxShowDeletedCustomer = new System.Windows.Forms.CheckBox();
            this.dgvOrderHistory = new System.Windows.Forms.DataGridView();
            this.textBoxSearchCustomer = new System.Windows.Forms.TextBox();
            this.labelOrderHistory = new System.Windows.Forms.Label();
            this.buttonCreateNewCustomer = new System.Windows.Forms.Button();
            this.buttonEditCustomer = new System.Windows.Forms.Button();
            this.linkLabelCancelEditCustomer = new System.Windows.Forms.LinkLabel();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCustomerList)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvOrderHistory)).BeginInit();
            this.SuspendLayout();
            // 
            // labelCustomerId
            // 
            this.labelCustomerId.AutoSize = true;
            this.labelCustomerId.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.labelCustomerId.Location = new System.Drawing.Point(5, 75);
            this.labelCustomerId.Name = "labelCustomerId";
            this.labelCustomerId.Size = new System.Drawing.Size(174, 37);
            this.labelCustomerId.TabIndex = 7;
            this.labelCustomerId.Text = "Customer Id: ";
            // 
            // labelCustomerName
            // 
            this.labelCustomerName.AutoSize = true;
            this.labelCustomerName.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.labelCustomerName.Location = new System.Drawing.Point(5, 138);
            this.labelCustomerName.Name = "labelCustomerName";
            this.labelCustomerName.Size = new System.Drawing.Size(222, 37);
            this.labelCustomerName.TabIndex = 8;
            this.labelCustomerName.Text = "Customer Name: ";
            // 
            // labelCustomerPhoneNumber
            // 
            this.labelCustomerPhoneNumber.AutoSize = true;
            this.labelCustomerPhoneNumber.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.labelCustomerPhoneNumber.Location = new System.Drawing.Point(10, 195);
            this.labelCustomerPhoneNumber.Name = "labelCustomerPhoneNumber";
            this.labelCustomerPhoneNumber.Size = new System.Drawing.Size(209, 37);
            this.labelCustomerPhoneNumber.TabIndex = 9;
            this.labelCustomerPhoneNumber.Text = "Phone Number: ";
            // 
            // labelCustomerAddress
            // 
            this.labelCustomerAddress.AutoSize = true;
            this.labelCustomerAddress.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.labelCustomerAddress.Location = new System.Drawing.Point(10, 255);
            this.labelCustomerAddress.Name = "labelCustomerAddress";
            this.labelCustomerAddress.Size = new System.Drawing.Size(124, 37);
            this.labelCustomerAddress.TabIndex = 10;
            this.labelCustomerAddress.Text = "Address: ";
            // 
            // textBoxCustomerName
            // 
            this.textBoxCustomerName.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.textBoxCustomerName.Location = new System.Drawing.Point(238, 135);
            this.textBoxCustomerName.Name = "textBoxCustomerName";
            this.textBoxCustomerName.Size = new System.Drawing.Size(350, 43);
            this.textBoxCustomerName.TabIndex = 11;
            // 
            // textBoxPhoneNumber
            // 
            this.textBoxPhoneNumber.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.textBoxPhoneNumber.Location = new System.Drawing.Point(238, 192);
            this.textBoxPhoneNumber.Name = "textBoxPhoneNumber";
            this.textBoxPhoneNumber.Size = new System.Drawing.Size(350, 43);
            this.textBoxPhoneNumber.TabIndex = 12;
            // 
            // richTextBoxAddress
            // 
            this.richTextBoxAddress.BackColor = System.Drawing.Color.WhiteSmoke;
            this.richTextBoxAddress.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.richTextBoxAddress.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.richTextBoxAddress.Location = new System.Drawing.Point(17, 295);
            this.richTextBoxAddress.Name = "richTextBoxAddress";
            this.richTextBoxAddress.Size = new System.Drawing.Size(571, 100);
            this.richTextBoxAddress.TabIndex = 13;
            this.richTextBoxAddress.Text = "";
            // 
            // buttonSaveChanges
            // 
            this.buttonSaveChanges.BackColor = System.Drawing.Color.LimeGreen;
            this.buttonSaveChanges.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSaveChanges.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.buttonSaveChanges.ForeColor = System.Drawing.Color.White;
            this.buttonSaveChanges.Location = new System.Drawing.Point(12, 1057);
            this.buttonSaveChanges.Name = "buttonSaveChanges";
            this.buttonSaveChanges.Size = new System.Drawing.Size(150, 60);
            this.buttonSaveChanges.TabIndex = 21;
            this.buttonSaveChanges.Text = "Save";
            this.buttonSaveChanges.UseVisualStyleBackColor = false;
            this.buttonSaveChanges.Click += new System.EventHandler(this.buttonSaveChanges_Click);
            // 
            // buttonAddCustomer
            // 
            this.buttonAddCustomer.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.buttonAddCustomer.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAddCustomer.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.buttonAddCustomer.ForeColor = System.Drawing.Color.White;
            this.buttonAddCustomer.Location = new System.Drawing.Point(168, 1057);
            this.buttonAddCustomer.Name = "buttonAddCustomer";
            this.buttonAddCustomer.Size = new System.Drawing.Size(150, 60);
            this.buttonAddCustomer.TabIndex = 22;
            this.buttonAddCustomer.Text = "Add";
            this.buttonAddCustomer.UseVisualStyleBackColor = false;
            this.buttonAddCustomer.Click += new System.EventHandler(this.buttonAddCustomer_Click);
            // 
            // buttonDeleteCustomer
            // 
            this.buttonDeleteCustomer.BackColor = System.Drawing.Color.LightCoral;
            this.buttonDeleteCustomer.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonDeleteCustomer.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.buttonDeleteCustomer.ForeColor = System.Drawing.Color.White;
            this.buttonDeleteCustomer.Location = new System.Drawing.Point(433, 1057);
            this.buttonDeleteCustomer.Name = "buttonDeleteCustomer";
            this.buttonDeleteCustomer.Size = new System.Drawing.Size(150, 60);
            this.buttonDeleteCustomer.TabIndex = 23;
            this.buttonDeleteCustomer.Text = "Delete";
            this.buttonDeleteCustomer.UseVisualStyleBackColor = false;
            this.buttonDeleteCustomer.Click += new System.EventHandler(this.buttonDeleteCustomer_Click);
            // 
            // dgvCustomerList
            // 
            this.dgvCustomerList.AllowUserToAddRows = false;
            this.dgvCustomerList.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dgvCustomerList.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 9F);
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvCustomerList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvCustomerList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCustomerList.Location = new System.Drawing.Point(622, 108);
            this.dgvCustomerList.MultiSelect = false;
            this.dgvCustomerList.Name = "dgvCustomerList";
            this.dgvCustomerList.ReadOnly = true;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 10F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvCustomerList.RowHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dgvCustomerList.RowHeadersWidth = 82;
            this.dgvCustomerList.RowTemplate.Height = 33;
            this.dgvCustomerList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvCustomerList.Size = new System.Drawing.Size(1260, 1009);
            this.dgvCustomerList.TabIndex = 24;
            this.dgvCustomerList.SelectionChanged += new System.EventHandler(this.dgvCustomerList_SelectionChanged);
            // 
            // checkBoxShowDeletedCustomer
            // 
            this.checkBoxShowDeletedCustomer.AutoSize = true;
            this.checkBoxShowDeletedCustomer.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.checkBoxShowDeletedCustomer.Location = new System.Drawing.Point(622, 61);
            this.checkBoxShowDeletedCustomer.Name = "checkBoxShowDeletedCustomer";
            this.checkBoxShowDeletedCustomer.Size = new System.Drawing.Size(335, 41);
            this.checkBoxShowDeletedCustomer.TabIndex = 25;
            this.checkBoxShowDeletedCustomer.Text = "Show Deleted Customer";
            this.checkBoxShowDeletedCustomer.UseVisualStyleBackColor = true;
            this.checkBoxShowDeletedCustomer.CheckedChanged += new System.EventHandler(this.checkBoxShowDeletedCustomer_CheckedChanged);
            // 
            // dgvOrderHistory
            // 
            this.dgvOrderHistory.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dgvOrderHistory.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvOrderHistory.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvOrderHistory.Location = new System.Drawing.Point(12, 438);
            this.dgvOrderHistory.MultiSelect = false;
            this.dgvOrderHistory.Name = "dgvOrderHistory";
            this.dgvOrderHistory.ReadOnly = true;
            this.dgvOrderHistory.RowHeadersWidth = 82;
            this.dgvOrderHistory.RowTemplate.Height = 33;
            this.dgvOrderHistory.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvOrderHistory.Size = new System.Drawing.Size(576, 605);
            this.dgvOrderHistory.TabIndex = 26;
            // 
            // textBoxSearchCustomer
            // 
            this.textBoxSearchCustomer.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.textBoxSearchCustomer.Location = new System.Drawing.Point(622, 12);
            this.textBoxSearchCustomer.Name = "textBoxSearchCustomer";
            this.textBoxSearchCustomer.Size = new System.Drawing.Size(1260, 43);
            this.textBoxSearchCustomer.TabIndex = 27;
            this.textBoxSearchCustomer.Text = "Search Customer";
            this.textBoxSearchCustomer.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxSearchCustomer.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxSearchCustomer_KeyDown);
            // 
            // labelOrderHistory
            // 
            this.labelOrderHistory.AutoSize = true;
            this.labelOrderHistory.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.labelOrderHistory.Location = new System.Drawing.Point(12, 398);
            this.labelOrderHistory.Name = "labelOrderHistory";
            this.labelOrderHistory.Size = new System.Drawing.Size(189, 37);
            this.labelOrderHistory.TabIndex = 28;
            this.labelOrderHistory.Text = "Order History: ";
            // 
            // buttonCreateNewCustomer
            // 
            this.buttonCreateNewCustomer.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.buttonCreateNewCustomer.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonCreateNewCustomer.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.buttonCreateNewCustomer.ForeColor = System.Drawing.Color.White;
            this.buttonCreateNewCustomer.Location = new System.Drawing.Point(12, 12);
            this.buttonCreateNewCustomer.Name = "buttonCreateNewCustomer";
            this.buttonCreateNewCustomer.Size = new System.Drawing.Size(200, 60);
            this.buttonCreateNewCustomer.TabIndex = 66;
            this.buttonCreateNewCustomer.Text = "New";
            this.buttonCreateNewCustomer.UseVisualStyleBackColor = false;
            this.buttonCreateNewCustomer.Click += new System.EventHandler(this.buttonCreateNewCustomer_Click);
            // 
            // buttonEditCustomer
            // 
            this.buttonEditCustomer.BackColor = System.Drawing.Color.MediumOrchid;
            this.buttonEditCustomer.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonEditCustomer.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.buttonEditCustomer.ForeColor = System.Drawing.Color.White;
            this.buttonEditCustomer.Location = new System.Drawing.Point(218, 12);
            this.buttonEditCustomer.Name = "buttonEditCustomer";
            this.buttonEditCustomer.Size = new System.Drawing.Size(200, 60);
            this.buttonEditCustomer.TabIndex = 73;
            this.buttonEditCustomer.Text = "Edit Customer";
            this.buttonEditCustomer.UseVisualStyleBackColor = false;
            this.buttonEditCustomer.Click += new System.EventHandler(this.buttonEditCustomer_Click);
            // 
            // linkLabelCancelEditCustomer
            // 
            this.linkLabelCancelEditCustomer.AutoSize = true;
            this.linkLabelCancelEditCustomer.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.linkLabelCancelEditCustomer.LinkColor = System.Drawing.Color.DeepSkyBlue;
            this.linkLabelCancelEditCustomer.Location = new System.Drawing.Point(424, 24);
            this.linkLabelCancelEditCustomer.Name = "linkLabelCancelEditCustomer";
            this.linkLabelCancelEditCustomer.Size = new System.Drawing.Size(149, 37);
            this.linkLabelCancelEditCustomer.TabIndex = 74;
            this.linkLabelCancelEditCustomer.TabStop = true;
            this.linkLabelCancelEditCustomer.Text = "Cancel edit";
            this.linkLabelCancelEditCustomer.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabelCancelEditCustomer_LinkClicked);
            // 
            // CustomerForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1894, 1129);
            this.Controls.Add(this.linkLabelCancelEditCustomer);
            this.Controls.Add(this.buttonEditCustomer);
            this.Controls.Add(this.buttonCreateNewCustomer);
            this.Controls.Add(this.labelOrderHistory);
            this.Controls.Add(this.textBoxSearchCustomer);
            this.Controls.Add(this.dgvOrderHistory);
            this.Controls.Add(this.checkBoxShowDeletedCustomer);
            this.Controls.Add(this.dgvCustomerList);
            this.Controls.Add(this.buttonDeleteCustomer);
            this.Controls.Add(this.buttonAddCustomer);
            this.Controls.Add(this.buttonSaveChanges);
            this.Controls.Add(this.richTextBoxAddress);
            this.Controls.Add(this.textBoxPhoneNumber);
            this.Controls.Add(this.textBoxCustomerName);
            this.Controls.Add(this.labelCustomerAddress);
            this.Controls.Add(this.labelCustomerPhoneNumber);
            this.Controls.Add(this.labelCustomerName);
            this.Controls.Add(this.labelCustomerId);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "CustomerForm";
            this.Text = "Customer Managerment";
            this.Load += new System.EventHandler(this.CustomerForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvCustomerList)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvOrderHistory)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelCustomerId;
        private System.Windows.Forms.Label labelCustomerName;
        private System.Windows.Forms.Label labelCustomerPhoneNumber;
        private System.Windows.Forms.Label labelCustomerAddress;
        private System.Windows.Forms.TextBox textBoxCustomerName;
        private System.Windows.Forms.TextBox textBoxPhoneNumber;
        private System.Windows.Forms.RichTextBox richTextBoxAddress;
        private System.Windows.Forms.Button buttonSaveChanges;
        private System.Windows.Forms.Button buttonAddCustomer;
        private System.Windows.Forms.Button buttonDeleteCustomer;
        private System.Windows.Forms.DataGridView dgvCustomerList;
        private System.Windows.Forms.CheckBox checkBoxShowDeletedCustomer;
        private System.Windows.Forms.DataGridView dgvOrderHistory;
        private System.Windows.Forms.TextBox textBoxSearchCustomer;
        private System.Windows.Forms.Label labelOrderHistory;
        private System.Windows.Forms.Button buttonCreateNewCustomer;
        private System.Windows.Forms.Button buttonEditCustomer;
        private System.Windows.Forms.LinkLabel linkLabelCancelEditCustomer;
    }
}