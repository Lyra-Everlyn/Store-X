﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace My_Store
{
    public partial class OrderForm : Form
    {
        private string connectionString;
        private int selectedItemId = -1;
        private int selectedOrderId = -1;

        private DataTable orderDetailTempTable; //Bảng tạm thời để giữ các chi tiết đơn hàng (dùng khi tạo/sửa đơn)
        private DataView orderDetailView;       // Bản đã lọc (kết quả tìm kiếm được lấy từ bản gốc là orderDetailTempTable)

        private string switchModeState;         // Biến để theo dõi trạng thái hiện tại của form (view, edit, add)
        
        public OrderForm()
        {
            InitializeComponent();
            this.connectionString = ConfigurationManager.ConnectionStrings["StoreMNGConnectionString"].ConnectionString;
            createOrderDetailTempTable(); // Khởi tạo bảng tạm chứa chi tiết đơn hàng
        }

        // Khi form được load
        private void OrderForm_Load(object sender, EventArgs e)
        {
            loadOrderData();
            loadItemData();
            switchMode("view");
            clearOrderDetails();
            labelStaffId.Text = "Staff Id: " + CurrentUser.StaffId.ToString();
        }


        // Khởi tạo DataTable để lưu trữ các mặt hàng cho một đơn hàng mới
        private void createOrderDetailTempTable()
        {
            orderDetailTempTable = new DataTable();
            orderDetailTempTable.Columns.Add("Item Id", typeof(int));
            orderDetailTempTable.Columns.Add("Item Name", typeof(string));
            orderDetailTempTable.Columns.Add("Quantity", typeof(int));
            orderDetailTempTable.Columns.Add("Item Price", typeof(decimal));
        }


        #region Load dữ liệu đơn hàng 
        // Phương thức load tổng quan đơn hàng (chứa id đơn hàng, id khách hàng, ngày đặt hàng, tổng tiền, id nhân viên)
        private void loadOrderData()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string detailedRevenueThisMonthQuery = @"
                        SELECT
                            O.orderId AS [Order Id],
                            O.customerId AS [Customer Id],
                            CAST(O.orderDate AS DATE) AS [Order Time],
                            S.staffId AS [Staff Id],
                            O.totalPrice AS [Total Price]
                        FROM Orders O
                        LEFT JOIN Staff S ON O.staffId = S.staffId
                        WHERE MONTH(O.orderDate) = MONTH(GETDATE()) AND YEAR(O.orderDate) = YEAR(GETDATE())
                        ORDER BY O.orderDate DESC;";

                    SqlDataAdapter detailedAdapter = new SqlDataAdapter(detailedRevenueThisMonthQuery, connection);
                    DataTable detailedData = new DataTable();
                    detailedAdapter.Fill(detailedData);

                    dgvOrderList.DataSource = detailedData;
                    dgvOrderList.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Loading Failed: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Phương thức load chi tiết đơn hàng (chứa id đơn hàng, vật phẩm, số lượng)
        private void loadOrderDetailData(int orderId)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = @"
                        SELECT
                            OD.orderId AS [Order Id],
                            OD.itemId AS [Item Id],
                            I.itemName AS [Item Name],
                            OD.quantity AS [Quantity],
                            I.itemPrice AS [Item Price]
                        FROM OrderDetail OD
                        LEFT JOIN Item I ON I.itemId = OD.itemId
                        WHERE OD.orderId = @orderId";

                    SqlCommand cmd = new SqlCommand(query, connection);
                    cmd.Parameters.AddWithValue("@orderId", orderId);

                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    DataTable detailData = new DataTable();
                    adapter.Fill(detailData);

                    dgvOrderDetail.DataSource = detailData;
                    dgvOrderDetail.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Loading order detail failed: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Khi click vào bảng đơn hàng (hiện Id đơn hàng, Id khách hàng, tổng tiền, Id nhân viên)
        private void dgvOrderList_SelectionChanged(object sender, EventArgs e)
        {
            if (switchModeState == "view" && dgvOrderList.CurrentRow != null && dgvOrderList.CurrentRow.Index >= 0)
            {
                DataGridViewRow selectedRow = dgvOrderList.CurrentRow;
                int orderId = Convert.ToInt32(selectedRow.Cells["Order Id"].Value);
                selectedOrderId = orderId;

                labelOrderId.Text = "Order Id: " + selectedOrderId.ToString();
                textBoxCustomerId.Text = Convert.ToString(selectedRow.Cells["Customer Id"].Value);
                textBoxTotalPrice.Text = Convert.ToString(selectedRow.Cells["Total Price"].Value);
                labelStaffId.Text = "Staff Id: " + Convert.ToString(selectedRow.Cells["Staff Id"].Value);

                string dateStr = selectedRow.Cells["Order Time"].Value?.ToString()?.Trim();

                if (string.IsNullOrEmpty(dateStr))
                {
                    MessageBox.Show("Date string is empty.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Chuyển "SA" -> "AM", "CH" -> "PM" nếu có
                dateStr = dateStr.Replace("SA", "AM").Replace("CH", "PM");

                // Danh sách định dạng ngày tháng hợp lệ
                string[] formats = {
                    "yyyy-MM-dd HH:mm:ss",
                    "yyyy-MM-dd",
                    "MM/dd/yyyy hh:mm:ss tt",
                    "M/d/yyyy h:mm:ss tt",
                    "dd/MM/yyyy HH:mm:ss",
                    "dd/MM/yyyy",
                };

                // Dùng InvariantCulture để tránh lỗi do ngôn ngữ hệ thống
                var invariantCulture = System.Globalization.CultureInfo.InvariantCulture;

                if (DateTime.TryParseExact(dateStr, formats, invariantCulture, System.Globalization.DateTimeStyles.None, out DateTime orderDate))
                {
                    dateTimePickerOrder.Value = orderDate;
 }
                else {MessageBox.Show("Cannot convert date: " + dateStr, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);}

                loadOrderDetailData(orderId);
            }
        }


        // Khi click vào dòng trong bảng chi tiết đơn hàng (hiện thông tin vật phẩm)
        private void dgvOrderDetail_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvOrderDetail.CurrentRow != null && dgvOrderDetail.CurrentRow.Index >= 0)
            {
                DataGridViewRow selectedRow = dgvOrderDetail.CurrentRow;
                selectedItemId = Convert.ToInt32(selectedRow.Cells["Item Id"].Value);
                
                labelOrderItemName.Text = selectedRow.Cells["Item name"].Value.ToString();
                int quantity = Convert.ToInt32(selectedRow.Cells["Quantity"].Value);
                numOrderDetail.Value = quantity;                               
            }
        }

        // Khi numeric của order thay đổi thì cập nhật số lượng trong bảng
        private void numOrderDetail_ValueChanged(object sender, EventArgs e)
        {
            if (dgvOrderDetail.CurrentRow != null && dgvOrderDetail.CurrentRow.Index >= 0)
            {
                DataGridViewRow selectedRow = dgvOrderDetail.CurrentRow;
                selectedRow.Cells["Quantity"].Value = (int)numOrderDetail.Value;
            }
        }

        // Khi ấn link tìm khách hàng
        private void linkLabelFindOrAddCustomer_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            CustomerForm customerForm = new CustomerForm();
            customerForm.Show();
        }

        // Tìm kiếm đơn hàng theo id
        private void searchOrder(string keyword)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string searchQuery = @"
                        SELECT
                            O.orderId AS [Order Id],
                            O.customerId AS [Customer Id],
                            CAST(O.orderDate AS DATE) AS [Order Time],
                            S.staffId AS [Staff Id],
                            O.totalPrice AS [Total Price]
                        FROM Orders O
                        LEFT JOIN Staff S ON O.staffId = S.staffId
                        WHERE O.orderId = @orderId
                        ORDER BY O.orderDate DESC;";

                    SqlCommand cmd = new SqlCommand(searchQuery, connection);
                    //cmd.Parameters.AddWithValue("@keyword", $"%{keyword}%");
             
                    if (int.TryParse(keyword, out int orderId))
                    {
                        cmd.Parameters.AddWithValue("@orderId", orderId);
                    }
                    else
                    {
                        MessageBox.Show("Please enter a valid Order ID to search.", "Invalid Search Term", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        loadOrderData();
                        return;
                    }

                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    DataTable searchResult = new DataTable();
                    adapter.Fill(searchResult);

                    if (searchResult.Rows.Count > 0)
                    {
                        dgvOrderList.DataSource = searchResult;
                        dgvOrderList.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                    }
                    else
                    {
                        MessageBox.Show("No orders found with the specified Order ID.", "No Results", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        loadOrderData();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Search Failed: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Khi nhập dữ liệu tìm kiếm 
        private void textBoxSearchOrder_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.Handled = true;
                e.SuppressKeyPress = true;

                string keyword = textBoxSearchOrder.Text.Trim();
                if (string.IsNullOrEmpty(keyword))
                {
                    loadOrderData();
                    return;
                }
                searchOrder(keyword);
            }
        }
        #endregion


        #region Load dữ liệu tất cả vật phẩm để add
        // Phương thức load vật phẩm (id vật phẩm, tên, mô tả, số lượng có sẵn)
        private void loadItemData()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    string query = @"
                        SELECT
                            itemId AS [ID],
                            itemName AS [Name],
                            itemDescription AS [Description],
                            itemPrice AS [Price],
                            itemQuantity AS [Quantity]
                        FROM Item
                        WHERE itemName != 'Deleted Item'
                        ORDER BY itemId";

                    SqlDataAdapter itemAdapter = new SqlDataAdapter(query, connection);
                    DataTable itemData = new DataTable();
                    itemAdapter.Fill(itemData);
                    dgvItemList.DataSource = itemData;
                    dgvItemList.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

                }
                catch (Exception ex)
                {
                    MessageBox.Show("Loading item data failed: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        
        // Khi click vào bảng Item
        private void dgvItemList_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvItemList.CurrentRow != null && dgvItemList.CurrentRow.Index >= 0)
            {
                DataGridViewRow selectedRow = dgvItemList.CurrentRow;
                selectedItemId = Convert.ToInt32(selectedRow.Cells["ID"].Value);
                labelItemName.Text = selectedRow.Cells["Name"].Value.ToString();
                labelItemPrice.Text = selectedRow.Cells["Price"].Value.ToString();
            }    
        }
        #endregion

        #region Tìm kiếm vật phẩm để add vào đơn
        // Phương thức tìm kiếm vật phẩm
        private void searchItem(string keyword)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    string query = @"
                        SELECT itemId AS [ID], itemName AS [Name], itemDescription AS [Description], itemPrice AS [Price], itemQuantity AS [Quantity]
                        FROM Item
                        WHERE ((itemId LIKE @keyword OR itemName LIKE @keyword) AND itemName != 'Deleted item')";

                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@keyword", $"%{keyword}%");

                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable resultTable = new DataTable();
                    adapter.Fill(resultTable);

                    dgvItemList.DataSource = resultTable;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Search failed: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        // Sự kiện ấn Enter box tìm kiếm 
        private void textBoxSearchItem_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.Handled = true;
                e.SuppressKeyPress = true;

                string keyword = textBoxSearchItem.Text.Trim();
                if (string.IsNullOrEmpty(keyword))
                {
                    loadItemData();
                    return;
                }
                searchItem(keyword);
            }
        }
        #endregion


        #region Sua thong tin don hang
        // Xóa thông tin đang hiển thị
        private void clearOrderDetails()
        {
            labelOrderId.Text = "Order Id: <Auto Generated>";
            textBoxCustomerId.Text = "";
            dateTimePickerOrder.Value = DateTime.Now;
            textBoxTotalPrice.Text = "0.00";
            labelStaffId.Text = "Staff Id: " + CurrentUser.StaffId.ToString();
            dgvOrderDetail.DataSource = null;
            labelOrderItemName.Text = "Selected item name";
            numOrderDetail.Value = 1;
            orderDetailTempTable.Clear();
            dgvOrderDetail.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }

        private void switchMode(string modeName)
        {
            switchModeState = modeName;
            switch (modeName)
            {
                case "view":
                    // Block 0. OrderList
                    buttonEditOrder.Enabled = true;               // nút edit
                    buttonCreateNewOrder.Enabled = true;          // nút tạo mới
                    dgvOrderList.Enabled = true;                  // bảng dgvOrderList
                    textBoxSearchOrder.Enabled = true;            // hộp tìm kiếm

                    // Block 1. TextBox Panel tổng quan đơn hàng
                    textBoxCustomerId.Enabled = false;            // hộp nhập id khách hàng
                    dateTimePickerOrder.Enabled = false;          // thanh chọn tgian
                    textBoxTotalPrice.Enabled = false;            // hộp tổng tiền

                    // Block 2. Button Panel tổng quan đơn hàng
                    linkLabelFindOrAddCustomer.Enabled = false;   // link tìm khách hàng
                    buttonAddOrder.Enabled = false;               // nút add đơn hàng
                    linkLabelCancelEdit.Enabled = false;          // link hủy edit
                    buttonDeleteOrder.Enabled = false;            // nút xóa đơn hàng
                    buttonSaveChangesInOrder.Enabled = false;     // nút lưu sửa đổi trong đơn

                    // Block 3. OrderDetail 
                    textBoxSearchItemInOrder.Enabled = false;     // hộp tìm kiếm vp trong đơn hàng
                    dgvItemList.Enabled = false;                  // bảng danh sách vật phẩm
                    numOrderDetail.Enabled = false;               // thanh sửa số lượng khi đã vào đơn
                    buttonDeleteItemFromOrder.Enabled = false;    // nút xóa vật phẩm khỏi đơn
                    buttonSaveAllItemInOrder.Enabled = false;     // nút lưu tất cả item vào đơn 

                    // Block 4. Item
                    textBoxSearchItem.Enabled = false;            // hộp tìm kiếm tất cả vật phẩm
                    buttonAddItemToOrder.Enabled = false;         // nút thêm vật phẩm vào đơn
                    numericUpDownSelectQuantity.Enabled = false;  // thanh chọn số lượng vp
                    break;

                case "edit":
                    // Block 0. OrderList
                    buttonEditOrder.Enabled = false;               // nút edit
                    buttonCreateNewOrder.Enabled = false;          // nút tạo mới
                    dgvOrderList.Enabled = false;                  // bảng dgvOrderList
                    textBoxSearchOrder.Enabled = false;            // hộp tìm kiếm

                    // Block 1. TextBox Panel tổng quan đơn hàng
                    textBoxCustomerId.Enabled = true;              // hộp nhập id khách hàng
                    dateTimePickerOrder.Enabled = true;            // thanh chọn tgian
                    textBoxTotalPrice.Enabled = true;              // hộp tổng tiền

                    // Block 2. Button Panel tổng quan đơn hàng
                    linkLabelFindOrAddCustomer.Enabled = true;     // link tìm khách hàng
                    buttonAddOrder.Enabled = false;                // nút add đơn hàng
                    linkLabelCancelEdit.Enabled = true;            // link hủy edit
                    buttonDeleteOrder.Enabled = true;              // nút xóa đơn hàng
                    buttonSaveChangesInOrder.Enabled = true;       // nút lưu sửa đổi trong đơn

                    // Block 3. OrderDetail 
                    textBoxSearchItemInOrder.Enabled = true;       // hộp tìm kiếm vp trong đơn hàng
                    dgvItemList.Enabled = true;                    // bảng danh sách vật phẩm
                    numOrderDetail.Enabled = true;                 // thanh sửa số lượng khi đã vào đơn
                    buttonDeleteItemFromOrder.Enabled = true;      // nút xóa vật phẩm khỏi đơn
                    buttonSaveAllItemInOrder.Enabled = true;       // nút lưu tất cả item vào đơn 

                    // Block 4. Item
                    textBoxSearchItem.Enabled = true;              // hộp tìm kiếm tất cả vật phẩm
                    buttonAddItemToOrder.Enabled = true;           // nút thêm vật phẩm vào đơn
                    numericUpDownSelectQuantity.Enabled = true;    // thanh chọn số lượng vp
                    break;

                case "add":
                    // Block 0. OrderList
                    buttonEditOrder.Enabled = false;               // nút edit
                    buttonCreateNewOrder.Enabled = false;          // nút tạo mới
                    dgvOrderList.Enabled = false;                  // bảng dgvOrderList
                    textBoxSearchOrder.Enabled = false;            // hộp tìm kiếm

                    // Block 1. TextBox Panel tổng quan đơn hàng
                    textBoxCustomerId.Enabled = true;              // hộp nhập id khách hàng
                    dateTimePickerOrder.Enabled = true;            // thanh chọn tgian
                    textBoxTotalPrice.Enabled = true;              // hộp tổng tiền

                    // Block 2. Button Panel tổng quan đơn hàng
                    linkLabelFindOrAddCustomer.Enabled = true;     // link tìm khách hàng
                    buttonAddOrder.Enabled = true;                 // nút add đơn hàng
                    linkLabelCancelEdit.Enabled = true;            // link hủy edit
                    buttonDeleteOrder.Enabled = false;             // nút xóa đơn hàng
                    buttonSaveChangesInOrder.Enabled = false;      // nút lưu sửa đổi trong đơn

                    // Block 3. OrderDetail 
                    textBoxSearchItemInOrder.Enabled = true;       // hộp tìm kiếm vp trong đơn hàng
                    dgvItemList.Enabled = true;                    // bảng danh sách vật phẩm
                    numOrderDetail.Enabled = true;                 // thanh sửa số lượng khi đã vào đơn
                    buttonDeleteItemFromOrder.Enabled = true;      // nút xóa vật phẩm khỏi đơn
                    buttonSaveAllItemInOrder.Enabled = true;       // nút lưu tất cả item vào đơn 

                    // Block 4. Item
                    textBoxSearchItem.Enabled = true;              // hộp tìm kiếm tất cả vật phẩm
                    buttonAddItemToOrder.Enabled = true;           // nút thêm vật phẩm vào đơn
                    numericUpDownSelectQuantity.Enabled = true;    // thanh chọn số lượng vp
                    break;
                default:
                    switchMode("view");
                    break;
            }
        }

        // Khi ấn nút thêm đơn hàng mới
        private void buttonCreateNewOrder_Click(object sender, EventArgs e)
        {
            switchMode("add");
            clearOrderDetails();

            createOrderDetailTempTable(); // New                                  
            orderDetailView = new DataView(orderDetailTempTable);// Gán DataView để hỗ trợ tìm kiếm            
            dgvOrderDetail.DataSource = orderDetailView;// Gán vào DataGridView

            //dgvOrderDetail.DataSource = orderDetailTempTable;
        }

        // Khi ấn nút sửa đơn hàng bất kì
        private void buttonEditOrder_Click(object sender, EventArgs e)
        {
            if (selectedOrderId == -1)
            {
                MessageBox.Show("Please select an order to edit.", "No Order Selected", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            switchMode("edit");
            LoadOrderDetailToTempTable(selectedOrderId);
        }

        // Phương thức tải chi tiết đơn hàng vào bảng tạm để chỉnh sửa
        private void LoadOrderDetailToTempTable(int orderId)
        {
            orderDetailTempTable.Clear();
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = @"
                        SELECT
                            OD.itemId AS [Item Id],
                            I.itemName AS [Item Name],
                            OD.quantity AS [Quantity],
                            I.itemPrice AS [Item Price]
                        FROM OrderDetail OD
                        LEFT JOIN Item I ON I.itemId = OD.itemId
                        WHERE OD.orderId = @orderId";

                    SqlCommand cmd = new SqlCommand(query, connection);
                    cmd.Parameters.AddWithValue("@orderId", orderId);

                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    adapter.Fill(orderDetailTempTable); // Đổ dữ liệu vào bảng tạm thời (bản gốc)

                    orderDetailView = new DataView(orderDetailTempTable); // Bản bộ lọc lấy dữ liệu từ bản gốc
                    dgvOrderDetail.DataSource = orderDetailView;                   

                    dgvOrderDetail.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Loading order details for editing failed: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Khi nhấp link hủy edit đơn hàng
        private void linkLabelCancelEdit_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            switchMode("view");
            loadOrderData();
            clearOrderDetails();
        }

        // Khi ấn nút thêm vật phẩm vào đơn (đơn hàng tạm thời)
        // Thêm vật phẩm vào đơn hàng tạm thời(cho cả mode "add" và "edit")
        private void buttonAddItemToOrder_Click(object sender, EventArgs e)
        {
            if (selectedItemId == -1)
            {
                MessageBox.Show("Please select an item to add.", "No Item Selected", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            int quantityToAdd = (int)numericUpDownSelectQuantity.Value;
            if (quantityToAdd <= 0)
            {
                MessageBox.Show("Quantity must be greater than 0.", "Invalid Quantity", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Lấy chi tiết vật phẩm từ dgvItemList (bảng hiển thị tất cả các mặt hàng có sẵn)
            DataGridViewRow selectedItemRow = dgvItemList.CurrentRow;
            if (selectedItemRow == null)
            {
                MessageBox.Show("Please select an item from the item list.", "No Item Selected", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            int itemId = Convert.ToInt32(selectedItemRow.Cells["ID"].Value);
            string itemName = selectedItemRow.Cells["Name"].Value.ToString();
            decimal itemPrice = Convert.ToDecimal(selectedItemRow.Cells["Price"].Value);
            int availableQuantity = Convert.ToInt32(selectedItemRow.Cells["Quantity"].Value);

            if (quantityToAdd > availableQuantity)
            {
                MessageBox.Show($"Only {availableQuantity} of '{itemName}' available. Cannot add {quantityToAdd}.", "Insufficient Stock", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Kiểm tra xem mặt hàng đã tồn tại trong bảng tạm chi tiết đơn hàng chưa
            DataRow existingRow = orderDetailTempTable.AsEnumerable()
                                    .FirstOrDefault(row => row.Field<int>("Item Id") == itemId);

            if (existingRow != null)
            {
                int currentQuantity = existingRow.Field<int>("Quantity");
                int newQuantity = currentQuantity + quantityToAdd;
                if (newQuantity > availableQuantity)
                {
                    MessageBox.Show($"Adding {quantityToAdd} more of '{itemName}' would exceed available stock ({availableQuantity}). Current in order: {currentQuantity}.", "Insufficient Stock", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                existingRow["Quantity"] = newQuantity;
            }
            else
            {
                // Thêm mặt hàng mới vào bảng "OrderDetail gốc" tạm thời 
                orderDetailTempTable.Rows.Add(itemId, itemName, quantityToAdd, itemPrice);
            }
                        
            dgvOrderDetail.DataSource = orderDetailView; // Nguồn dữ liệu cho bảng OrderDetail tạm thời 
            CalculateTotalPrice(); // Tính toán lại tổng giá
        }

        // Tính toán tổng giá dựa trên các mặt hàng trong orderDetailTempTable
        private void CalculateTotalPrice()
        {
            decimal totalPrice = 0;
            foreach (DataRow row in orderDetailTempTable.Rows)
            {
                decimal itemPrice = row.Field<decimal>("Item Price");
                int quantity = row.Field<int>("Quantity");
                totalPrice += (itemPrice * quantity);
            }
            textBoxTotalPrice.Text = totalPrice.ToString("N2"); // Định dạng tiền tệ
        }


        // Khi ấn lưu tất cả vật phẩm trong đơn
        private void buttonSaveAllItemInOrder_Click(object sender, EventArgs e)
        {
            if (switchModeState == "edit")
            {
                // Logic để cập nhật chi tiết đơn hàng hiện có (xóa tất cả chi tiết cũ và chèn chi tiết mới)
                if (selectedOrderId == -1)
                {
                    MessageBox.Show("No order selected to save details.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();
                        SqlTransaction transaction = connection.BeginTransaction(); // Sử dụng Transaction để đảm bảo tính toàn vẹn dữ liệu
                        try
                        {
                            // 1. Xóa chi tiết đơn hàng hiện có cho đơn hàng đã chọn
                            string deleteDetailQuery = 
                                "DELETE FROM OrderDetail WHERE orderId = @orderId;";
                            SqlCommand deleteCmd = new SqlCommand(deleteDetailQuery, connection, transaction);
                            deleteCmd.Parameters.AddWithValue("@orderId", selectedOrderId);
                            deleteCmd.ExecuteNonQuery();

                            // 2. Chèn chi tiết đơn hàng mới từ bảng tạm
                            string insertDetailQuery = 
                                "INSERT INTO OrderDetail (orderId, itemId, quantity) " +
                                "VALUES (@orderId, @itemId, @quantity);";

                            SqlCommand insertCmd = new SqlCommand(insertDetailQuery, connection, transaction);
                            insertCmd.Parameters.Add("@orderId", SqlDbType.Int).Value = selectedOrderId;
                            insertCmd.Parameters.Add("@itemId", SqlDbType.Int);
                            insertCmd.Parameters.Add("@quantity", SqlDbType.Int);

                            foreach (DataRow row in orderDetailTempTable.Rows)
                            {
                                insertCmd.Parameters["@itemId"].Value = row.Field<int>("Item Id");
                                insertCmd.Parameters["@quantity"].Value = row.Field<int>("Quantity");
                                insertCmd.ExecuteNonQuery();
                            }

                            // 3. Cập nhật tổng giá của đơn hàng
                            string updateOrderTotalPriceQuery = "UPDATE Orders SET totalPrice = @totalPrice WHERE orderId = @orderId;";
                            SqlCommand updateOrderCmd = new SqlCommand(updateOrderTotalPriceQuery, connection, transaction);
                            updateOrderCmd.Parameters.AddWithValue("@totalPrice", Convert.ToDecimal(textBoxTotalPrice.Text));
                            updateOrderCmd.Parameters.AddWithValue("@orderId", selectedOrderId);
                            updateOrderCmd.ExecuteNonQuery();

                            transaction.Commit(); // Xác nhận giao dịch
                            MessageBox.Show("Order details updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            loadOrderData(); // Tải lại danh sách đơn hàng chính
                            loadOrderDetailData(selectedOrderId); // Tải lại chi tiết đơn hàng đã cập nhật
                        }
                        catch (Exception ex)
                        {
                            transaction.Rollback(); // Hoàn tác giao dịch nếu có lỗi
                            MessageBox.Show("Failed to save order details: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Database connection error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else if (switchModeState == "add")
            {
                // Trong chế độ "add", nút này được dùng để thêm vật phẩm vào bảng tạm thời chi tiết đơn hàng.
                // Việc lưu vào DB thực tế xảy ra khi nhấn nút buttonAddOrder_Click.
                MessageBox.Show("Items have been added to the temporary order list. Click 'Add' to save the new order to the database.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        // Khi ấn nút xóa vật phẩm khỏi OrderDetail
        private void buttonDeleteItemFromOrder_Click(object sender, EventArgs e)
        {
            if (dgvOrderDetail.CurrentRow != null && dgvOrderDetail.CurrentRow.Index >= 0)
            {
                DialogResult result = MessageBox.Show("Are you sure you want to remove this item from the order?", "Confirm Removal", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    int rowIndex = dgvOrderDetail.CurrentRow.Index;
                    orderDetailTempTable.Rows.RemoveAt(rowIndex);
                    CalculateTotalPrice(); // Tính toán lại tổng giá
                }
            }
            else
            {
                MessageBox.Show("Please select an item from the order details to remove.", "No Item Selected", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        
        // Tìm kiếm vật phẩm trong đơn hàng bằng tên
        private void searchItemInOrder(string keyword)
        {
            if (orderDetailView == null) return;

            if (string.IsNullOrEmpty(keyword))
            {
                orderDetailView.RowFilter = "";
            }
            else
            {
                string safeKeyword = keyword.Replace("'", "''");
                orderDetailView.RowFilter = $"[Item Name] LIKE '%{safeKeyword}%'";
            }
        }

        // Khi an tim kiem vat pham trong don hang
        private void textBoxSearchItemInOrder_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.Handled = true;
                e.SuppressKeyPress = true;
                searchItemInOrder(textBoxSearchItemInOrder.Text.Trim());
            }
        }
        #endregion


        #region Thêm, sửa, xóa đơn hàng (Tổng quan)
        // Thêm đơn hàng mới
        private void buttonAddOrder_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBoxCustomerId.Text) || !int.TryParse(textBoxCustomerId.Text, out int customerId))
            {
                MessageBox.Show("Please enter a valid Customer ID.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (orderDetailTempTable.Rows.Count == 0)
            {
                MessageBox.Show("Please add items to the order before saving.", "No Items", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            decimal totalPrice;
            if (!decimal.TryParse(textBoxTotalPrice.Text, out totalPrice))
            {
                MessageBox.Show("Total price is invalid. Please ensure items are added correctly.", "Invalid Total Price", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int staffId = CurrentUser.StaffId;
            DateTime orderDate = dateTimePickerOrder.Value;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlTransaction transaction = connection.BeginTransaction(); // Bắt đầu giao dịch để đảm bảo toàn vẹn dữ liệu
                try
                {
                    // 1. Chèn vào bảng Orders
                    // Sử dụng SELECT SCOPE_IDENTITY() để lấy OrderId vừa được tạo tự động
                    string insertOrderQuery = "" +
                        "INSERT INTO Orders (customerId, orderDate, totalPrice, staffId) " +
                        "VALUES (@customerId, @orderDate, @totalPrice, @staffId); SELECT SCOPE_IDENTITY();";
                    SqlCommand orderCmd = new SqlCommand(insertOrderQuery, connection, transaction);
                    orderCmd.Parameters.AddWithValue("@customerId", customerId);
                    orderCmd.Parameters.AddWithValue("@orderDate", orderDate);
                    orderCmd.Parameters.AddWithValue("@totalPrice", totalPrice);
                    orderCmd.Parameters.AddWithValue("@staffId", staffId);

                    int newOrderId = Convert.ToInt32(orderCmd.ExecuteScalar()); // Lấy OrderId mới được tạo

                    // 2. Chèn vào bảng OrderDetail và cập nhật số lượng Item
                    string insertOrderDetailQuery = "INSERT INTO OrderDetail (orderId, itemId, quantity) VALUES (@orderId, @itemId, @quantity);";
                    string updateItemQuantityQuery = "UPDATE Item SET itemQuantity = itemQuantity - @quantity WHERE itemId = @itemId;";

                    foreach (DataRow row in orderDetailTempTable.Rows)
                    {
                        int itemId = row.Field<int>("Item Id");
                        int quantity = row.Field<int>("Quantity");

                        // Chèn OrderDetail
                        SqlCommand detailCmd = new SqlCommand(insertOrderDetailQuery, connection, transaction);
                        detailCmd.Parameters.AddWithValue("@orderId", newOrderId);
                        detailCmd.Parameters.AddWithValue("@itemId", itemId);
                        detailCmd.Parameters.AddWithValue("@quantity", quantity);
                        detailCmd.ExecuteNonQuery();

                        // Cập nhật số lượng Item
                        SqlCommand updateItemCmd = new SqlCommand(updateItemQuantityQuery, connection, transaction);
                        updateItemCmd.Parameters.AddWithValue("@quantity", quantity);
                        updateItemCmd.Parameters.AddWithValue("@itemId", itemId);
                        updateItemCmd.ExecuteNonQuery();
                    }

                    transaction.Commit(); // Xác nhận giao dịch (tất cả các thao tác thành công)
                    MessageBox.Show("New order added successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    loadOrderData();      // Tải lại danh sách đơn hàng chính
                    loadItemData();       // Tải lại dữ liệu vật phẩm để phản ánh thay đổi số lượng
                    clearOrderDetails();
                    switchMode("view");
                }
                catch (Exception ex)
                {
                    transaction.Rollback(); // Hoàn tác giao dịch nếu có bất kỳ lỗi nào
                    MessageBox.Show("Failed to add new order: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        // Lưu đơn hàng vừa edit (nút này dùng để lưu thông tin chung của đơn hàng, không phải chi tiết)
        private void buttonSaveChangesInOrder_Click(object sender, EventArgs e)
        {
            if (selectedOrderId == -1)
            {
                MessageBox.Show("Please select an order to save changes.", "No Order Selected", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            if (!int.TryParse(textBoxCustomerId.Text, out int customerId))
            {
                MessageBox.Show("Please enter a valid Customer ID.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!decimal.TryParse(textBoxTotalPrice.Text, out decimal totalPrice))
            {
                MessageBox.Show("Total price is invalid. Please ensure items are added correctly or recalculate.", "Invalid Total Price", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DateTime orderDate = dateTimePickerOrder.Value;

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string updateOrderQuery = 
                        "UPDATE Orders SET customerId = @customerId, orderDate = @orderDate, " +
                        "totalPrice = @totalPrice WHERE orderId = @orderId;";

                    SqlCommand cmd = new SqlCommand(updateOrderQuery, connection);
                    cmd.Parameters.AddWithValue("@customerId", customerId);
                    cmd.Parameters.AddWithValue("@orderDate", orderDate);
                    cmd.Parameters.AddWithValue("@totalPrice", totalPrice);
                    cmd.Parameters.AddWithValue("@orderId", selectedOrderId);

                    int rowsAffected = cmd.ExecuteNonQuery();
                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Order information updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        loadOrderData(); // Làm mới danh sách đơn hàng
                    }
                    else
                    {
                        MessageBox.Show("No changes applied. Order might not exist.", "Update Failed", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error updating order information: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                switchMode("view");
            }
        }

        // Xóa đơn hàng
        private void buttonDeleteOrder_Click(object sender, EventArgs e)
        {
            if (selectedOrderId == -1)
            {
                MessageBox.Show("Please select an order to delete.", "No Order Selected", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            DialogResult confirm = MessageBox.Show($"Are you sure you want to delete Order ID: {selectedOrderId}? This action cannot be undone.", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (confirm == DialogResult.Yes)
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    SqlTransaction transaction = connection.BeginTransaction();
                    try
                    {
                        // 1. Khôi phục số lượng vật phẩm (đảo ngược việc trừ kho)
                        string restoreItemQuantityQuery = @"
                            UPDATE I
                            SET I.itemQuantity = I.itemQuantity + OD.quantity
                            FROM Item I
                            JOIN OrderDetail OD ON I.itemId = OD.itemId
                            WHERE OD.orderId = @orderId;";
                        SqlCommand restoreCmd = new SqlCommand(restoreItemQuantityQuery, connection, transaction);
                        restoreCmd.Parameters.AddWithValue("@orderId", selectedOrderId);
                        restoreCmd.ExecuteNonQuery();

                        // 2. Xóa từ bảng OrderDetail
                        string deleteOrderDetailQuery = "DELETE FROM OrderDetail WHERE orderId = @orderId;";
                        SqlCommand deleteDetailCmd = new SqlCommand(deleteOrderDetailQuery, connection, transaction);
                        deleteDetailCmd.Parameters.AddWithValue("@orderId", selectedOrderId);
                        deleteDetailCmd.ExecuteNonQuery();

                        // 3. Xóa từ bảng Orders
                        string deleteOrderQuery = "DELETE FROM Orders WHERE orderId = @orderId;";
                        SqlCommand deleteOrderCmd = new SqlCommand(deleteOrderQuery, connection, transaction);
                        deleteOrderCmd.Parameters.AddWithValue("@orderId", selectedOrderId);
                        deleteOrderCmd.ExecuteNonQuery();

                        transaction.Commit(); // Xác nhận giao dịch
                        MessageBox.Show("Order deleted successfully and item quantities restored!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        loadOrderData(); // Tải lại danh sách đơn hàng chính
                        loadItemData(); // Tải lại dữ liệu vật phẩm để phản ánh số lượng đã khôi phục
                        clearOrderDetails();
                        selectedOrderId = -1; // Đặt lại đơn hàng đã chọn
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback(); // Hoàn tác giao dịch nếu có lỗi
                        MessageBox.Show("Failed to delete order: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            switchMode("view");
        }
        #endregion
        
    }
}