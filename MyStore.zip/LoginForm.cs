﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;

namespace My_Store
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        // Khi nút Login được ấn
        private void buttonLogin_Click(object sender, EventArgs e)
        {
            string username = textBoxUsername.Text;
            string password = textBoxPassword.Text;
 
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password)) 
            {
                MessageBox.Show("Please enter full information", "Login Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string connectionString = ConfigurationManager.ConnectionStrings["StoreMNGConnectionString"].ConnectionString;
            DatabaseHelper helper = new DatabaseHelper(connectionString);
            string hashPassword = DatabaseHelper.GetSha256Hash(password);
            StaffProfile loggedInstaff = helper.AuthenticateUser(username, hashPassword);

            if (loggedInstaff != null) 
            {
                CurrentUser.Set(loggedInstaff);

                this.Hide();
                MainDashboardForm mainForm = new MainDashboardForm();
                mainForm.Show();
            }
            else
            {
                MessageBox.Show("Invalid username or password.", "Login error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Khi link exit được ấn
        private void linkLabelExit_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Application.Exit();
        }

        // Khi tick hiện mật khẩu 
        private void checkBoxShowPassword_CheckedChanged(object sender, EventArgs e)
        {   
            // Nếu đã tick
            if (checkBoxShowPassword.Checked) { textBoxPassword.PasswordChar = (char)0; }
            // Nếu chưa tick
            else { textBoxPassword.PasswordChar = '*'; }
        }

        // Khi form được load
        private void LoginForm_Load(object sender, EventArgs e)
        {
            // Kích hoạt kí tự mật khẩu
            textBoxPassword.PasswordChar = '*';
        }

        // Khi người dùng click quên mật khẩu
        private void linkLabelForgotPassword_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            // Gửi mã xác nhận khôi phục mật khẩu (cập nhật sau này)
        }
    }
}
