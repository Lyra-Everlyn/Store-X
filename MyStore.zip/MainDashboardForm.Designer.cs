﻿namespace My_Store
{
    partial class MainDashboardForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainDashboardForm));
            this.labelUserName = new System.Windows.Forms.Label();
            this.labelUserId = new System.Windows.Forms.Label();
            this.buttonOpenAdminDashboard = new System.Windows.Forms.Button();
            this.buttonCategoryAndSupplierManagement = new System.Windows.Forms.Button();
            this.buttonCustomerManagement = new System.Windows.Forms.Button();
            this.buttonOpenItemManagement = new System.Windows.Forms.Button();
            this.buttonOpenOrderManagement = new System.Windows.Forms.Button();
            this.linkLabelExitApp = new System.Windows.Forms.LinkLabel();
            this.SuspendLayout();
            // 
            // labelUserName
            // 
            this.labelUserName.AutoSize = true;
            this.labelUserName.Font = new System.Drawing.Font("Segoe UI", 16F);
            this.labelUserName.Location = new System.Drawing.Point(13, 13);
            this.labelUserName.Name = "labelUserName";
            this.labelUserName.Size = new System.Drawing.Size(263, 59);
            this.labelUserName.TabIndex = 0;
            this.labelUserName.Text = "User\'s Name";
            // 
            // labelUserId
            // 
            this.labelUserId.AutoSize = true;
            this.labelUserId.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.labelUserId.Location = new System.Drawing.Point(15, 72);
            this.labelUserId.Name = "labelUserId";
            this.labelUserId.Size = new System.Drawing.Size(298, 45);
            this.labelUserId.TabIndex = 1;
            this.labelUserId.Text = "UserId: 1234567890";
            // 
            // buttonOpenAdminDashboard
            // 
            this.buttonOpenAdminDashboard.BackColor = System.Drawing.Color.MediumAquamarine;
            this.buttonOpenAdminDashboard.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonOpenAdminDashboard.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.buttonOpenAdminDashboard.ForeColor = System.Drawing.Color.Transparent;
            this.buttonOpenAdminDashboard.Location = new System.Drawing.Point(1257, 12);
            this.buttonOpenAdminDashboard.Name = "buttonOpenAdminDashboard";
            this.buttonOpenAdminDashboard.Size = new System.Drawing.Size(400, 290);
            this.buttonOpenAdminDashboard.TabIndex = 2;
            this.buttonOpenAdminDashboard.Text = "Revenue \r\n- \r\nStaff\r\n";
            this.buttonOpenAdminDashboard.UseVisualStyleBackColor = false;
            this.buttonOpenAdminDashboard.Click += new System.EventHandler(this.buttonOpenAdminDashboard_Click);
            // 
            // buttonCategoryAndSupplierManagement
            // 
            this.buttonCategoryAndSupplierManagement.BackColor = System.Drawing.Color.SlateBlue;
            this.buttonCategoryAndSupplierManagement.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonCategoryAndSupplierManagement.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.buttonCategoryAndSupplierManagement.ForeColor = System.Drawing.Color.Transparent;
            this.buttonCategoryAndSupplierManagement.Location = new System.Drawing.Point(1257, 604);
            this.buttonCategoryAndSupplierManagement.Name = "buttonCategoryAndSupplierManagement";
            this.buttonCategoryAndSupplierManagement.Size = new System.Drawing.Size(400, 290);
            this.buttonCategoryAndSupplierManagement.TabIndex = 3;
            this.buttonCategoryAndSupplierManagement.Text = "Category \r\n- \r\nSupplier";
            this.buttonCategoryAndSupplierManagement.UseVisualStyleBackColor = false;
            this.buttonCategoryAndSupplierManagement.Click += new System.EventHandler(this.buttonCategoryAndSupplierManagement_Click);
            // 
            // buttonCustomerManagement
            // 
            this.buttonCustomerManagement.BackColor = System.Drawing.Color.LightCoral;
            this.buttonCustomerManagement.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonCustomerManagement.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.buttonCustomerManagement.ForeColor = System.Drawing.Color.Transparent;
            this.buttonCustomerManagement.Location = new System.Drawing.Point(1257, 308);
            this.buttonCustomerManagement.Name = "buttonCustomerManagement";
            this.buttonCustomerManagement.Size = new System.Drawing.Size(400, 290);
            this.buttonCustomerManagement.TabIndex = 4;
            this.buttonCustomerManagement.Text = "Customer";
            this.buttonCustomerManagement.UseVisualStyleBackColor = false;
            this.buttonCustomerManagement.Click += new System.EventHandler(this.buttonCustomerManagement_Click);
            // 
            // buttonOpenItemManagement
            // 
            this.buttonOpenItemManagement.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.buttonOpenItemManagement.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonOpenItemManagement.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.buttonOpenItemManagement.ForeColor = System.Drawing.Color.Transparent;
            this.buttonOpenItemManagement.Location = new System.Drawing.Point(851, 604);
            this.buttonOpenItemManagement.Name = "buttonOpenItemManagement";
            this.buttonOpenItemManagement.Size = new System.Drawing.Size(400, 290);
            this.buttonOpenItemManagement.TabIndex = 5;
            this.buttonOpenItemManagement.Text = "Item";
            this.buttonOpenItemManagement.UseVisualStyleBackColor = false;
            this.buttonOpenItemManagement.Click += new System.EventHandler(this.buttonOpenItemManagement_Click);
            // 
            // buttonOpenOrderManagement
            // 
            this.buttonOpenOrderManagement.BackColor = System.Drawing.Color.Wheat;
            this.buttonOpenOrderManagement.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonOpenOrderManagement.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.buttonOpenOrderManagement.ForeColor = System.Drawing.Color.Transparent;
            this.buttonOpenOrderManagement.Location = new System.Drawing.Point(851, 308);
            this.buttonOpenOrderManagement.Name = "buttonOpenOrderManagement";
            this.buttonOpenOrderManagement.Size = new System.Drawing.Size(400, 290);
            this.buttonOpenOrderManagement.TabIndex = 6;
            this.buttonOpenOrderManagement.Text = "Order";
            this.buttonOpenOrderManagement.UseVisualStyleBackColor = false;
            this.buttonOpenOrderManagement.Click += new System.EventHandler(this.buttonOpenOrderManagement_Click);
            // 
            // linkLabelExitApp
            // 
            this.linkLabelExitApp.AutoSize = true;
            this.linkLabelExitApp.Font = new System.Drawing.Font("Segoe UI", 15F);
            this.linkLabelExitApp.LinkColor = System.Drawing.Color.DeepSkyBlue;
            this.linkLabelExitApp.Location = new System.Drawing.Point(14, 840);
            this.linkLabelExitApp.Name = "linkLabelExitApp";
            this.linkLabelExitApp.Size = new System.Drawing.Size(164, 54);
            this.linkLabelExitApp.TabIndex = 7;
            this.linkLabelExitApp.TabStop = true;
            this.linkLabelExitApp.Text = "Exit app";
            this.linkLabelExitApp.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabelExitApp_LinkClicked);
            // 
            // MainDashboardForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1669, 904);
            this.Controls.Add(this.linkLabelExitApp);
            this.Controls.Add(this.buttonOpenOrderManagement);
            this.Controls.Add(this.buttonOpenItemManagement);
            this.Controls.Add(this.buttonCustomerManagement);
            this.Controls.Add(this.buttonCategoryAndSupplierManagement);
            this.Controls.Add(this.buttonOpenAdminDashboard);
            this.Controls.Add(this.labelUserId);
            this.Controls.Add(this.labelUserName);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "MainDashboardForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Main Dashboard";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainDashboardForm_FormClosing);
            this.Load += new System.EventHandler(this.MainDashboardForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelUserName;
        private System.Windows.Forms.Label labelUserId;
        private System.Windows.Forms.Button buttonOpenAdminDashboard;
        private System.Windows.Forms.Button buttonCategoryAndSupplierManagement;
        private System.Windows.Forms.Button buttonCustomerManagement;
        private System.Windows.Forms.Button buttonOpenItemManagement;
        private System.Windows.Forms.Button buttonOpenOrderManagement;
        private System.Windows.Forms.LinkLabel linkLabelExitApp;
    }
}