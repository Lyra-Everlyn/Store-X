CREATE DATABASE StoreXDatabase;
GO
USE StoreXDatabase;
GO

-- Customer
CREATE TABLE Customer (
    customerId INT IDENTITY(1,1) PRIMARY KEY,
    customerName NVARCHAR(100) NULL DEFAULT N'Unknow Customer',
    customerPhoneNumber VARCHAR(20) NULL UNIQUE,
    customerAddress NVARCHAR(500) NULL
);

-- Supplier
CREATE TABLE Supplier (
    supplierId INT IDENTITY(1,1) PRIMARY KEY,
    supplierName NVARCHAR(100) NOT NULL,
    supplierPhoneNumber NVARCHAR(20) NOT NULL,

    supplierEmail VARCHAR(100) NOT NULL UNIQUE,
    supplierAddress NVARCHAR(500) NOT NULL
);

-- Category
CREATE TABLE Category (
    categoryId INT IDENTITY(1,1) PRIMARY KEY,
    categoryName NVARCHAR(100) NOT NULL UNIQUE,
    categoryDescription NVARCHAR(500) NULL
);

-- Item
CREATE TABLE Item (
    itemId INT IDENTITY(1,1) PRIMARY KEY,
    itemName NVARCHAR(100) NOT NULL,
    itemDescription NVARCHAR(MAX) NULL,

    itemPrice DECIMAL(10,2) NOT NULL CHECK (itemPrice >= 0),
    categoryId INT NOT NULL,
    supplierId INT NOT NULL,
    
    itemQuantity INT NOT NULL CHECK (itemQuantity >= 0),
    FOREIGN KEY (categoryId) REFERENCES Category(categoryId),
    FOREIGN KEY (supplierId) REFERENCES Supplier(supplierId)
);

-- Staff 
CREATE TABLE Staff (
    staffId INT IDENTITY(1,1) PRIMARY KEY,
    staffName NVARCHAR(100) NOT NULL,
    staffPhoneNumber NVARCHAR(20) NOT NULL UNIQUE,
    staffEmail VARCHAR(100) NULL UNIQUE,
    authorityLevel INT NOT NULL CHECK (authorityLevel BETWEEN 1 AND 3),
    staffUsername VARCHAR(50) NOT NULL UNIQUE,
    staffPassword NVARCHAR(64) NOT NULL,
    isActive BIT DEFAULT 1
);

-- Orders
CREATE TABLE Orders (
    orderId INT IDENTITY(1,1) PRIMARY KEY,
    customerId INT NOT NULL,
    orderDate DATETIME2 NOT NULL DEFAULT GETDATE(),
    totalPrice DECIMAL(15,2) NOT NULL CHECK (totalPrice >= 0),
    staffId INT NOT NULL,
    FOREIGN KEY (staffId) REFERENCES Staff(staffId),
    FOREIGN KEY (customerId) REFERENCES Customer(customerId)
);

-- OrderDetail
CREATE TABLE OrderDetail (
    orderId INT NOT NULL,
    itemId INT NOT NULL,
    quantity INT NOT NULL CHECK (quantity > 0),

    PRIMARY KEY (orderId, itemId),
    FOREIGN KEY (orderId) REFERENCES Orders(orderId),
    FOREIGN KEY (itemId) REFERENCES Item(itemId)
);



-- Customer(customerId, customerName, customerPhoneNumber, customerAddress)
INSERT INTO Customer VALUES
(N'Nguyen Van A', '0909123456', N'123 Le Loi, District 1, HCM'),
(N'Tran Thi B' , '0912345678', N'456 Nguyen Trai, District 5, HCM'),
(N'Pham Van C' , '0987654321', N'789 Hai Ba Trung, District 3, HCM'),
(N'Le Thi D'	, '0922334455', N'12 Le Lai, District 1, HCM'),
(N'Hoang Van E'	, '0933445566', N'99 Phan Dang Luu, Binh Thanh, HCM'),
(N'Vu Thi F'	, '0944556677', N'01 Dinh Tien Hoang, Binh Duong');

-- Supplier(supplierId, supplierName, supplierPhoneNumber, supplierEmail, supplierAddress)
INSERT INTO Supplier VALUES
(N'ABC Company', '0281234567', 'abc@supplier.com', N'123 Dien Bien Phu, HCM'),
(N'XYZ Company', '0282345678', 'xyz@supplier.com', N'456 Cach Mang Thang 8, HCM'),
(N'DEF Company', '0283456789', 'def@supplier.com', N'789 Nguyen Van Cu, HCM'),
(N'MNO Company', '0284567890', 'mno@supplier.com', N'12 Nguyen Huu Canh, HCM'),
(N'PQR Company', '0285678901', 'pqr@supplier.com', N'34 Vo Van Tan, HCM'),
(N'TUV Company', '0286789012', 'tuv@supplier.com', N'56 Ly Tu Trong, HCM');

-- Category(categoryId, categoryName, categoryDescription)
INSERT INTO Category VALUES
(N'Smartphones', N'Mobile phones and smartphones'),
(N'Laptops'	   , N'Personal and business laptops'),
(N'Tablets'	   , N'Touchscreen portable computers'),
(N'Accessories', N'Cables, chargers, cases'),
(N'Monitors'   , N'Desktop and TV displays'),
(N'Speakers'   , N'Audio equipment and sound systems');

-- Item(itemId, itemName, itemDescription, itemPrice, categoryId, supplierId, itemQuantity)
INSERT INTO Item VALUES
(N'iPhone 15'      , N'Latest Apple smartphone'    , 25000, 1, 1, 1000),
(N'Galaxy S23'     , N'Samsung flagship smartphone', 23000, 1, 2, 1120),
(N'MacBook Pro 14"', N'Apple M2 Pro laptop'        , 45000, 2, 3, 1200),
(N'Dell XPS 13'    , N'High-end ultrabook'         , 38000, 2, 2, 1250),
(N'iPad Air'       , N'Slim and light tablet'      , 10000, 3, 4, 2040),
(N'Sony WH-1000XM5', N'Noise cancelling headphones', 85000, 4, 5, 1020);

-- Staff(staffId, staffName, staffPhoneNumber, staffEmail, authorityLevel, staffUsername, staffPassword, isActive)
INSERT INTO Staff VALUES
(N'Nguyen Thanh', '0901234567', 'nguyen.thanh@example.com', 1, 'nguyen_t', 'pass123', 1),
(N'Tran Hoai'	, '0902345678', 'tran.hoai@example.com'	  , 2, 'tran_h'	 , 'pass234', 1),
(N'Pham Minh'	, '0903456789', 'pham.minh@example.com'   , 2, 'pham.m'	 , 'pass345', 1),
(N'Le Hanh'		, '0904567890', 'le.hanh@example.com'     , 3, 'le_h'	 , 'pass456', 1),
(N'Hoang Lan'	, '0905678901', 'hoang.lan@example.com'	  , 3, 'hoang_l' , 'pass567', 1),
(N'Vu Bao'		, '0906789012', 'vu.bao@example.com'      , 3, 'vu_b'	 , 'pass678', 1);

-- Orders(orderId, customerId, orderDate, totalPrice, staffId)
INSERT INTO Orders VALUES
(1, '2025-06-10', 250000, 2),
(2, '2025-06-12', 230000, 2),
(3, '2025-06-14', 450000, 3),
(4, '2025-06-16', 380000, 3),
(5, '2025-06-18', 850000, 2),
(6, '2025-06-19', 100000, 3);

-- OrderDetail(orderId, itemId, quantity)
INSERT INTO OrderDetail VALUES
(1, 1, 10),
(2, 2, 10),
(3, 3, 10),
(4, 4, 10),
(5, 6, 10),
(6, 5, 20);



select * from Item;
select * from Category;
select * from Supplier;
select * from Customer;
select * from Staff;
select * from Orders;
select * from OrderDetail;



DELETE FROM OrderDetail;
DELETE FROM Orders;
DELETE FROM Staff;
DELETE FROM Item;
DELETE FROM Category;
DELETE FROM Supplier;
DELETE FROM Customer;



drop table OrderDetail;
drop table Orders;
drop table Staff;
drop table Item;
drop table Category;
drop table Supplier;
drop table Customer;