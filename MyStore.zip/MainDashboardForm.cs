﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace My_Store
{
    public partial class MainDashboardForm : Form
    {
        public MainDashboardForm()
        {
            InitializeComponent();
        }

        private void MainDashboardForm_Load(object sender, EventArgs e)
        {
            labelUserName.Text = CurrentUser.StaffName;
            labelUserId.Text = "Staff Id: " + Convert.ToString(CurrentUser.StaffId);
            if (CurrentUser.AuthorityLevel == 1) { switchMode("admin");}
            else if (CurrentUser.AuthorityLevel == 2) { switchMode("sale");}
            else if (CurrentUser.AuthorityLevel == 3) { switchMode("warehouse"); }
            else { Application.Exit(); }           
        }

        public void switchMode(string modeName)
        {
            switch (modeName)
            {
                case "admin":
                    // Form Admin
                    buttonOpenAdminDashboard.Enabled = true;

                    // Form Warehouse
                    buttonCategoryAndSupplierManagement.Enabled = true;
                    buttonCustomerManagement.Enabled = true;

                    // Form Sale
                    buttonOpenItemManagement.Enabled = true;
                    buttonOpenOrderManagement.Enabled = true;

                    break;

                case "sale":
                    // Form Admin
                    buttonOpenAdminDashboard.Enabled = false;

                    // Form Warehouse
                    buttonCategoryAndSupplierManagement.Enabled = false;
                    buttonOpenItemManagement.Enabled = false;

                    // Form Sale
                    buttonCustomerManagement.Enabled = true;                    
                    buttonOpenOrderManagement.Enabled = true;

                    break;

                case "warehouse":
                    // Form Admin
                    buttonOpenAdminDashboard.Enabled = false;

                    // Form Warehouse
                    buttonCategoryAndSupplierManagement.Enabled = true;
                    buttonOpenItemManagement.Enabled = true;

                    // Form Sale
                    buttonCustomerManagement.Enabled = false;                   
                    buttonOpenOrderManagement.Enabled = false;

                    break;

                default:
                    // Form Admin
                    buttonOpenAdminDashboard.Enabled = false;

                    // Form Warehouse
                    buttonCategoryAndSupplierManagement.Enabled = false;                    
                    buttonOpenItemManagement.Enabled = false;

                    // Form Sale
                    buttonCustomerManagement.Enabled = false;
                    buttonOpenOrderManagement.Enabled = false;

                    break;
            }
        }

        private void linkLabelExitApp_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e) {Application.Exit();}
        private void MainDashboardForm_FormClosing(object sender, FormClosingEventArgs e) {Application.Exit();}

        private void buttonOpenAdminDashboard_Click(object sender, EventArgs e)
        {
            if (CurrentUser.AuthorityLevel != 1) { return; }
            AdminDashboard adminDashboard = new AdminDashboard();
            adminDashboard.Show();
        }

        private void buttonOpenOrderManagement_Click(object sender, EventArgs e)
        {
            if (CurrentUser.AuthorityLevel == 2 || CurrentUser.AuthorityLevel == 1) 
            {
                OrderForm orderForm = new OrderForm();
                orderForm.Show();
            }
            else { return; }
        }

        private void buttonCustomerManagement_Click(object sender, EventArgs e)
        {
            if (CurrentUser.AuthorityLevel == 2 || CurrentUser.AuthorityLevel == 1) 
            {
                CustomerForm customerForm = new CustomerForm();
                customerForm.Show();
            }
            else { return; }
        }

        private void buttonOpenItemManagement_Click(object sender, EventArgs e)
        {
            if (CurrentUser.AuthorityLevel == 3 || CurrentUser.AuthorityLevel == 1) 
            {
                ItemForm itemForm = new ItemForm();
                itemForm.Show();
            }
            else { return; }
        }

        private void buttonCategoryAndSupplierManagement_Click(object sender, EventArgs e)
        {
            if (CurrentUser.AuthorityLevel == 3 || CurrentUser.AuthorityLevel == 1) 
            {
                CategoryAndSupplierForm categoryForm = new CategoryAndSupplierForm();
                categoryForm.Show();
            }
            else { return; }
        }
    }
}
