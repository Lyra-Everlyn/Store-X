﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace My_Store
{
    public partial class CustomerForm : Form
    {
        private string connectionString;
        private int selectedCustomerId = -1;
        private bool isUsingShowDeletedData = false;

        public CustomerForm()
        {
            InitializeComponent();
            this.connectionString = ConfigurationManager.ConnectionStrings["StoreMNGConnectionString"].ConnectionString;
            clearCustomerDetails();
            loadCustomerData();
            switchMode("view");
        }

        #region Load dữ liệu 
        // -- Phần 1. Load dữ liệu khách hàng --
        // Khi form khách hàng được load
        private void CustomerForm_Load(object sender, EventArgs e)
        {
            loadCustomerData();
            dgvOrderHistory.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }

        // Load dữ liệu khách hàng
        private void loadCustomerData()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    string query;
                    if (isUsingShowDeletedData)
                    {
                        query = @"
                        SELECT
                            customerId AS [ID],
                            customerName AS [Name],
                            customerPhoneNumber AS [Phone],
                            customerAddress AS [Address]
                        FROM
                            Customer
                        ORDER BY customerId DESC";
                    }
                    else 
                    {
                        query = @"
                        SELECT
                            customerId AS [ID],
                            customerName AS [Name],
                            customerPhoneNumber AS [Phone],
                            customerAddress AS [Address]
                        FROM
                            Customer
                        WHERE customerName != 'Deleted Customer'
                        ORDER BY customerId DESC";
                    }
                    
                    SqlDataAdapter customerAdapter = new SqlDataAdapter(query, connection);
                    DataTable customerData = new DataTable();
                    customerAdapter.Fill(customerData);
                    dgvCustomerList.DataSource = customerData;
                    dgvCustomerList.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                        
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Loading customer data failed: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        // Khi chọn 1 hàng bất kì trong dgvCustomerList
        private void dgvCustomerList_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvCustomerList.CurrentRow != null && dgvCustomerList.CurrentRow.Index >= 0)
            {
                DataGridViewRow row = dgvCustomerList.CurrentRow;
                selectedCustomerId = Convert.ToInt32(row.Cells["ID"].Value);

                labelCustomerId.Text = "Customer Id: " + selectedCustomerId.ToString();
                textBoxCustomerName.Text = row.Cells["Name"].Value.ToString();
                textBoxPhoneNumber.Text = row.Cells["Phone"].Value.ToString();
                richTextBoxAddress.Text = row.Cells["Address"].Value.ToString();

                // Lay lich su mua hang
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    try
                    {
                        connection.Open();

                        string query = @"
                            SELECT 
                                O.orderId AS [Order Code],
                                O.orderDate AS [Time Order],
                                O.totalPrice AS [Total Price],
                                S.staffName AS [Cashier]
                            FROM Orders O
                            INNER JOIN Staff S ON O.staffId = S.staffId
                            WHERE O.customerId = @customerId
                            ORDER BY O.orderDate DESC;";

                        SqlCommand cmd = new SqlCommand(query, connection);
                        cmd.Parameters.AddWithValue("@customerId", selectedCustomerId);

                        SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                        DataTable data = new DataTable();
                        adapter.Fill(data);

                        dgvOrderHistory.DataSource = data;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Loading order history failed: " + ex.Message);
                    }
                }

            }
        }
        #endregion

        #region Sửa dữ liệu
        // Clear dữ liệu các box
        private void clearCustomerDetails()
        {
            labelCustomerId.Text = "Customer Id: <Auto Generate>";
            textBoxCustomerName.Text = "Unknow Customer Name";

            #region textBoxPhoneNumber
            int lastCustomerId = 0;
            string query = "SELECT MAX(customerId) FROM Customer";

            using (SqlConnection connection = new SqlConnection(connectionString))
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                connection.Open();
                object result = command.ExecuteScalar();
                if (result != DBNull.Value)
                    lastCustomerId = Convert.ToInt32(result);
                connection.Close();
            }
            lastCustomerId = lastCustomerId + 1;
            textBoxPhoneNumber.Text = lastCustomerId.ToString().PadLeft(10, '0');
            #endregion

            richTextBoxAddress.Text = "Unknow address";
            selectedCustomerId = -1;
        }

        private void switchMode(string modeName)
        {
            switch (modeName)
            {
                case "view":
                    // Block 1. TextBox
                    textBoxCustomerName.Enabled = false;
                    textBoxPhoneNumber.Enabled = false;
                    richTextBoxAddress.Enabled = false;

                    // Block 2. Button
                    buttonCreateNewCustomer.Enabled = true;
                    buttonEditCustomer.Enabled = true;

                    buttonAddCustomer.Enabled = false;
                    buttonSaveChanges.Enabled = false;
                    buttonDeleteCustomer.Enabled = false;
                    linkLabelCancelEditCustomer.Enabled = false;

                    // Block 3. dgv Table 
                    textBoxSearchCustomer.Enabled = true;
                    dgvCustomerList.Enabled = true;
                    break;

                case "edit":
                    // Block 1. TextBox
                    textBoxCustomerName.Enabled = true;
                    textBoxPhoneNumber.Enabled = true;
                    richTextBoxAddress.Enabled = true;

                    // Block 2. Button
                    buttonCreateNewCustomer.Enabled = false;
                    buttonEditCustomer.Enabled = false;

                    buttonAddCustomer.Enabled = false;
                    buttonSaveChanges.Enabled = true;
                    buttonDeleteCustomer.Enabled = true;
                    linkLabelCancelEditCustomer.Enabled = true;

                    // Block 3. dgv Table
                    textBoxSearchCustomer.Enabled = true;
                    dgvCustomerList.Enabled = true;
                    break;

                case "add":
                    // Block 1. TextBox
                    textBoxCustomerName.Enabled = true;
                    textBoxPhoneNumber.Enabled = true;
                    richTextBoxAddress.Enabled = true;

                    // Block 2. Button
                    buttonCreateNewCustomer.Enabled = false;
                    buttonEditCustomer.Enabled = false;

                    buttonAddCustomer.Enabled = true;
                    buttonSaveChanges.Enabled = false;
                    buttonDeleteCustomer.Enabled = false;
                    linkLabelCancelEditCustomer.Enabled = true;

                    // Block 3. dgv Table
                    textBoxSearchCustomer.Enabled = false;
                    dgvCustomerList.Enabled = false;
                    break;

                default:
                    switchMode("view");
                    break;
            }
        }
        private void buttonCreateNewCustomer_Click(object sender, EventArgs e)
        {
            switchMode("add");
            clearCustomerDetails();
        }

        private void buttonEditCustomer_Click(object sender, EventArgs e)
        {
            if (selectedCustomerId == -1)
            {
                MessageBox.Show("Please select a customer member from the list to update.", "Selection Required", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            switchMode("edit");
        }

        private void linkLabelCancelEditCustomer_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            switchMode("view");
        }

        // Khi an nut them khach hang
        private void buttonAddCustomer_Click(object sender, EventArgs e)
        {

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    string query = @"
                        INSERT INTO Customer (customerName, customerPhoneNumber, customerAddress)
                        VALUES (@customerName, @customerPhoneNumber, @customerAddress);
                        SELECT SCOPE_IDENTITY();";

                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@customerName", textBoxCustomerName.Text);
                    command.Parameters.AddWithValue("@customerPhoneNumber", textBoxPhoneNumber.Text);
                    command.Parameters.AddWithValue("@customerAddress", richTextBoxAddress.Text);
                    selectedCustomerId = Convert.ToInt32(command.ExecuteScalar());

                    MessageBox.Show("Customer added successfully! ID: " + selectedCustomerId, "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    
                    loadCustomerData();
                    switchMode("view");

                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error adding customer: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        // Khi an nut luu du lieu
        private void buttonSaveChanges_Click(object sender, EventArgs e)
        {
            if (selectedCustomerId == -1)
            {
                MessageBox.Show("Please select a customer member from the list to update.", "Selection Required", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            if (string.IsNullOrWhiteSpace(textBoxCustomerName.Text) ||
                string.IsNullOrWhiteSpace(textBoxPhoneNumber.Text) ||
                string.IsNullOrWhiteSpace(richTextBoxAddress.Text))
            {
                MessageBox.Show("Please fill in all customer details.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    string query = @"
                        UPDATE Customer SET
                            customerName = @customerName,
                            customerPhoneNumber = @customerPhoneNumber,
                            customerAddress = @customerAddress
                        WHERE customerId = @customerId";

                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@customerId", selectedCustomerId);
                    command.Parameters.AddWithValue("@customerName", textBoxCustomerName.Text);
                    command.Parameters.AddWithValue("@customerPhoneNumber", textBoxPhoneNumber.Text);
                    command.Parameters.AddWithValue("@customerAddress", richTextBoxAddress.Text);
                    command.ExecuteNonQuery();

                    MessageBox.Show("Customer updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    
                    loadCustomerData();
                    switchMode("view");

                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error updating customer: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        // Khi an nut xoa khach hang
        private void buttonDeleteCustomer_Click(object sender, EventArgs e)
        {
            if (selectedCustomerId == -1)
            {
                MessageBox.Show("Please select a customer member from the list to 'soft delete'.", "Selection Required", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            if (MessageBox.Show($"Are you sure you want to mark customer ID {selectedCustomerId} as 'Deleted customer'?", "Confirm Soft Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    try
                    {
                        connection.Open();
                        string query = @"
                            UPDATE Customer SET
                                customerName = 'Deleted Customer',
                                customerPhoneNumber = RIGHT('0000000000' + CONVERT(NVARCHAR, customerId), 10),
                                customerAddress = 'Deleted Address'
                            WHERE customerId = @customerId";

                        SqlCommand command = new SqlCommand(query, connection);
                        command.Parameters.AddWithValue("@customerId", selectedCustomerId);
                        command.ExecuteNonQuery();

                        MessageBox.Show("Customer marked as 'Deleted Customer' successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        
                        loadCustomerData();
                        clearCustomerDetails();
                        switchMode("view");

                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error marking customer as 'Deleted': " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }
        #endregion

        #region Bo loc khach hang
        // Khi tick hien thi khach hang da xoa
        private void checkBoxShowDeletedCustomer_CheckedChanged(object sender, EventArgs e)
        {
            if (!checkBoxShowDeletedCustomer.Checked) { isUsingShowDeletedData = false; }
            else { isUsingShowDeletedData = true; }
            loadCustomerData();
        }
        #endregion

        #region Tim kiem khach hang
        // Phuong thuc tim kiem khach hang
        private void searchCustomer(string keyword)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    string query = @"
                        SELECT customerId AS [ID], customerName AS [Name], customerPhoneNumber AS [Phone],
                            customerAddress AS [Address]
                        FROM Customer
                        WHERE (
                            (customerId LIKE @keyword OR
                            customerName LIKE @keyword OR
                            customerPhoneNumber LIKE @keyword OR
                            customerAddress LIKE @keyword) AND (customerName != 'Deleted customer' OR customerAddress != 'Deleted Address')
                        )";

                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@keyword", $"%{keyword}%");

                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable resultTable = new DataTable();
                    adapter.Fill(resultTable);

                    dgvCustomerList.DataSource = resultTable;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Search failed: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        // Khi nhan nut
        private void textBoxSearchCustomer_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.Handled = true;
                e.SuppressKeyPress = true;

                string keyword = textBoxSearchCustomer.Text.Trim();
                if (string.IsNullOrEmpty(keyword))
                {
                    loadCustomerData();
                    return;
                }
                searchCustomer(keyword);
            }
        }
        #endregion
    }
}